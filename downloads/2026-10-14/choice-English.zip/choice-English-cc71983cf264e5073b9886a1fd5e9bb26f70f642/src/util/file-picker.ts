// JSON 文件选择工具：两库导入共用的文件拾取入口。
//
// 为什么不用「隐藏 input + .click()」这一老方案：
// 真实浏览器（非 CDP 自动化）里，file input 的选择器能否弹出受元素可见性、
// 挂载状态、内核版本多重限制——此前条目库/正则库的导入"点击毫无反应"即栽在这上面；
// 且 CDP 自动化会拦截文件选择器，使这类问题在自动化测试中完全不可见（假通过）。
//
// 策略：桌面 Chrome/Edge 优先 showOpenFilePicker（File System Access API，
// 直接弹系统级选择器，无 input 元素参与，最稳）；不支持的环境（Firefox/Safari/
// 移动端）回退到「挂载到 body 的可视隐藏 input」——挂载 + display:block 是
// 回退路径可用的最低要求（detached 或 display:none 的 input 在真机上会被拦截）。
export async function pickJsonFile(): Promise<File | null> {
  const w = window as any;
  if (typeof w.showOpenFilePicker === 'function') {
    try {
      const [handle] = await w.showOpenFilePicker({
        types: [{ description: 'JSON', accept: { 'application/json': ['.json'] } }],
      });
      return (await handle.getFile()) as File;
    } catch (err: any) {
      // 用户在原生选择器点取消：直接返回（不要回退再弹一次）
      if (err?.name === 'AbortError') return null;
      // SecurityError/NotAllowedError 等（无激活、策略限制）→ 落到底部 input 回退
    }
  }

  return new Promise<File | null>(resolve => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    // 必须挂载到文档：detached input 在部分内核不弹选择器；
    // 必须可见性例外于 ST 的 input[type=file]{display:none}：display:block + 1px + 透明
    input.style.display = 'block';
    input.style.position = 'fixed';
    input.style.top = '-100px';
    input.style.left = '-100px';
    input.style.width = '1px';
    input.style.height = '1px';
    input.style.opacity = '0';
    input.onchange = async () => {
      const file = input.files?.[0] ?? null;
      input.remove();
      resolve(file);
    };
    // 用户取消（Esc/关闭选择器）：change 不触发，部分内核派发 cancel 事件——不监听会让
    // Promise 永不 resolve、导入流程挂死（Firefox/Safari）
    input.oncancel = () => {
      input.remove();
      resolve(null);
    };
    document.body.appendChild(input);
    input.click();
    // cancel 事件缺失的内核兜底：超时清理挂载的 input 并以 null 结束（重复 resolve 无害）
    setTimeout(() => {
      if (input.isConnected) {
        input.remove();
        resolve(null);
      }
    }, 60_000);
  });
}
