import { chat_metadata, substituteParams, this_chid } from '@sillytavern/script';
import { getStCharacter, readCharacterFields } from '@/core/st-character';
import { persistGateEnter, persistGateExit } from '@/core/persist-gate';
import toastr from 'toastr';
import {
  getWorldInfoPrompt,
  loadWorldInfo,
  METADATA_KEY,
  selected_world_info,
  worldInfoCache,
} from '@sillytavern/scripts/world-info';
import { getRegexedString, regex_placement } from '@sillytavern/scripts/extensions/regex/engine';
import { uuidv4 } from '@sillytavern/scripts/utils';
import { power_user } from '@sillytavern/scripts/power-user';
import { resolvePool } from '@/core/pool-resolver';
import { resolveCount } from '@/core/resolve-count';
import { equippedCardsPromptLine } from '@/core/cards-deck';
import { callSecondaryApiWithRetry, resolveCustomApi, type ChatMsg } from '@/core/api-client';
import { dedupOptions } from '@/core/option-dedup';
import { matchOptionToEntry, prepareMatchSignals } from '@/core/option-attribution';
import { getBaiBaiSummary } from '@/core/baibai-bridge';
import { getShujukuTargetBook } from '@/core/shujuku-bridge';
import { renderWorldInfoContent } from '@/core/ejs-bridge';
import { useChatSettingsStore } from '@/store/chat-settings';
import { useGlobalSettingsStore } from '@/store/global-settings';
import { usePoolSelectorStore } from '@/store/pool-selector';
import {
  getMessageSwipeId,
  getMessageChoiceData,
  captureLayerIdentity,
  isSameLayerIdentity,
  type ChoiceGeneration,
  type ChoiceOption,
} from '@/core/options-store';
import { recordOptionsGenerated, NONE_SCOPE } from '@/core/stats';
import { enqueueAttributionAnalysis } from '@/core/ai-attribution';
import type {
  ChatSettings,
  PoolConfig,
  PoolEntry,
  PromptModule,
  WIBookMode,
  WorldInfoGlobalSettings,
} from '@/type/settings';
import { DEFAULT_MODULES, GenerationSettings, OPTION_MATCH_THRESHOLD } from '@/type/settings';

type GenerateTarget = { messageId: number; swipeId: number };

export const generatorState = reactive({ loading: false, generationId: null as string | null });

// 取消标志：模块级单例。generateOptions 串行（generatorState.loading 守卫互斥），
// cancelGeneration 触发 genController.abort() 使在途 await 立即 reject → finally 紧随复位，
// 故新一次生成启动时旧生成的 finally 必已完成，共享布尔无实际竞态。
let cancelled = false;
let genController: AbortController | null = null;

/** 最近一次行动选项生成成功的时间戳（0 = 从未成功过）。
 *  新手引导用它检测"用户已成功生成过第一组选项"，仅在 generateOptions 成功路径置位 */
export const lastOptionsGeneratedAt = ref(0);

/** 最近一次 buildMessages 的完整产物（调试用），DebugSettings 渲染；undefined = 尚未生成过。 */
export const lastBuildMessages = ref<ChatMsg[] | undefined>(undefined);

/** 最近一次去重报告（调试用），DebugSettings 渲染；undefined = 尚未生成过或去重未启用。 */
export const lastDedupReport = ref<
  | {
      dropped: number;
      refilled: boolean;
      details: { candidate: string; reason: 'title' | 'jaccard'; matchedRef: string; score?: number }[];
      threshold: number;
      refs: string[];
    }
  | undefined
>(undefined);

// resolveCount 抽到纯模块 @/core/resolve-count（可单测兜底）；此处 re-export 保
// 持既有 import { resolveCount } from './generator' 调用点（enrich-input 等）零改动
export { resolveCount };

export { resolveCustomApi };

/**
 * 解析世界书参与范围（全局排除 + 聊天排除 + 数据库开关 + 数据库目标书强制排除/启用）。
 * 供 generateOptions / enrichUserInput 共用，避免两处漂移。
 */
export async function resolveWIParticipation(
  gwi: WorldInfoGlobalSettings,
  cwi: ChatSettings['world_info'],
): Promise<{ allExcl: string[]; enabled: string[] }> {
  const gs = useGlobalSettingsStore();
  const allExcl = [...new Set([...gwi.global_excluded_books, ...cwi.excluded_books])];
  const enabled = [...cwi.enabled_books];

  const book = getShujukuTargetBook();
  if (book) {
    if (gs.settings.prompt_rules.shujuku_enabled) {
      // 开关 ON：确保该书参与。仅 push 进 enabled 不够——applyWIExcl 是「排除优先于启用」，
      // 用户在全局/聊天排除过该书时「确保参与」会被静默覆盖（注释承诺落空）。桥接书是
      // 扩展自管工作书，参与开关 ON 即参与意图的权威表达，从排除集剔除。残余：聊天侧
      // book_entry_modes 把该书设为 off 时仍会被排除（applyWIExcl 内计算，此处够不到），
      // 属显式 off 档语义，视为用户明确意愿。
      if (!enabled.includes(book)) enabled.push(book);
      const exclIdx = allExcl.indexOf(book);
      if (exclIdx !== -1) allExcl.splice(exclIdx, 1);
    } else {
      // 开关 OFF：排除该书，除非它是角色卡主世界书（避免误杀主书）
      const ch = getStCharacter(this_chid);
      const primary = String(ch?.data?.extensions?.world ?? '').trim();
      if (book !== primary) allExcl.push(book);
    }
  }

  return { allExcl, enabled };
}

export type Ctx = {
  count: number;
  pinnedCount: number;
  pinned: string;
  poolSelected: string;
  input: string;
  minChars: number;
  maxChars: number;
  enrichPersonStyle: string;
  optionPerson: string;
  enrichPerson: string;
  prevOptions: string;
};

/** 只替换本插件定义的运行时占位符；酒馆宏交给宿主的 substituteParams 处理。 */
const sub = (t: string, c: Ctx) =>
  t
    .replaceAll('{{count}}', String(c.count))
    .replaceAll('{{pinned_count}}', String(c.pinnedCount))
    .replaceAll('{{count_minus_1}}', String(Math.max(0, c.count - 1)))
    .replaceAll('{{pinned}}', c.pinned)
    .replaceAll('{{pool_selected}}', c.poolSelected)
    .replaceAll('{{input}}', c.input)
    .replaceAll('{{min_chars}}', String(c.minChars))
    .replaceAll('{{max_chars}}', String(c.maxChars))
    .replaceAll('{{enrich_person_style}}', c.enrichPersonStyle)
    .replaceAll('{{option_person}}', c.optionPerson)
    .replaceAll('{{enrich_person}}', c.enrichPerson)
    .replaceAll('{{prev_options}}', c.prevOptions);

export const buildMessages = async (
  modules: PromptModule[],
  ctx: Ctx,
  wi: WorldInfoGlobalSettings,
  contextRounds: number,
  isEnrich = false,
): Promise<ChatMsg[]> => {
  const gs = useGlobalSettingsStore();
  const pr = gs.settings.prompt_rules;
  const augmentedCtx: Ctx = {
    ...ctx,
    minChars: isEnrich ? pr.enrich_min_chars : pr.option_min_chars,
    maxChars: isEnrich ? pr.enrich_max_chars : pr.option_max_chars,
    enrichPersonStyle:
      pr.enrich_person_style || (pr.enrich_person ? `Use uniformly${pr.enrich_person} {{user}} is the subject` : ''),
    optionPerson: pr.option_person || 'third person',
    enrichPerson: pr.enrich_person || 'third person',
  };
  const msgs: ChatMsg[] = [];
  const wiBuckets = wi.enabled ? await buildWI() : null;

  const sorted = [...modules].sort((a, b) => a.order - b.order);

  for (const mod of sorted) {
    if (!mod.enabled) continue;
    if (isEnrich && mod.option_only) continue;

    switch (mod.id) {
      case 'system_prompt': {
        const content = substituteParams(sub(mod.content, augmentedCtx));
        if (content) msgs.push({ role: mod.role, content });
        break;
      }
      case 'world_info_before': {
        if (wiBuckets) {
          const merged = [wiBuckets.before, wiBuckets.anBefore, wiBuckets.em].filter(Boolean).join('\n\n');
          if (merged) msgs.push({ role: 'system', content: merged });
        }
        break;
      }
      case 'persona_description': {
        const personaDesc = power_user?.persona_description;
        if (personaDesc) {
          msgs.push({
            role: 'system',
            content: `<user_persona>\nThe following is the character setting of the user himself (user = protagonist = user): \n${substituteParams(personaDesc)}\n</user_persona>`,
          });
        }
        break;
      }
      case 'char_description': {
        const ch = getStCharacter(this_chid);
        const desc = readCharacterFields(ch).description;
        if (desc) msgs.push({ role: 'system', content: substituteParams(desc) });
        break;
      }
      case 'char_personality': {
        const ch = getStCharacter(this_chid);
        const personality = readCharacterFields(ch).personality;
        if (personality) msgs.push({ role: 'system', content: substituteParams(personality) });
        break;
      }
      case 'char_scenario': {
        const ch = getStCharacter(this_chid);
        const scenario = readCharacterFields(ch).scenario;
        if (scenario) msgs.push({ role: 'system', content: substituteParams(scenario) });
        break;
      }
      case 'world_info_after': {
        if (wiBuckets) {
          // 深度条目不再塞此桶末尾、也不再织入历史中段（会与对白交织污染 <history>），
          // 改按 depth 分组迁到 <history> 标签外——见 wi_depth_before/after 两个 marker
          const merged = [wiBuckets.after, wiBuckets.anAfter].filter(Boolean).join('\n\n');
          if (merged) msgs.push({ role: 'system', content: merged });
        }
        break;
      }
      case 'chat_history': {
        // 保持原始 user/assistant 角色（buildChatHistory 内已强制，v69 起无预填充开关可切换）；
        // 世界书深度条目不再织入此数组，改由 wi_depth_before/after 在聊天历史外注入
        const history = buildChatHistory(contextRounds);
        for (const m of history) msgs.push(m);
        break;
      }
      case 'wi_depth_before': {
        // depth ≥ 3 的世界书 atDepth 条目，注入 </reference> 与聊天历史之间（深、背景）
        if (wiBuckets && wiBuckets.depthBefore) msgs.push({ role: 'system', content: wiBuckets.depthBefore });
        break;
      }
      case 'wi_depth_after': {
        // depth ≤ 2（D0/D1/D2）的世界书 atDepth 条目，注入聊天历史之后（浅、贴近生成点）
        if (wiBuckets && wiBuckets.depthAfter) msgs.push({ role: 'system', content: wiBuckets.depthAfter });
        break;
      }
      case 'baibai_summary': {
        if (!gs.settings.prompt_rules.baibai_enabled) break;
        const text = getBaiBaiSummary();
        if (text) {
          msgs.push({
            role: 'system',
            content: `<baibai_summary>\nThe following is a compressed summary of the plot that has occurred by the memory system. It records historical role-playing events that have left the current context window and are no longer directly visible. It is provided for your reference only to keep the plot coherent, and may not be quoted or repeated directly in your reply. \n${text}\n</baibai_summary>`,
          });
        }
        break;
      }

      case 'core_rules': {
        // core_rules 单一来源：直接发模块自己的 content（经占位符替换）。
        // 以前按隐藏字段动态拼装，造成"编辑器显示 ≠ 实际发送"的双来源矛盾；
        // 该路径已整体删除，现在编辑器内容就是发送给 AI 的内容。
        const content = substituteParams(sub(mod.content, augmentedCtx));
        if (content) msgs.push({ role: mod.role, content });
        break;
      }
      case 'thinking_prompt': {
        const content = substituteParams(sub(mod.content, augmentedCtx));
        if (content) msgs.push({ role: mod.role, content });
        break;
      }
      default: {
        // v69：模块一律按其自身 role 发送（assistant_ack/assistant_thinking/enrich_assistant
        // 不再特殊处理，预填充开关已移除）。想用预填充把模块角色改为 assistant 即可。
        const content = substituteParams(sub(mod.content, augmentedCtx));
        if (content) msgs.push({ role: mod.role, content });
        break;
      }
    }
  }

  // 合并相邻同 role 消息，避免连续多个 system/user/assistant。
  // user 消息不互相合并（审计 A5）：聊天历史末条 user 与 option_task/enrich_prompt
  // 同为 user 时会把「生成任务」混进历史正文——user 角色消息在提示词里代表独立的输入
  // 边界，合并会模糊"这是用户说的话"还是"这是任务指令"；system/assistant 相邻（多为
  // 内置模块拼接）仍合并以减少首尾噪音
  const merged: ChatMsg[] = [];
  for (const msg of msgs) {
    const last = merged[merged.length - 1];
    if (last && last.role === msg.role && msg.role !== 'user') {
      last.content = last.content + '\n\n' + msg.content;
    } else {
      merged.push({ ...msg });
    }
  }
  lastBuildMessages.value = structuredClone(merged);
  return merged;
};

/**
 * 拉取聊天历史。wrapCurrentScene=true（默认）时把最后一条 assistant 消息包进 <current_scene>，
 * 让选项 AI 明确"当前场景"边界——选项是场景产物，需要这层锚定；卡牌主题池等跨场景常驻
 * 内容的生成方传 false：卡在剧情推进后仍要反复掉落，绑死当前场景会让池子迅速过时。
 */
export const buildChatHistory = (contextRounds: number, wrapCurrentScene = true): ChatMsg[] => {
  const ctx = window.SillyTavern?.getContext?.();
  const chatArr: any[] = ctx?.chat ?? [];
  const gs = useGlobalSettingsStore();
  const mode = gs.settings.prompt_rules.context_mode;
  // 镜像 ST 主生成 coreChat：先剔除隐藏楼层（is_system），再按模式截尾。
  // visible_only：全量未隐藏消息；rounds：未隐藏消息的最后 N*2 条（隐藏楼层不再占轮数槽位，
  // 避免被截进 N*2 窗口后再丢弃导致实际发送轮数偏少）。
  // 原 `m.is_hidden` 过滤是死代码——酒馆原始 chat 对象无此字段，隐藏真实字段是 is_system。
  const visible = chatArr.filter((m: any) => !m.is_system);
  const msgs = mode === 'rounds' && contextRounds > 0 ? visible.slice(-contextRounds * 2) : visible;
  const rules = gs.sortedEnabledFilterRules;
  const h: ChatMsg[] = [];
  let lastAssistantIdx = -1;
  // 提取遍恒定先于 tag/regex 遍执行（顺序固定、与规则排列无关）：提取是"保留哪些"的负向语义，
  // 必须先把消息裁剪到只剩标签区间，之后现有 tag/regex 规则在裁剪结果上继续跑——
  // 这样"提取后再用标签过滤滤掉提取内容里的子标签"天然成立，且无提取规则的用户行为零变化
  const extractRules = rules.filter(r => r.type === 'extract');
  // depth 相对当前迭代数组：0=距末尾最近一条，对齐 script.js:4445（rounds 截尾取自末尾，
  // 截尾数组内 depth 与全量未隐藏数组一致，无需特判）
  const total = msgs.length;
  for (let i = 0; i < total; i++) {
    const m = msgs[i];
    // 先过酒馆正则扩展的提示词侧处理——与主生成完全一致：promptOnly 正则按 minDepth/maxDepth
    // 限定作用楼层（"只保留最近 N 层"类脚本即靠此清空旧楼层），不应用则旧楼层全文直发 AI。
    // depth 必须传入，否则 minDepth/maxDepth 判定被整段跳过（engine.js:362）。不传 characterOverride，
    // 与主生成历史路径一致（script.js:4447）。清空后的空消息由下方 !content.trim() 整条丢弃。
    // 开关关闭时整体跳过酒馆正则（含 depth 限定脚本）——逃生舱：预设正则清空旧层 user 输入
    // 会让相邻 assistant 失去 user 分隔而"合并"，受此困扰的用户可关闭此开关只用本页过滤规则。
    const stRegexOn = gs.settings.filter_settings.st_regex_enabled;
    const placement = m.is_user ? regex_placement.USER_INPUT : regex_placement.AI_OUTPUT;
    let content = stRegexOn
      ? getRegexedString(String(m.mes ?? ''), placement, { isPrompt: true, depth: total - i - 1 })
      : String(m.mes ?? '');
    if (!content) continue;
    // 标签提取只作用于 AI 输出（assistant）：user 输入多为纯文本/对白，不含待提取的结构化
    // 标签区间，对其执行 extract 会因无目标标签而整条丢弃，致用户发送内容从提示词消失。
    // tag/regex 过滤仍对所有消息（含 user）生效——删除语义不整条丢，保留原行为
    const isUser = m.role === 'user' || m.is_user;
    if (!isUser && extractRules.length > 0) {
      content = extractTagContents(content, extractRules);
      // 没有任何目标标签 → 该消息没有可保留的内容，整条丢弃（与"过滤后为空丢弃"一致）
      if (!content.trim()) continue;
    }
    for (const rule of rules) {
      try {
        if (rule.type === 'extract') continue; // 已由提取遍整段处理
        if (rule.type === 'tag') {
          if (!rule.start && !rule.end) continue;
          const startPat = rule.start ? escapeRegExp(rule.start) : '';
          const endPat = rule.end ? escapeRegExp(rule.end) : '';
          // 仅标签头：从起始标签匹配到字符串末尾；仅标签尾：从开头匹配到结束标签；两者都有：匹配标签对
          const body = rule.start ? (rule.end ? '[\\s\\S]*?' : '[\\s\\S]*') : '[\\s\\S]*?';
          const re = new RegExp(startPat + body + endPat, 'g');
          content = content.replace(re, '');
        } else {
          if (!rule.pattern) continue;
          // replace 为空串时即"整段删除"；导入 ST 正则时承载其 replaceString（如 $1 保留内容去标签壳）
          content = content.replace(new RegExp(rule.pattern, 'gs'), rule.replace ?? '');
        }
      } catch {
        console.warn('[choice] Invalid filter rule:', rule);
      }
    }
    if (!content.trim()) continue;
    // 保持原始 user/assistant 角色：实测统一 system 后模型不适应历史语境，
    // 恢复按消息来源区分角色。lastAssistantIdx 仍用 isUser 追踪最后一条 AI 楼层，
    // 用于下方 <current_scene> 包裹——与 role 字段解耦，改 role 不影响锚定逻辑
    h.push({ role: isUser ? 'user' : 'assistant', content });
    if (!isUser) lastAssistantIdx = h.length - 1;
  }
  // 将最后一条 assistant 消息用 <current_scene> 包裹，让 AI 明确识别"当前场景"边界，
  // 避免在长对话中注意力被稀释到更早的剧情。回退到 h 最后一条（无 assistant 时）。
  // wrapCurrentScene=false（卡牌池等跨场景生成方）跳过包裹，见函数头注释
  if (wrapCurrentScene && h.length > 0) {
    const wrapIdx = lastAssistantIdx >= 0 ? lastAssistantIdx : h.length - 1;
    h[wrapIdx].content = `<current_scene>\n${h[wrapIdx].content}\n</current_scene>`;
  }

  return h;
};

// 将标签头/尾按字面量转义，避免 <思考>、[小剧场] 等含正则特殊字符的标签被误解析
const escapeRegExp = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// 标签提取：收集所有 extract 规则的 <标签>…</标签> 字面量区间（并集，含标签壳），按原文
// 顺序拼接保留、舍弃其余。为什么不用逐规则 replace 实现：提取是负向语义（保留命中的、
// 删除没命中的），逐规则独立 replace 会互相吃掉对方尚未处理的匹配区间，多标签并集无法表达。
// lazy（*?）配对与现有 tag 删除规则一致；同名标签嵌套/畸形交错属边角输入，重叠区间只保留
// 最先命中的完整对，不重复输出
const extractTagContents = (content: string, rules: Array<{ tag_name: string }>): string => {
  const ranges: Array<[number, number]> = [];
  for (const rule of rules) {
    const name = rule.tag_name.trim();
    if (!name) continue;
    const re = new RegExp(escapeRegExp(`<${name}>`) + '[\\s\\S]*?' + escapeRegExp(`</${name}>`), 'g');
    for (const match of content.matchAll(re)) {
      ranges.push([match.index ?? 0, (match.index ?? 0) + match[0].length]);
    }
  }
  if (ranges.length === 0) return '';
  ranges.sort((a, b) => a[0] - b[0] || b[1] - a[1]);
  let out = '';
  let keptEnd = -1;
  for (const [start, end] of ranges) {
    if (start < keptEnd) continue;
    out += content.slice(start, end);
    keptEnd = end;
  }
  return out;
};

export type WIBuckets = {
  before: string;
  after: string;
  anBefore: string;
  anAfter: string;
  em: string;
  /** atDepth 世界书条目，按深度阈值分两组、各自按 depth 降序拼接、统一 system 注入：
   *  depth ≤ WI_DEPTH_AFTER_MAXDEPTH（0/1/2）→ depthAfter，注入 </history> 之后（浅、贴近生成点）；
   *  depth ≥ 阈值+1 → depthBefore，注入 <history> 之前（深、背景）。不再织入历史中段，
   *  保持 <history> 纯对白，避免世界书与正文交织污染历史内容。 */
  depthBefore: string;
  depthAfter: string;
};

/** depth ≤ 此值的世界书深度条目注入 </history> 之后（浅、贴近生成点）；> 此值注入 <history> 之前（深、背景）。
 *  取 2：D0/D1/D2 归"历史后"，D3+ 归"历史前"（用户指定）。 */
const WI_DEPTH_AFTER_MAXDEPTH = 2;

/** 对 buckets 的 7 个 content 字段并行展宏 + 执行 EJS（开关由调用方判断）。
 *  纯提取自 buildWI 的渲染回填块；返回新对象，原 buckets 不被原地改写以保持纯函数性。
 *  renderWorldInfoContent 内部对无 <% 的纯文本短路、未装提示词模板插件时降级为只展宏 */
const renderWIBuckets = async (buckets: WIBuckets): Promise<WIBuckets> => {
  const [before, after, anBefore, anAfter, em, depthBefore, depthAfter] = await Promise.all([
    renderWorldInfoContent(buckets.before),
    renderWorldInfoContent(buckets.after),
    renderWorldInfoContent(buckets.anBefore),
    renderWorldInfoContent(buckets.anAfter),
    renderWorldInfoContent(buckets.em),
    renderWorldInfoContent(buckets.depthBefore),
    renderWorldInfoContent(buckets.depthAfter),
  ]);
  return { before, after, anBefore, anAfter, em, depthBefore, depthAfter };
};

export const buildWI = async (): Promise<WIBuckets> => {
  const gs = useGlobalSettingsStore();
  const empty: WIBuckets = {
    before: '',
    after: '',
    anBefore: '',
    anAfter: '',
    em: '',
    depthBefore: '',
    depthAfter: '',
  };
  try {
    const ctx = window.SillyTavern?.getContext?.();
    const chatArr: any[] = ctx?.chat ?? [];
    // getWorldInfoPrompt 要求 chat 为倒序（最新消息在前），与 ST 主生成 script.js
    // 中 .reverse() 保持一致。不倒序会导致 WorldInfoBuffer 把最旧消息当作最新层扫描，
    // 绿灯关键词匹配的是旧上下文而非当前层。
    // 过滤 is_system：主生成喂给 checkWorldInfo 的是 coreChat（已剔除隐藏楼层），choice 此前
    // 喂全量 chat 会让隐藏楼层里的关键词多触发绿灯记忆条目，与主生成激活范围不一致。
    const chatStrings = chatArr
      .filter((m: any) => !m.is_system)
      .map((m: any) => m?.mes ?? '')
      .reverse();
    const ch = getStCharacter(this_chid);
    // 角色字段走 readCharacterFields（V2 缺失时兜底顶层 V1）：直读 ch.data.* 会让 V1/浅卡
    // 在这里看到空串——WI 关键词激活扫描拿不到角色描述，而 char_description 等提示词模块
    // 却能（readCharacterFields 兜底），同一次生成两套口径。
    const charFields = readCharacterFields(ch);

    // 世界书预算 = world_info_budget(%) × maxContext。ST 主生成用 ctx.maxContext(如 8192) 算预算，
    // 但行动选项是独立 API 调用，沿用 8192 会让角色世界书的大条目先耗尽预算，
    // 导致额外启用的世界书 constant 条目在预算检查阶段被丢弃（"budget of N reached"）。
    // 这里放宽到较大上下文估算值，使预算不再成为额外世界书条目的瓶颈。
    const maxCtx = 128000;

    const result = await getWorldInfoPrompt(chatStrings, maxCtx, false, {
      trigger: 'normal',
      personaDescription: power_user?.persona_description ?? '',
      characterDescription: charFields.description ?? '',
      characterPersonality: charFields.personality ?? '',
      characterDepthPrompt: ch?.data?.extensions?.depth_prompt?.prompt ?? '',
      scenario: charFields.scenario ?? '',
      creatorNotes: ch?.data?.creator_notes ?? '',
    });

    // worldInfoDepth 结构 = [{depth, entries: string[]}]（world-info.js:5121-5125 已核实）。
    // 同 depth+role 的多条目 ST 已 unshift 合并进同一组，组内按 \n 拼接即可。v38 起不再
    // 织入历史中段：按 WI_DEPTH_AFTER_MAXDEPTH 分两组，各自按 depth 降序（深者在前 / D2→D0
    // 在末，使 D0 最贴近生成点）、组间 \n\n 拼成单串，注入时统一 system（条目原 role 不保留）
    const allDepth = (result.worldInfoDepth ?? [])
      .map((d: any) => ({
        depth: typeof d?.depth === 'number' ? d.depth : 0,
        content: (d?.entries ?? []).filter(Boolean).join('\n'),
      }))
      .filter(e => e.content);
    const byDepthDesc = (a: { depth: number }, b: { depth: number }) => b.depth - a.depth;
    const buckets: WIBuckets = {
      before: result.worldInfoBefore ?? '',
      after: result.worldInfoAfter ?? '',
      anBefore: (result.anBefore ?? []).join('\n'),
      anAfter: (result.anAfter ?? []).join('\n'),
      em: (result.worldInfoExamples ?? [])
        .map((e: any) => e?.content ?? '')
        .filter(Boolean)
        .join('\n'),
      depthBefore: allDepth
        .filter(e => e.depth > WI_DEPTH_AFTER_MAXDEPTH)
        .sort(byDepthDesc)
        .map(e => e.content)
        .join('\n\n'),
      depthAfter: allDepth
        .filter(e => e.depth <= WI_DEPTH_AFTER_MAXDEPTH)
        .sort(byDepthDesc)
        .map(e => e.content)
        .join('\n\n'),
    };

    // EJS 渲染后处理（开关开时）：对 buckets 各 content 展宏 + 执行提示词模板插件的 <% %>。
    // 零侵入——getWorldInfoPrompt/分桶逻辑不碰；未装插件时 renderWorldInfoContent 内部
    // 降级为只展宏（<% 原样保留），不比现状差。depthBefore/depthAfter 已是单串，并入同一轮
    // Promise.all 渲染回填即可（迁出历史后注入逻辑对渲染结果无感）
    if (gs.settings.world_info.render_world_info_ejs) {
      Object.assign(buckets, await renderWIBuckets(buckets));
    }

    return buckets;
  } catch (err) {
    console.error('[Choice] buildWI failed', err);
    return empty;
  }
};

type Restore = { restore: () => void } | null;

/** 世界书注入的临时改写（选项/润色两条生成链路共用）：
 *  1. 书级：临时重写 selected_world_info（移除排除书/off 模式书、追加启用书），并按需清空角色绑定书，
 *     restore 恢复；
 *  2. 条目级：force/custom 模式下经 Map.prototype.get.call 取 worldInfoCache 缓存原始引用，
 *     临时变异条目 disable 标志，restore 逐条还原——checkWorldInfo 对 disable==true 的条目跳过
 *     （world-info.js:4689），变异即控制注入。
 *  处理范围 = 生成时 ST 实际会读取的所有"活动书"：selected_world_info（getGlobalLore，world-info.js:4415）、
 *  角色绑定书 character.data.extensions.world（getCharacterLore，:4363）、聊天绑定书
 *  chat_metadata[METADATA_KEY]（getChatLore，:4432，原生聊天世界书）、enabled_books（用户显式启用）。
 *  此前只遍历 enabled_books，导致在角色绑定书 / 全局选中书 / 聊天绑定书上设置的 off/force/custom
 *  与逐条覆盖被静默忽略（"整本关了仍注入"即此因），现已扩到全集。
 *  四态语义：off=整本并入临时排除（等价"条目全关"）；follow=酒馆原生 disable（覆盖不生效，切换模式即
 *  脱离自定义）；force=全部条目 disable=false；custom=按 book_entry_overrides 逐条生效（快照未覆盖的
 *  条目保持酒馆原状）。异步原因：loadWorldInfo 未命中缓存时会 fetch，条目变异必须在 getWorldInfoPrompt
 *  之前完成，故调用方需 await 本函数。 */
export const applyWIExcl = async (
  excl: string[],
  enabled: string[],
  bookModes?: Record<string, WIBookMode>,
  bookEntryOverrides?: Record<string, Record<string, boolean>>,
): Promise<Restore> => {
  const saved = [...(selected_world_info ?? [])];
  const modes = bookModes ?? {};
  const modeOf = (name: string): WIBookMode => modes[name] ?? 'follow';

  // 处理范围 = ST 生成时实际读取的全部活动书（见上方 JSDoc 出处）。
  // 角色绑定书 / 聊天绑定书不在 enabled_books 里，旧实现只遍历 enabled_books 才是 bug 根源。
  const ch = getStCharacter(this_chid);
  const cw = ch?.data?.extensions?.world;
  // 聊天绑定书：原生世界书面板的"聊天世界书"按钮绑定（chat_metadata[METADATA_KEY]，METADATA_KEY='world_info'）。
  // getChatLore（world-info.js:4432）直接读此键，不在 selected_world_info 中，故需单独纳入处理范围。
  const chatBook = typeof chat_metadata?.[METADATA_KEY] === 'string' ? chat_metadata[METADATA_KEY] : '';
  const processSet = new Set<string>([...saved, ...enabled, ...(cw ? [cw] : []), ...(chatBook ? [chatBook] : [])]);

  // off 模式书并入临时排除：整本不注入（等价"条目全关"的生成结果，且无需条目级变异）。
  // 覆盖全集，不再只筛 enabled_books——否则角色/全局书的 off 模式形同虚设。
  const offBooks = [...processSet].filter(name => modeOf(name) === 'off');
  const allExcl = new Set<string>([...excl, ...offBooks]);

  // 仅当确有改写需要时才动 selected_world_info，避免无配置时无谓重写。
  // hasNewEnabled：用户显式启用的书若尚未在 selected_world_info 中，必须追加以便 getGlobalLore 读取。
  const hasExcl = allExcl.size > 0;
  const hasMutation = [...processSet].some(name => modeOf(name) === 'force' || modeOf(name) === 'custom');
  const hasNewEnabled = enabled.some(n => !saved.includes(n));
  if (!hasExcl && !hasMutation && !hasNewEnabled) return null;

  // 持久化闸门：窗口内的临时改写（角色/聊天绑定书置空）若被并发持久化通道序列化，
  // 空值会落盘（内存 restore 救得回、磁盘救不回）。见 persist-gate.ts 模块注释。
  persistGateEnter();
  // 还原所需状态提升到 try 外：中途抛错时 catch 要做尽力还原（原缺陷：变异段无 restore
  // 路径，全局态带伤且无法回滚——现实可达性极低，但一旦发生污染持续到下次生成）
  const cwEx = !!cw && allExcl.has(cw);
  const chatBookEx = !!chatBook && allExcl.has(chatBook);
  type MutableEntry = { uid?: number | string; disable?: boolean };
  const mutated: Array<{ entry: MutableEntry; value: boolean }> = [];
  const restoreAll = (): void => {
    selected_world_info.length = 0;
    selected_world_info.push(...saved);
    if (cwEx && ch?.data?.extensions) ch.data.extensions.world = cw;
    if (chatBookEx) chat_metadata[METADATA_KEY] = chatBook;
    for (const m of mutated) m.entry.disable = m.value;
  };
  try {
    selected_world_info.length = 0;
    const newList = saved.filter(n => !allExcl.has(n));
    for (const name of enabled) {
      // 排除优先于启用：被排除的书即使仍在 enabled 列表里也不注入
      if (!allExcl.has(name) && !newList.includes(name)) newList.push(name);
    }
    selected_world_info.push(...newList);
    if (cwEx && ch?.data?.extensions) ch.data.extensions.world = '';
    // 聊天绑定书被排除/off：临时清空 chat_metadata[METADATA_KEY]，getChatLore 读到空串即返回 []（:4435）。
    // 与角色绑定书的临时改写同一模式；restore 还原原值。
    if (chatBookEx) chat_metadata[METADATA_KEY] = '';

    // 条目级 disable 变异：worldInfoCache 是 StructuredCloneMap 且 cloneOnGet:true
    // （world-info.js:882，已核实）——loadWorldInfo 命中缓存走 worldInfoCache.get 返回深拷贝
    // （world-info.js:2041），直接变异拷贝无法影响生成。故先 loadWorldInfo 确保书已进缓存，再经
    // Map.prototype.get.call 绕过 clone-on-get 拿到缓存内原始引用变异，restore 逐条还原。
    const overrides = bookEntryOverrides ?? {};
    for (const name of processSet) {
      if (allExcl.has(name)) continue; // off/排除书不注入，无需条目级变异
      const mode = modeOf(name);
      if (mode === 'follow') continue; // follow：纯酒馆原生 disable，覆盖不生效
      try {
        await loadWorldInfo(name); // 确保书已进缓存（其 set 为 cloneOnSet:false，存引用本身）
        const data = Map.prototype.get.call(worldInfoCache, name) as
          { entries?: Record<string, MutableEntry> } | undefined;
        if (!data?.entries) continue;
        const bookOverrides = overrides[name] ?? {};
        for (const entry of Object.values(data.entries)) {
          if (!entry || typeof entry.disable !== 'boolean') continue;
          const uidKey = `${entry.uid}`;
          if (mode === 'force') {
            // force 全启用：覆盖不生效（条目勾选框显示与生成一致）
            if (entry.disable) {
              mutated.push({ entry, value: entry.disable });
              entry.disable = false;
            }
          } else if (mode === 'custom') {
            // custom：按覆盖逐条；快照未覆盖的条目保持酒馆原状
            const ov = bookOverrides[uidKey];
            if (typeof ov !== 'boolean') continue;
            if (entry.disable === ov) {
              mutated.push({ entry, value: entry.disable });
              entry.disable = !ov;
            }
          }
        }
      } catch (err) {
        console.warn('[Choice] applyWIExcl entry mutation failed (leaving SillyTavern as is):', name, err);
      }
    }

    return {
      restore: () => {
        try {
          restoreAll();
        } finally {
          // 先还原再放行排队的持久化：放行时序列化读到的是完整还原后的状态
          persistGateExit();
        }
      },
    };
  } catch (err) {
    // 变异段自身抛错（理论上各写点均有守卫）：尽力还原已完成的全局改写 + 退出闸门防
    // 持久化悬挂，再原样上抛由调用方兜底
    try {
      restoreAll();
    } catch {
      /* 还原失败仅能记录，勿吞原始异常 */
    }
    persistGateExit();
    throw err;
  }
};

/** 世界书排他窗口互斥（模块级队列）：applyWIExcl 是对酒馆全局 WI 状态（selected_world_info/
 *  角色绑定书/chat_metadata/缓存条目 disable）的 save/restore，选项生成/润色/卡牌池三条链路
 *  并发时窗口交错——后者的 restore 会基于前者已改写的快照回滚，把临时排除永久留在酒馆状态。
 *  排队串行化消除交错；窗口已收窄到「消息构建完成即还原」（副 API 直连不再读酒馆世界书），
 *  排队等待为毫秒级。 */
let wiWindowTail: Promise<void> = Promise.resolve();
export async function runWIExclWindow<T>(task: () => Promise<T>): Promise<T> {
  const prev = wiWindowTail;
  let release!: () => void;
  wiWindowTail = new Promise<void>(resolve => (release = resolve));
  await prev;
  try {
    return await task();
  } finally {
    release();
  }
}

/** 思维链标签块剥离正则：parseOptions 共用。
 *  新增模型思维标签（如 <reasoning_content>/<antThinking>）时只改这一处即可同步，
 *  避免只补一处而另一处静默漏处理。String.replace 对 /g 正则不保留 lastIndex 状态，跨调用共享安全。 */
const STRIP_REASONING_TAGS_RE =
  /<(?:think(?:ing)?|reasoning|thought)>[\s\S]*?<\/(?:think(?:ing)?|reasoning|thought)>/gi;

/** 标签堆叠间隙判定：标题括号闭合后到同一下一个括号之间，仅含空白和/或 emoji 才算堆叠。
 *  输出契约是 "[标题]emoji 内容"，emoji 紧跟标题括号，AI 无视禁令在正文开头再加场景头
 *  括号时间隙就是"emoji+空白"（实测："[回溯闪回]🎞️ [记忆片段·三年前] 正文"曾被切成
 *  "[回溯闪回]🎞️" 和 "[记忆片段·三年前] 正文" 两条）。emoji 用 Unicode
 *  Extended_Pictographic 属性类 + 变体选择符/ZWJ/肤色修饰符，不枚举具体 emoji 码位
 *  （新 emoji 不断新增，枚举必漏）。修饰符不写成字符类 [\uFE0F\u200D…]*：字符类按码位
 *  逐一匹配，组合序列（旗子成对 Regional Indicator、修饰符必须紧跟基字符）会被错误放行，
 *  no-misleading-character-class 正是拦这个误用——修饰符只能紧跟 emoji，故用非捕获组
 *  列举修饰符码位（肤色五个码位用 \p{Emoji_Modifier} 涵盖，与 1F3FB-1F3FF 精确等价）。
 *  不用 v flag 字符类集合语法：ES2024，移动端 WebView 内核滞后不兼容。关键取舍：间隙里
 *  出现任何正文文字仍判为新选项——AI 把两条选项挤在一行（"[A]内容A [B]内容B"）必须
 *  拆开，区分依据是位置：场景头只会出现在任何正文之前（紧跟标题的 emoji 是格式的一部分），
 *  正文都写完了才出现的括号只可能是下一条选项的标题，哪怕内容以 emoji 收尾
 *  （"内容A🎞️ [B]…"）也按新选项拆 */
const TAG_STACK_GAP_RE = /^(?:[^\S\r\n]|\p{Extended_Pictographic}(?:\uFE0F|\u200D|\u20E3|\p{Emoji_Modifier})*)*$/u;

/** 字符串感知的尾随逗号清理：跳过引号区间，仅删除引号外 `,`+空白+`]`/`}` 处的逗号。
 *  不能用全局正则 `,(\s*[\]}])` 替换——它会命中字符串值内部的 ",]"/",}" 字面量，
 *  静默篡改选项正文（如列举示例"苹果,橘子]"）。 */
const stripTrailingCommas = (s: string): string => {
  let out = '';
  let inStr = false;
  let esc = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      out += ch;
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') {
      inStr = true;
      out += ch;
      continue;
    }
    if (ch === ',') {
      let k = i + 1;
      while (k < s.length && (s[k] === ' ' || s[k] === '\t' || s[k] === '\n' || s[k] === '\r')) k++;
      if (s[k] === ']' || s[k] === '}') continue;
    }
    out += ch;
  }
  return out;
};

/** 尝试把 `<options>` 块文本当 JSON 数组解析（主路径；解析失败走括号回退）。
 *  返回解析出的选项字符串数组，或 null（非数组 / 解析失败 / 解析后全空）。
 *  兼容多种元素形态：{title,content}、纯字符串、{text}、{option}、{t,c}、{type,content}。
 *  有 title 时重建为 `[title]content`（title 可带 |档位|需求值 标注，供骰子/档位消费）；
 *  内容含 []/【】/换行等任意字符都在 content 字符串里、依赖下游 ^ 锚定解析当内容处理，不切分。
 *  纯提取自 parseOptions 的 JSON 分支，便于复用与单测 */
const parseJsonOptionArray = (c: string): string[] | null => {
  try {
    // 处理 JSON 尾随逗号（LLM 常见错误）：复用条目池路径的字符串感知版本——全局正则
    // `,(\s*[\]}])` 会命中字符串值内部的 ",]"/",}" 字面量，静默篡改选项正文
    const p = JSON.parse(stripTrailingCommas(c));
    if (!Array.isArray(p)) return null;
    const items = p
      .map(x => {
        if (typeof x === 'string') return x.trim();
        const title = typeof x?.title === 'string' ? x.title.trim() : '';
        const body =
          (typeof x?.content === 'string' ? x.content.trim() : null) ??
          (typeof x?.text === 'string' ? x.text.trim() : null) ??
          '';
        if (title) return body ? `[${title}]${body}` : `[${title}]`;
        // 无 title 但带 type（弱模型把方向词放进 type 字段）：映射成 [type]正文——与
        // {title,content} 同构（本契约里括号标题就是类型词）。旧的 `${type}: ${content}`
        // 模板分支对字符串 content 永不可达（body 已先行消费 content），类型信息丢失、
        // 归因的前缀匹配随之失效
        const typeAsTitle = typeof x?.type === 'string' ? x.type.trim() : '';
        if (typeAsTitle) return body ? `[${typeAsTitle}]${body}` : `[${typeAsTitle}]`;
        return (
          // 无 title 时回退链先查 body（已从 x.content 算出）：漏查会让
          // [{"content":"正文"}]（弱模型漏 title 字段，常见）被静默丢弃，
          // 与 {"text":"正文"} 可保留不对称——选项凭空变少且无提示。
          // body 为空串时继续回退（content:'' + text:'备用' 不应丢备用）
          (body || null) ??
          x?.text?.trim() ??
          x?.option?.trim() ??
          // ?? 右侧用 undefined 而非 ''，确保 '' 假值时链继续回退
          (x?.t && x?.c ? `${x.t}: ${x.c}` : undefined)
        );
      })
      .filter(Boolean);
    return items.length ? items : null;
  } catch {
    /* not JSON */
    return null;
  }
};

export function parseOptions(text: string, count: number): string[] {
  // 找到最后一个思维链闭合标签，丢弃它之前的所有内容
  // 原因：AI 可能在思维链中以文本形式提到 <options>（如"格式：<options> 标签内..."），
  // 直接在原始文本中 matchAll <options> 会误匹配到这些文本引用，导致提取错误
  const closeTagRe = /<\/(?:think(?:ing)?|reasoning|thought)>/gi;
  const closeMatches = [...text.matchAll(closeTagRe)];
  let c: string;

  if (closeMatches.length > 0) {
    const lastClose = closeMatches[closeMatches.length - 1];
    c = text.slice(lastClose.index! + lastClose[0].length).trim();
  } else {
    // 没有思维链闭合标签，剥离配对的思维链标签后使用全文
    c = text.replace(STRIP_REASONING_TAGS_RE, '').trim();
  }

  // 从剩余文本中提取 <options> 块
  const m = c.match(/<options>([\s\S]*?)<\/options>/i);
  if (m) {
    c = m[1].trim();
  } else {
    const openTagIdx = c.search(/<options>/i);
    if (openTagIdx !== -1) {
      c = c.slice(openTagIdx + '<options>'.length).trim();
    }
  }

  // 剥离 markdown 代码块（LLM 可能输出 ```json...```）
  c = c
    .replace(/^```[a-zA-Z]*\s*/i, '')
    .replace(/\s*```$/, '')
    .trim();

  // 主路径：JSON 数组（prompt 契约要求）。AI 输出以 `[` 开头即优先按 JSON 解析；
  // 结构读出内容（含 []/【】/换行都安全）。解析失败落到下面的括号回退。
  if (c.startsWith('[')) {
    const jsonParsed = parseJsonOptionArray(c);
    if (jsonParsed) return jsonParsed.slice(0, count);
  }

  // 回退路径（非 JSON 产出者，如旧提示词快照/老模型）：【】或 [] 格式——标题用【】或 []
  // 包裹，后续文本为内容，跨行自动合并。此路径下内容里再出现 []/【】仍可能被切（接受范围，
  // 历史上为兼容 run-on 与 【标题】 容错而保留）。边界判定按提示词契约"每条选项独占一行"
  // 做行锚定：只有行首（间隙含换行或正文）的
  // 括号才开启新选项。同一行内紧邻/仅隔空白或 emoji 的连续括号是"标签堆叠"（如
  // "[回溯闪回]🎞️ [记忆片段·三年前] 正文"、"[回溯闪回]【三年前·初二暑假】正文"），
  // 必须并入同一条——AI 常无视禁令在正文里用【】/[]写场景头，若把每个括号都当边界，
  // 一条选项会被切成 "[标签]" 和 "[场景头]正文" 两条（实测发生过，emoji 变体亦然）。
  // 间隙含正文文字则仍拆分（AI 挤行的两条选项），见 TAG_STACK_GAP_RE 注释
  const bracketTitleRe = /[[【]([^\]】]+?)[\]】]\s*/g;
  const bracketMatches = [...c.matchAll(bracketTitleRe)];
  if (bracketMatches.length > 0) {
    const result: string[] = [];
    // 上一个匹配里闭合括号之后的位置。match[0] 末尾的 \s* 会吞掉行尾换行，
    // 必须用 trimEnd 去掉后计算，否则换行被吞、无法判断下个括号是否在行首
    let prevCloseEnd = 0;
    // 最后一条已入列选项的括号起始位置：堆叠合并时从它整体重切片。不能用
    // "result[last] += gap + option" 拼接——那是纯空白间隙时代的写法，依赖"option 尾部被
    // trim 掉的空白恰好等于 gap"才不出错；emoji 间隙下 option 尾部带着 emoji、gap 又拼一遍，
    // 会产出 "[回溯闪回]🎞️🎞️ …" 这种 emoji 重复（实测发生过）
    let lastOptStart = 0;
    for (let i = 0; i < bracketMatches.length; i++) {
      const m = bracketMatches[i];
      const start = m.index!;
      const end = i + 1 < bracketMatches.length ? bracketMatches[i + 1].index! : c.length;
      const option = c.slice(start, end).replace(/\r?\n/g, '').trim();
      // 间隙 = 上个闭合括号到本括号开头之间的文本。空白/emoji（含空串）→
      // 同一行标签堆叠，并入上一条；含换行或正文 → 新选项（保持既有跨行行为）
      const gap = c.slice(prevCloseEnd, start);
      const isTagStack = TAG_STACK_GAP_RE.test(gap);
      if (i > 0 && isTagStack && result.length > 0) {
        result[result.length - 1] = c.slice(lastOptStart, end).replace(/\r?\n/g, '').trim();
      } else if (option) {
        result.push(option);
        lastOptStart = start;
      }
      prevCloseEnd = start + m[0].trimEnd().length;
    }
    return result.slice(0, count);
  }

  // 回退：旧格式 "标题: 内容"，按行解析
  // 先按换行分割，再在每行内按 "标题: 内容" 模式拆分，处理模型将多个选项写在同一行的情况
  const lines = c
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(l => l.length > 0 && !/^<\/?\w+>$/i.test(l));
  // 标题格式：2-5 个汉字后跟 ": " 或 "： "（\s* 兼容零空格/双空格/制表符等容错）
  const titleRe = /([\u4e00-\u9fff]{2,5})[:：]\s*/g;
  // 行首 emoji 判定：v23 放开"内容开头可带 emoji"后，模型偶尔违规输出无 [标题] 的
  // emoji 行（如 "😏 提醒她：该吃饭了"）——"提醒她"命中 titleRe 会被误拆成两条。
  // 行首为 emoji 时整行保留，跳过标题拆分（纯容错，正常 "[标题]emoji 内容" 走主路径）
  const leadingEmojiRe = /^\p{Extended_Pictographic}/u;
  const result: string[] = [];
  for (const line of lines) {
    if (leadingEmojiRe.test(line)) {
      result.push(line);
      continue;
    }
    // 用 matchAll 获取所有标题匹配位置，按相邻匹配区间切片
    // 替换原有的 lastIdx 算法，解决第一个标题在 index 0 时后续选项丢失的 bug
    const matches = [...line.matchAll(titleRe)];
    if (matches.length === 0) {
      result.push(line);
      continue;
    }
    for (let i = 0; i < matches.length; i++) {
      const start = matches[i].index!;
      const end = i + 1 < matches.length ? matches[i + 1].index! : line.length;
      result.push(line.slice(start, end).trim());
    }
  }
  return result.slice(0, count);
}

// 该配置的规则/示例自由文本：用户自行书写、无固定结构、不加任何标签，AI 原样读取。
// 空串返回 ''（不注入，通用行为零变化）；非空时由调用方原样拼到候选条目之后。
const buildConfigRuleText = (config: PoolConfig | null): string => config?.rules?.trim() ?? '';

// _target 预留：调用方语义上指定生成目标楼层，当前实现始终读取最新楼层上下文
export async function generateOptions(_target: GenerateTarget): Promise<ChoiceGeneration | null> {
  if (generatorState.loading) {
    toastr.info(t`Generating options, please wait...`);
    return null;
  }
  const gs = useGlobalSettingsStore(),
    cs = useChatSettingsStore(),
    ps = usePoolSelectorStore();
  const gid = uuidv4();
  generatorState.loading = true;
  generatorState.generationId = gid;
  // controller 随入口创建：WI 排他窗口构建消息（loadWorldInfo fetch/EJS 渲染）可达秒级，
  // 此间点取消也要能 abort——此前在 API 调用前才创建，构建期取消无对象可 abort，
  // 照发请求白耗 token（cancelGeneration 只 abort 不复位，见其注释）
  genController = new AbortController();
  const signal = genController.signal;
  // 楼层身份快照：慢请求期间切聊天/删楼重编号会让 chat[messageId] 变成别的楼层，
  // 落库前比对引用拦截（见下方 isSameLayerIdentity 校验点）
  const layerIdentity = captureLayerIdentity(_target.messageId);
  const gwi = gs.settings.world_info;
  const cwi = cs.settings.world_info;
  try {
    const count = resolveCount(gs.settings.global_count_mode);
    // 抽取参数读全局 settings.generation（v35 起从 per-pool-config 收归全局）：条目池配置
    // 只管条目引用，切换池配置严禁带动生成参数（历史耦合：本处读生效池配置，切池配置
    // 分组抽取/冗余比例即跳变）。?? 兜底：v9 前古存档迁移曾 delete 过根字段，防御 undefined
    const gen = gs.settings.generation ?? GenerationSettings.parse({});
    const pool = resolvePool({
      effectivePool: ps.effectivePool,
      count,
      categoriesEnabled: gen.categories_enabled,
      shuffleFinal: gen.shuffle_final,
      pinnedOverflow: gen.pinned_overflow,
      // ?? 兜底：防御运行时被绕过 zod 的历史对象（理论上 schema default 已补 50），
      // 缺失时回退 schema 默认而非 0——静默关闭菜单模式违背本改造意图
      oversamplePct: gen.oversample_pct ?? GenerationSettings.parse({}).oversample_pct,
    });
    const pinnedCount = pool.pinned.length;
    // rule 在固定/候选两个分区都只作写作约束（v21 起不再是跳过条目的触发条件，
    // 候选条目必须全部使用），渲染不做分区差异，分区语义由提示词文本的说明承担
    const renderEntryLine = (e: PoolEntry): string => {
      let line = e.type;
      if (e.content.trim()) line += ': ' + e.content.trim();
      if (e.rule.trim()) line += ` [Rules: ${e.rule.trim()}]`;
      return line;
    };
    const poolSelectedText = pool.drawn.map(renderEntryLine).join('\n');
    // 该配置的规则/示例原文内联进候选文本（config 级，纯 opt-in）：拼在候选条目行之后，
    // 随 {{pool_selected}} 一起展开进 option_task 的 user 消息——不新增消息、不改消息序列、
    // 不加任何标签，用户自行组织内容。空配置返回 ''，poolSelected 与现在完全一致。
    const configRuleText = buildConfigRuleText(ps.effectiveConfig);
    const poolSelectedTextFull = configRuleText
      ? `${poolSelectedText}${poolSelectedText ? '\n\n' : ''}${configRuleText}`
      : poolSelectedText;
    // 读上一 AI 楼层的已生成选项 + 当前楼层既有代，供后置去重参照（只读，不作条目）。
    // prevOptions 仍填充 Ctx 以兼容用户自定义模块引用 {{prev_options}} 的情况。
    const dedupRefs: string[] = [];
    try {
      const ctx = window.SillyTavern?.getContext?.();
      const chatArr: any[] = ctx?.chat ?? [];
      for (let i = _target.messageId - 1; i >= 0; i--) {
        const m = chatArr[i];
        if (m && !m.is_user && !m.is_system) {
          const swipeId = getMessageSwipeId(i);
          const data = getMessageChoiceData(i, swipeId);
          if (!data?.generations?.length) break;
          const gens = data.generations;
          const idx = data.currentIndex ?? gens.length - 1;
          const lastGen = gens[idx];
          if (lastGen?.options?.length) {
            dedupRefs.push(...lastGen.options.map((o: { text: string }) => o.text));
          }
          break;
        }
      }
      // 同楼重新生成：当前楼层被替换的版本也纳入参照集
      const curData = getMessageChoiceData(_target.messageId, getMessageSwipeId(_target.messageId));
      const curGen = curData?.generations?.[curData.currentIndex ?? curData.generations.length - 1];
      if (curGen?.options?.length) {
        dedupRefs.push(...curGen.options.map((o: { text: string }) => o.text));
      }
    } catch {
      /* 容错：读不到则 dedupRefs 保持空数组 */
    }
    const prevOptions = dedupRefs.join('\n');
    const c: Ctx = {
      count,
      pinnedCount,
      pinned: pool.pinned.map(renderEntryLine).join('\n'),
      poolSelected: poolSelectedTextFull || 'None',
      input: '',
      // 直接取全局设置而非硬编码：buildMessages 的 augmentedCtx 会再按 isEnrich 覆盖，
      // 这里提供一致的非死值，避免误导后人（审计 A4）
      minChars: gs.settings.prompt_rules.option_min_chars,
      maxChars: gs.settings.prompt_rules.option_max_chars,
      enrichPersonStyle: '',
      optionPerson: 'third person',
      enrichPerson: 'third person',
      prevOptions,
    };
    const rules = gs.settings.prompt_rules;

    let enabledModules = gs.sortedEnabledModules.filter(m => !m.enrich_only);
    // 全禁用兜底：静默回退全量默认模块——用户「全部关闭」的意图被无声推翻，至少明示。
    // 不改为「发空提示词」：那只会产出更离谱的回复且浪费一次请求。
    if (!enabledModules || enabledModules.length === 0) {
      toastr.warning(t`All prompt modules are disabled — generating with the default modules this time`);
      enabledModules = [...DEFAULT_MODULES].filter(m => !m.enrich_only).sort((a, b) => a.order - b.order);
    }
    // WI 排他窗口（互斥 + 即用即还，见 runWIExclWindow）：只有消息构建读取酒馆世界书，后续
    // 副 API 直连不再读——构建完成立即还原，不再持有到请求结束。此前 applyWIExcl 悬在 try 外
    // （抛错绕过 finally、loading 永久卡死），且排他态持有整个生成期（酒馆 WI 面板读到临时改写态）
    const messages = await runWIExclWindow(async () => {
      const { allExcl, enabled } = await resolveWIParticipation(gwi, cwi);
      const wiRestore = gwi.enabled
        ? await applyWIExcl(allExcl, enabled, cwi.book_entry_modes, cwi.book_entry_overrides)
        : null;
      try {
        return await buildMessages(enabledModules, c, gwi, rules.context_rounds);
      } finally {
        wiRestore?.restore();
      }
    });

    // 运行时追加指令统一出口（v61 骰式行先例）：追加到末条 user 消息，避免「system 紧随
    // user」的次序噪音；末条非 user 才另起 system。骰式标注/COC 教学行/装备卡上下文共用。
    const appendRuntimeLine = (line: string): void => {
      if (messages.length === 0) return;
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === 'user') {
        lastMsg.content += `\n\n${line}`;
      } else {
        messages.push({ role: 'system', content: line });
      }
    };

    // v61 骰式表达式（dice.allow_formula）：开启时向 option_task user 消息追加一句骰式标注
    // 指令（运行时多 token，不改用户提示词），让 AI 在相关选项上输出真实骰式。
    if (gs.settings.dice.allow_formula) {
      appendRuntimeLine(
        t`Advanced, optional: if an option involves a concrete dice check, annotate the title with the real dice expression and DC in the form [title|dice|DC] (e.g. [Attack|2d6+3|70]); options without checks keep the original format.`,
      );
    }

    // v67 COC 判定方向教学（dice.low_roll）：core_rules 默认教的是难度制「越难标得越高」，
    // low 模式语义相反（第三段=能力值，越有把握标得越高；掷 ≤ 需求值成功），且档位兜底已按
    // 100−v 对偶（见 option-format.gradeFallbackRate）——不追加这句 AI 会按难度制标注，
    // low 模式下难度整体反转。同骰式行：运行时追加，不改用户提示词。
    if (gs.settings.dice.enabled && gs.settings.dice.low_roll) {
      appendRuntimeLine(
        t`Check direction (COC percentile, overrides the "harder = higher DC" note above): the third title segment is the ability/skill level needed (0–100); roll ≤ DC to succeed — the higher the demand on ability, the lower the value; the more confident, the higher.`,
      );
    }

    // v67 卡牌上下文告知（card_enabled + 骰子开且非骰式，口径与卡判定路径一致）：让生成端
    // 知道玩家装备了什么卡、卡的发动面长什么样，AI 可在候选的题材/难度上自然呼应——卡与
    // 选项从单向触发（卡等选项）变为双向配合。只告知不强制，防纯对话轮逼出不自然选项。
    if (gs.settings.card_enabled && gs.settings.dice.enabled && !gs.settings.dice.allow_formula) {
      const cardLine = equippedCardsPromptLine();
      if (cardLine) appendRuntimeLine(cardLine);
    }

    const api = resolveCustomApi(gs.settings.active_api_id, gs.settings.apis);
    if (!api) {
      toastr.error(t`Please configure an API (URL + model) in Settings first, then regenerate`);
      return null;
    }

    // 取消早退：构建完成后、发请求前再查一次（controller 已在入口创建，abort 已生效）
    if (cancelled) return null;

    const raw = await callSecondaryApiWithRetry(
      messages,
      api,
      gs.settings.retry_count,
      gs.settings.retry_interval,
      signal,
    );
    if (cancelled) return null;
    const parsed = parseOptions(raw, count).map(t => ({ text: t, sourceEntryId: null }));
    if (!parsed.length) {
      toastr.error(t`Could not parse any options. Check model output.`);
      return null;
    }
    let options: ChoiceOption[] = parsed;
    const genCfg = gs.settings.generation;
    if (genCfg.dedup_enabled) {
      const r1 = dedupOptions(
        parsed.map(o => o.text),
        dedupRefs,
        genCfg.dedup_threshold,
      );
      let kept = r1.kept;
      let dropped = r1.droppedCount;
      let details = r1.details;
      let refilled = false;
      // 累计解析数：refill 剔除比例的分母用累计值——旧实现固定用首批 parsed.length，
      // 分母不随轮次增长使比例单调虚高、refill 提前放弃
      let totalParsed = parsed.length;
      // refill 循环：直到凑够 count 条或 refill 无新产出为止，防止最终数量不足。
      // 上限 2 轮防模型持续返回重复内容导致死循环。
      let refillRound = 0;
      const MAX_REFILL_ROUNDS = 2;
      while (kept.length < count && refillRound < MAX_REFILL_ROUNDS) {
        refillRound++;
        // 若累计剔除比例 > 60%，说明模型可能整体重复，停止 refill
        if (dropped / totalParsed > 0.6) break;
        refilled = true;
        const need = count - kept.length;
        const refillMessages: ChatMsg[] = [
          ...messages,
          { role: 'assistant', content: raw },
          {
            role: 'user',
            // 剔除数用当前累计值（dropped），首轮后恒等 r1 数字会与实际不符；
            // dropped 含同批内互相重复（dedupOptions 批内互重），措辞勿只提「此前选项」
            content: `Among the above <options> ${dropped} Duplicate options have been eliminated (including duplicates with previous options and within the same batch). Please reproduce it exactly ${need} A new action option must not be repeated with the given option and the previous direction; the format, person, and scene anchoring requirements remain unchanged, first <thinking> and then <options>.`,
          },
        ];
        lastBuildMessages.value = structuredClone(refillMessages);
        const refillRaw = await callSecondaryApiWithRetry(
          refillMessages,
          api,
          gs.settings.retry_count,
          gs.settings.retry_interval,
          signal,
        );
        if (cancelled) return null;
        const refillParsed = parseOptions(refillRaw, need).map(t => ({ text: t, sourceEntryId: null }));
        totalParsed += refillParsed.length;
        const rNext = dedupOptions(
          refillParsed.map(o => o.text),
          [...dedupRefs, ...kept],
          genCfg.dedup_threshold,
        );
        dropped += rNext.droppedCount;
        details = details.concat(rNext.details);
        kept = kept.concat(rNext.kept);
        // 若本次 refill 解析为空或去重后无新条目，停止循环，避免无限请求。
        if (!refillParsed.length || !rNext.kept.length) break;
      }
      options = kept.slice(0, count).map(t => ({ text: t, sourceEntryId: null }));
      lastDedupReport.value = {
        dropped,
        refilled,
        details,
        threshold: genCfg.dedup_threshold,
        refs: dedupRefs,
      };
      if (dropped > 0) {
        toastr.warning(t`Cull ${dropped} Duplicate options have been completed ${kept.length - r1.kept.length} entries`);
      }
    }
    if (!options.length) {
      toastr.error(t`Could not parse any options. Check model output.`);
      return null;
    }
    // 本轮实际进入候选菜单的池条目 id 集合（固定必发 pinned + 抽签 drawn）：随消息持久化，
    // 供条目级统计/智能权重分析。此前只记 pool.drawn 漏掉 pinned——pinned 同样注入提示词
    // 参与生成，漏记会让「参与数」与发给 AI 的候选不一致（选项是 AI 自由文本，只能记轮次
    // 级集合做整轮归因，无法逐项映射到单条）。pool.pinned 已含 pinned_overflow 截断后的最终集。
    // 单一来源 roundEntries：poolEntryIds（统计口径）与 matchSignals（精确归因候选）
    // 同源派生，新增候选来源时只改一处，避免统计与匹配静默失配
    const roundEntries = [...pool.drawn, ...pool.pinned];
    const poolEntryIds = roundEntries.map(e => e.id);
    // 精确归因（v53）：对最终保留的每条选项与当轮候选条目（含 pinned）做文本匹配，
    // 结果写入 option.matchedEntryId 随消息持久化——统计「命中」只记匹配条目，
    // 被 AI 舍弃的候选不产生命中；匹配不上的选项（AI 自由发挥）为 null。
    // 候选信号预计算一次（bigram 集合复用），前缀匹配按最长 type 优先
    const matchSignals = prepareMatchSignals(roundEntries);
    // 全部选项均按 type 前缀精确命中 = Dice 已高置信、AI 语义纠偏空间趋零：
    // 作为 L1 归因的前置快检信号（enqueue 据此跳过外部请求，省成本）。
    // 任一选项走 Dice 兜底或未匹配（AI 自由发挥），语义归属仍存疑 → 需要 AI 复核。
    let allPrefixMatched = options.length > 0;
    for (const o of options) {
      const m = matchOptionToEntry(o.text, matchSignals, OPTION_MATCH_THRESHOLD);
      o.matchedEntryId = m?.id ?? null;
      if (m?.via !== 'prefix') allPrefixMatched = false;
    }
    // 生成时的统计维度：命中回写优先归到本维度，防止切 config 后回看旧楼层记错 scope
    const scopeId = usePoolSelectorStore().effectiveConfig?.id ?? NONE_SCOPE;
    const generation: ChoiceGeneration = {
      id: gid,
      timestamp: Date.now(),
      count,
      options,
      poolEntryIds,
      scopeId,
    };
    // 跨聊天防护：身份不符（切聊天/删楼重编号）整体丢弃——统计记账、L1 入队与消息落库
    // 必须同进同退，否则统计已记、结果写进别家楼层的单侧分裂
    if (!isSameLayerIdentity(layerIdentity, _target.messageId)) {
      toastr.info(t`Chat switched — these generated options were discarded`);
      return null;
    }
    // 新手引导第 8 步"去生成第一组选项"的完成信号：只在选项生成成功时置位，
    // 润色（enrich-input）不算——引导验证的是主链路
    lastOptionsGeneratedAt.value = Date.now();
    // 统计口径：仅行动选项生成成功（实际保留条数）计数，润色/条目生成不计入。
    // 与 lastOptionsGeneratedAt 同处成功路径，失败/取消/空解析不会走到这里；
    // poolEntryIds 与 generation 同源，轮次共现归因到当轮全部参与条目；
    // gid 写入窗口记录供命中回写 hit，count 由 options.length 推导期望基线；
    // scopeId 传入生成时维度（与 generation.scopeId 同源），统计层不再二次解析
    recordOptionsGenerated(options, poolEntryIds, gid, scopeId);
    // L1 AI 归因增强：生成成功后异步入队（fire-and-forget，不进关键路径）。开关关/无 API
    // 时 enqueue 内部 no-op；失败静默保留 Dice 结果——主体功能对 AI 零依赖。
    // allPrefixMatched=true 时整轮前缀高置信命中，enqueue 直接跳过（省一次外部请求）。
    enqueueAttributionAnalysis(generation, _target.messageId, _target.swipeId, allPrefixMatched);
    return generation;
  } catch (e) {
    if (cancelled) return null;
    console.error('Choice generation failed', e);
    toastr.error(t`Options generation failed:${e instanceof Error ? e.message : String(e)}`);
    return null;
  } finally {
    cancelled = false;
    genController = null;
    generatorState.loading = false;
    generatorState.generationId = null;
  }
}

export function cancelGeneration() {
  // 无生成时调用不留毒标志：cancelled 复位只发生在生成运行的 finally，若导出函数在
  // 空闲期被置位（当前调用方均有 isGenerating 守卫，防御未来新增调用点），下一次生成
  // 会在请求发起前与流式读取等取消检查点被静默丢弃且无任何提示。abort 空转无害。
  if (!generatorState.loading) return;
  cancelled = true;
  genController?.abort();
  // 不复位 generatorState/genController：abort 触发的旧生成 finally 在微任务中
  // 紧随执行并负责复位。若在此同步清空，会打开「取消 → 立即重新生成」竞态窗口——
  // 旧 finally 晚于新生成同步段运行时，会把新代的 loading/controller/代 id 覆盖掉
  //（新生成实际在跑但按钮态错乱、取消失效）。复位延迟一帧（<16ms）无感知。
}
