/**
 * 卡牌系统核心（纯逻辑 + 轻 store 交互）：触发匹配、判定管线集成、开卡包/行动币等
 * 全部卡牌操作的共享层。卡定义/卡组解析簇（cardDefById/resolveEquippedCards/autoDeckCards 等）
 * 已拆至 cards-deck.ts（v67：generator 需要装备卡摘要做生成端注入，直接 import 本模块会经
 * cards-ai 成环），本模块 import 后 re-export 公开面，既有消费方 import 点零改动。
 *
 * 判定管线集成（option-action.ts 调用）：
 *   resolveCardRoll 在既有 D100 判定路径上叠加卡效果——预掷效果（roll_bonus 改骰值、
 *   demand_mod 改需求、crit_window 改彩蛋窗口，数值经 cards-constraints clamp）在掷骰前
 *   施加（掷前触发卡）；后置分两遍：掷后触发卡的修正型效果先补算到已掷骰值/需求/窗口上
 *   并重判结局（武器系「roll 触发 + 骰值加成」的低骰补力即此语义），再按最终结局施加
 *   outcome_convert 结局转化、reroll 强制重掷。触发条件
 *  （type/grade/demand 前置可知，roll/outcome 掷后可知）决定卡是否触发。
 *
 * 关键分层：卡效果**只走 card_enabled=true 分支**；card_enabled=false（默认）时本模块
 * 的判定集成完全跳过，option-action 走与现状一致的路径——存量升级零行为变化。
 *
 * 游戏进度（货币/收藏/卡组/角色池/卡定义）直接读写 gs.settings 的 GlobalSettings
 * 字段，属「配置/进度层」；「清空统计」不清它们。仅统计读数（触发/收支等）走
 * core/stats.ts 的 recordCard* 函数（stats_enabled 门控）。
 */

import { BUILTIN_CARDS } from '@/core/cards-builtin';
// 静态导入（勿改回动态 import）：CardCollection.vue 等组件层已静态消费 cards-ai，单 chunk
// 构建下动态导入既不分包也不延迟求值，只会留下 vite「dynamic + static 混合」告警；
// cards-ai 不反向依赖本模块，无循环风险
import { generateCharacterPool } from '@/core/cards-ai';
import { CARD_OUTCOME_LABEL, effectSummary } from '@/core/cards-meta';
// 卡定义/卡组解析簇已拆至 cards-deck.ts（头部注释说明拆分动机），本模块消费并 re-export，
// 既有组件/共享层的 import 点零改动
import {
  autoDeckCards,
  cardDefById,
  currentCardConfigId,
  normalizeDeckSlots,
  resolveDeckSlots,
  resolveEquippedCards,
  type EquippedCard,
} from '@/core/cards-deck';
import { useGlobalSettingsStore } from '@/store/global-settings';
import { parkedCardPack } from '@/core/card-pack-state';
import toastr from 'toastr';
import { resolveCustomApi } from '@/core/api-client';
import { getStCharacter } from '@/core/st-character';
import { parseOptionStyle, parseOptionType, type OptionStyleGrade } from '@/util/option-format';
import { resolveOptionSuccessRateWithAttr } from '@/core/attribute-dc';
import {
  cardMaxDurability,
  cardRepairCost,
  clampEffect,
  checkDeckBudget,
  isCardBroken,
  CARD_DUPLICATE_VALUE,
  CARD_DROP_WEIGHT,
  CARD_OUTCOME_CURRENCY,
  CARD_PACK_PRICE,
  CARD_SLOT_TYPES,
  CARD_LUCKY_NUMBER,
  CARD_LUCKY_NUMBER_LOW,
  CARD_PACK_OFFER,
  CARD_POOL_MAX_CARDS,
} from '@/core/cards-constraints';
import { diceMargin, judgeOutcome, type DiceOutcome, type DiceRollMode } from '@/core/dice';
import type { Card, CardOwned, CardTrigger, GlobalSettings } from '@/type/settings';

// 公开面透传：解析簇的既有导出名由本模块继续提供（EquippedCard 类型不透传——无外部
// 消费方，knip 会报死导出；需要时从 cards-deck 导入）
export { autoDeckCards, cardDefById, currentCardConfigId, normalizeDeckSlots, resolveDeckSlots, resolveEquippedCards };

// ── 领域类型 ─────────────────────────────────────────────────────────────

/** 触发匹配上下文：type = 选项类型（parseOptionType），grade = 风险档位，
 *  rate = 判定需求值（attr 解析后，供 demand 区间匹配）。 */
export type CardContext = { type: string; grade: OptionStyleGrade | null; rate: number };

/** 已触发卡（chip 展示 + 触发计数 + 统计共用） */
export type CardTriggeredInfo = { card: Card; summary: string };

/** 一次开卡包的单个候选（3 选 1 之一）：upgrade = 已拥有 → 选它=重复折算行动币；
 *  owned = 采样时的持有条目（供弹窗角标显示「已拥有」而非「未拥有」）。 */
export type CardOfferOption = { card: Card; upgrade: boolean; owned?: CardOwned };

/** 一次开卡包 offer（混合池按星级权重固定抽 CARD_PACK_OFFER 张）。
 *  configId 供选择落库时记统计维度。 */
export type CardOffer = {
  options: CardOfferOption[];
  configId: string;
};

/** 一次判定中的卡牌决议（随 DiceRollResult 返回）：触发卡/幸运命中/行动币收支/机制行。 */
export type CardResolution = {
  triggered: CardTriggeredInfo[];
  luckyHit: boolean;
  packOffer?: CardOffer;
  currencyDelta: number;
  narrativeLines: string[];
  /** 最终结局：commitCardRun 用其在失败分支触发"判定中招诅咒" */
  outcome: DiceOutcome;
  /** v70 本次判定中触发而耐久归零破损的卡（commitCardRun 落库时产生；调用方用于
   *  判定 chip 短提示。仅真正应用后的 commit 才填充，预览/首掷 stage 为空）。 */
  brokenCards: Array<{ card: Card; owned: CardOwned }>;
};

/** 装备位解析结果（装备 + 持有态）——类型定义随解析簇迁至 cards-deck.ts，此处已透传 */

/** 历史获得 id 集合：card_obtained（曾获得）∪ card_collection（当前持有）的并集。
 *  图鉴进度/未拥有遮盖基于它永久保留，与当前是否持有无关。 */
export function collectedCardIds(): Set<string> {
  const s = useGlobalSettingsStore().settings;
  return new Set([...Object.keys(s.card_obtained), ...Object.keys(s.card_collection)]);
}

/** 混合卡池（抽卡用）：内置全量 + 当前角色已生成主题池全量。返回去重后的完整卡定义数组。 */
export function mixedPoolCards(): Card[] {
  const gs = useGlobalSettingsStore();
  const byId = new Map<string, Card>();
  for (const c of BUILTIN_CARDS) byId.set(c.id, c);
  const charId = gs.currentCharacterId;
  const pool = charId != null ? gs.settings.card_character_pools[charId] : undefined;
  if (pool?.generated) {
    for (const cid of pool.card_ids) {
      const def = gs.settings.card_definitions[cid];
      if (def) byId.set(cid, def);
    }
  }
  return [...byId.values()];
}

// ── 触发匹配 ─────────────────────────────────────────────────────────────

/** 触发匹配纯函数：按 kind 对 (context, roll, outcome) 求值。outcome 为 null 表示
 *  掷骰前（roll/outcome 类触发此时恒 false——它们需掷后结果）。 */
export function matchTrigger(
  t: CardTrigger,
  ctx: CardContext,
  roll: number | null,
  outcome: DiceOutcome | null,
): boolean {
  switch (t.kind) {
    case 'type':
      return !!t.typeValue && ctx.type.includes(t.typeValue);
    case 'grade':
      return t.grade !== null && ctx.grade === t.grade;
    case 'demand':
      return ctx.rate >= (t.min ?? 0) && ctx.rate <= (t.max ?? Infinity);
    case 'roll':
      return roll !== null && roll >= (t.min ?? 0) && roll <= (t.max ?? Infinity);
    case 'outcome':
      return outcome !== null && t.outcome !== null && outcome === t.outcome;
  }
}

// ── 判定管线集成（resolveCardRoll） ──────────────────────────────────────

const clamp0100 = (v: number): number => Math.min(100, Math.max(1, Math.round(v)));
const rollD100 = (): number => Math.floor(Math.random() * 100) + 1;

/** 彩蛋窗口扩展（crit_window）：success_delta/fail_delta 正向 = 扩对应窗口（正值=更频繁）。
 *  high（默认）大成功窗口在 [critS,100]→扩窗需降低 critS、大失败窗口在 [1,critF]→扩窗需升高 critF；
 *  low（COC 反向）成功窗口在 [1,critS]、失败窗口在 [critF,100]，方向相反。 */
const applyCritWindow = (
  critS: number,
  critF: number,
  sd: number,
  fd: number,
  mode: DiceRollMode,
): { critS: number; critF: number } => ({
  critS: clamp0100(mode === 'low' ? critS + sd : critS - sd),
  critF: clamp0100(mode === 'high' ? critF + fd : critF - fd),
});

/** 解析触发上下文（供 type/grade/demand 匹配）：type/grade 走 option-format，
 *  rate 走 attr 解析（与骰子判定同一口径）。rate 为 null 时不走卡判定（无需求值）。 */
export function buildCardContext(
  optionText: string,
  character: { data?: unknown } | undefined,
  attrEnabled: boolean,
  lowRoll: boolean,
): CardContext | null {
  const rate = resolveOptionSuccessRateWithAttr(optionText, character, attrEnabled, lowRoll);
  if (rate === null) return null;
  return { type: parseOptionType(optionText), grade: parseOptionStyle(optionText), rate };
}

/** 点选前触发预览（选项行提示用）：只匹配掷前可知的触发（type/grade/demand）——
 *  roll/outcome 两类需掷后结果，天然不命中（matchTrigger 的 null 守卫）。纯读不改状态
 *  （不发放 starter、不落库）。供主面板与悬浮球选项行共用；措辞按「可触发」，
 *  因 demand 区间依赖最终 attr 解析口径，非 100% 保证触发。
 *  与判定路径同门控：骰子关闭或骰式（allow_formula）时点选不走卡判定，
 *  此时预告即为永不触发的谎言，直接返回空。楼层已结算由调用方把守（需 message 标识）。 */
export function previewTriggeredCards(
  optionText: string,
  character: { data?: unknown } | undefined,
  dice: { attr_dc_enabled: boolean; low_roll: boolean },
): Card[] {
  const gs = useGlobalSettingsStore();
  if (!gs.settings.card_enabled) return [];
  if (!gs.settings.dice.enabled || gs.settings.dice.allow_formula) return [];
  const equipped = resolveEquippedCards(currentCardConfigId());
  if (equipped.length === 0) return [];
  const ctx = buildCardContext(optionText, character, dice.attr_dc_enabled, dice.low_roll);
  if (ctx === null) return [];
  return equipped
    .filter(eq => {
      const t = eq.card.trigger;
      return (t.kind === 'type' || t.kind === 'grade' || t.kind === 'demand') && matchTrigger(t, ctx, null, null);
    })
    .map(eq => eq.card);
}

/** 抽卡随机：按星级权重取 1 张（CARD_DROP_WEIGHT）。 */
function pickWeighted(pool: Card[]): Card {
  const total = pool.reduce((s, c) => s + CARD_DROP_WEIGHT[c.star], 0);
  let r = Math.random() * total;
  for (const c of pool) {
    r -= CARD_DROP_WEIGHT[c.star];
    if (r <= 0) return c;
  }
  return pool[pool.length - 1];
}

/** 抽 1 张不重复候选（避免同包内重复 id）。 */
function pickDistinct(pool: Card[], exclude: Set<string>): Card | null {
  const candidates = pool.filter(c => !exclude.has(c.id));
  if (candidates.length === 0) return null;
  return pickWeighted(candidates);
}

/** 混合池 3 选 1 开卡包：按星级权重抽固定 CARD_PACK_OFFER 张不重复候选；已拥有卡转「重复折算」。
 *  纯采样不改状态——实际落库由 applyPackSelection 完成。 */
export function samplePackOffer(configId: string): CardOffer {
  const gs = useGlobalSettingsStore();
  const pool = mixedPoolCards();
  const n = CARD_PACK_OFFER;
  const options: CardOfferOption[] = [];
  const exclude = new Set<string>();
  for (let i = 0; i < n; i++) {
    const c = pickDistinct(pool, exclude);
    if (!c) break;
    exclude.add(c.id);
    const owned = gs.settings.card_collection[c.id];
    options.push({ card: c, upgrade: !!owned, owned });
  }
  return { options, configId };
}

/** 判定主入口（card_enabled=true 分支）：叠加卡效果完成一次 D100 判定并返回扩展结果。
 *  除开头 ensureStarterCards 的一次性幂等发放（预览路径同样会触发，无害）外不改持久状态
 *  （货币/开包都在 commitCardRun 统一落库）——使就地重掷两步流的「预览」不记账，
 *  只有真正应用时才 commit。返回 null 表示无需求值（与既有判定一致，不掷骰）。 */
export function resolveCardRoll(
  optionText: string,
  character: { data?: unknown } | undefined,
  dice: {
    attr_dc_enabled: boolean;
    low_roll: boolean;
    crit_success_min: number;
    crit_fail_max: number;
    low_roll_crit_success_max: number;
    low_roll_crit_fail_min: number;
  },
  cardEnabled: boolean,
): {
  outcome: DiceOutcome;
  roll: number;
  rate: number;
  margin: number;
  mode: DiceRollMode;
  cards?: CardResolution;
} | null {
  const configId = currentCardConfigId();
  if (cardEnabled) ensureStarterCards();
  const equipped = cardEnabled ? resolveEquippedCards(configId) : [];
  const mode: DiceRollMode = dice.low_roll ? 'low' : 'high';
  const crits = dice.low_roll
    ? { success: dice.low_roll_crit_success_max, fail: dice.low_roll_crit_fail_min }
    : { success: dice.crit_success_min, fail: dice.crit_fail_max };
  const ctx = buildCardContext(optionText, character, dice.attr_dc_enabled, dice.low_roll);
  if (ctx === null) return null;

  let rate = ctx.rate;
  let critS = crits.success;
  let critF = crits.fail;
  let rollBonus = 0;
  // 数值效果极性约定（两模式一致）：正 roll_bonus = 利好、正 demand_mod = 代价。
  // low 模式成功 = roll ≤ 需求：利好 = 降骰/升需求，故施加前按判定方向取反
  // （crit_window 的 applyCritWindow 本就模式感知，这里补齐 roll_bonus/demand_mod 同等待遇）。
  // 卡面 effectSummary 展示的是设计原值；机制行 note 展示实际施加方向（含前后值）。
  const modeSign = mode === 'low' ? -1 : 1;
  const preFired: EquippedCard[] = [];
  // 每张触发卡的效果摘要（v67 机制行的素材）：有前后值的补「（前→后）」，
  // 正文 AI 才能理解数值因果；掷前触发卡还没掷骰，只列效果本身。
  const effectNotes = new Map<EquippedCard, string[]>();
  const note = (eq: EquippedCard, s: string): void => {
    const arr = effectNotes.get(eq) ?? [];
    arr.push(s);
    effectNotes.set(eq, arr);
  };
  const signed = (n: number): string => `${n >= 0 ? '+' : ''}${n}`;

  // ── 预掷效果（触发条件前置可知：type/grade/demand） ─────────────────
  for (const eq of equipped) {
    const t = eq.card.trigger;
    if (t.kind === 'type' || t.kind === 'grade' || t.kind === 'demand') {
      if (!matchTrigger(t, ctx, null, null)) continue;
      preFired.push(eq);
      for (const raw of eq.card.effects) {
        const eff = clampEffect(raw);
        if (!eff) continue;
        if (eff.kind === 'roll_bonus') {
          rollBonus += eff.amount * modeSign;
          note(eq, `die value${signed(eff.amount * modeSign)}`);
        } else if (eff.kind === 'demand_mod') {
          const before = rate;
          rate = clamp0100(rate + eff.amount * modeSign);
          note(eq, `demand${signed(eff.amount * modeSign)}（${before}→${rate}）`);
        } else if (eff.kind === 'crit_window') {
          ({ critS, critF } = applyCritWindow(critS, critF, eff.success_delta, eff.fail_delta, mode));
          note(eq, effectSummary(eff));
        }
      }
    }
  }

  // ── 掷骰 ──────────────────────────────────────────────────────────────
  const rawRoll = rollD100();
  let roll = clamp0100(rawRoll + rollBonus);
  let outcome = judgeOutcome(roll, rate, critS, critF, mode);

  // ── 后置触发卡收集（按初始骰值/结局匹配，不因后续补算重匹配） ─────────
  const postFired: EquippedCard[] = [];
  for (const eq of equipped) {
    if (preFired.includes(eq)) continue;
    const t = eq.card.trigger;
    if ((t.kind === 'roll' || t.kind === 'outcome') && matchTrigger(t, ctx, roll, outcome)) {
      postFired.push(eq);
    }
  }
  const fired = [...preFired, ...postFired];

  // ── 后置一遍：掷后触发卡的修正型效果补算重判（武器系「低骰补力」语义） ─
  // roll_bonus/demand_mod/crit_window 在掷后补到已掷结果上再判一次；无补算则不重判，
  // 避免无意义重算。
  let postRollBonus = 0;
  let postModified = false;
  for (const eq of postFired) {
    for (const raw of eq.card.effects) {
      const eff = clampEffect(raw);
      if (!eff) continue;
      if (eff.kind === 'roll_bonus') {
        const before = roll;
        postRollBonus += eff.amount * modeSign;
        roll = clamp0100(roll + eff.amount * modeSign);
        note(eq, `die value${signed(eff.amount * modeSign)}（${before}→${roll}）`);
        postModified = true;
      } else if (eff.kind === 'demand_mod') {
        const before = rate;
        rate = clamp0100(rate + eff.amount * modeSign);
        note(eq, `demand${signed(eff.amount * modeSign)}（${before}→${rate}）`);
        postModified = true;
      } else if (eff.kind === 'crit_window') {
        ({ critS, critF } = applyCritWindow(critS, critF, eff.success_delta, eff.fail_delta, mode));
        note(eq, effectSummary(eff));
        postModified = true;
      }
    }
  }
  if (postModified) outcome = judgeOutcome(roll, rate, critS, critF, mode);

  // ── 后置二遍：转化/重掷/机制行收集（按槽序、按当时结局匹配；上面的重判可能已
  //  改变 outcome，outcome 触发卡的转化条件沿此顺序依赖，与既有语义一致） ─
  const narrativeLines: string[] = [];
  let rerolled = false;
  let rerollRaw: number | null = null;
  for (const eq of fired) {
    for (const raw of eq.card.effects) {
      const eff = clampEffect(raw);
      if (!eff) continue;
      if (eff.kind === 'outcome_convert' && eff.from === outcome) {
        note(eq, `${CARD_OUTCOME_LABEL[eff.from]}→${CARD_OUTCOME_LABEL[eff.to]}`);
        outcome = eff.to;
      } else if (eff.kind === 'reroll' && eff.on === outcome && !rerolled) {
        rerolled = true;
        rerollRaw = rollD100();
        const prevRoll = roll;
        const rr = clamp0100(rerollRaw + rollBonus + postRollBonus);
        outcome = judgeOutcome(rr, rate, critS, critF, mode);
        roll = rr;
        note(eq, `reroll(${prevRoll}→${roll}）`);
      }
    }
  }

  // v67 机械效果机制行：触发卡的效果摘要（effectNotes 含前后值「前→后」）——
  // 所有触发卡都产出；卡面叙事/演出文案不注入正文 AI（只作卡面展示），机制行是
  // 卡在判定注释里的唯一存在。复用 narrativeLines 管线：option-action 合并进判定
  // 注释前会过 sanitizeNarrative。
  // 机制行是数值语言（「骰值+15（52→67）」），与判定注释纪律尾注「正文不得提及点数」
  // 表面冲突——统一前置一句定位语划清「机制记录仅供理解因果」的边界，弱模型才不会
  // 把数值照抄进正文或对指令自相矛盾。
  const mechanicalLines: string[] = [];
  for (const eq of fired) {
    const notes = effectNotes.get(eq);
    if (!notes || notes.length === 0) continue;
    mechanicalLines.push(`「${eq.card.name}"Start:${notes.join('、')}`);
  }
  if (mechanicalLines.length > 0) {
    narrativeLines.push('Mechanism record (for understanding cause and effect only, converted into plot performance during deduction, do not write numerical values in the text):', ...mechanicalLines);
  }

  // 满编共鸣：4 槽全装且本次有卡触发 → 小额奖励（鼓励凑满一套装备）。
  // 共鸣叙事句不再注入正文 AI（同演出行一并移除），setBonus +1 币保留照发。
  let setBonus = 0;
  if (cardEnabled && equipped.length === CARD_SLOT_TYPES.length && fired.length > 0) {
    setBonus = 1;
  }

  const margin = diceMargin(mode, roll, rate);
  // 幸运命中判原骰（不含卡牌加成，roll_bonus 不推高开包率）；low 模式取对偶极值，
  // 消除「加成凑 100」通胀与「大失败开包」两种口径失真。重掷的原骰命中同样计。
  const luckyNumber = mode === 'low' ? CARD_LUCKY_NUMBER_LOW : CARD_LUCKY_NUMBER;
  const luckyHit =
    cardEnabled && (isLuckyHit(rawRoll, luckyNumber) || (rerollRaw !== null && isLuckyHit(rerollRaw, luckyNumber)));
  const packOffer = luckyHit ? samplePackOffer(configId) : undefined;
  const currencyDelta = (cardEnabled ? CARD_OUTCOME_CURRENCY[outcome] : 0) + setBonus;

  return {
    outcome,
    roll,
    rate,
    margin,
    mode,
    cards: {
      triggered: fired.map(eq => ({ card: eq.card, summary: eq.card.effects.map(effectSummary).join('·') })),
      luckyHit,
      packOffer,
      currencyDelta,
      narrativeLines,
      outcome,
      // 破损只在 commitCardRun（真正应用落库）时产生——预览/首掷 stage 不扣耐久、不破损
      brokenCards: [],
    },
  };
}

/** 幸运数命中：原骰恰好掷中当前模式的幸运数（high=100 / low=1，见 cards-constraints）。 */
export function isLuckyHit(roll: number, luckyNumber: number): boolean {
  return roll === luckyNumber;
}

// ── 落库（应用判定结果，真正改动状态） ──────────────────────────────────

/** 把某张破损卡从所有 config 的卡组里卸下（v70 破损自动卸下）。auto 模式无存储槽位
 *  （投影自 autoDeckCards，破损后 resolveEquippedCards 自然过滤），仅手动槽需清。 */
function unequipCardFromAllDecks(cardId: string): void {
  const gs = useGlobalSettingsStore();
  for (const deck of Object.values(gs.settings.card_decks)) {
    if (!deck?.slots?.length) continue;
    let dirty = false;
    for (const slot of deck.slots) {
      if (slot.card_id === cardId) {
        slot.card_id = '';
        dirty = true;
      }
    }
    if (dirty) deck.slots = normalizeDeckSlots(deck.slots);
  }
}

/** v70 触发磨损落库：对每张触发卡扣 1 耐久，归零标记破损并从所有卡组自动卸下。
 *  只在 commitCardRun（真正应用落库的唯一入口）内调用——与楼层 cardSettled 防刷同门控：
 *  同层只扣一次、重掷确认/预览/首掷 stage 不扣。返回本次破损的卡（含卡名/持有条目）供提示。 */
function applyDurabilityLoss(resolution: Pick<CardResolution, 'triggered'>): Array<{ card: Card; owned: CardOwned }> {
  const gs = useGlobalSettingsStore();
  const broken: Array<{ card: Card; owned: CardOwned }> = [];
  for (const t of resolution.triggered) {
    const owned = gs.settings.card_collection[t.card.id];
    const card = cardDefById(t.card.id);
    if (!owned || !card) continue;
    owned.durability = Math.max(0, (owned.durability ?? 0) - 1);
    if (owned.durability <= 0) {
      owned.durability = 0;
      owned.broken = true;
      unequipCardFromAllDecks(t.card.id);
      broken.push({ card, owned });
    }
  }
  return broken;
}

/** 提交一次已应用判定：按结局收支行动币（≥0 不扣穿）、触发磨损（≤0 扣穿破损）、幸运命中开卡包。
 *  仅真正应用（发送框可用 + 行为已执行）后调用。 */
export function commitCardRun(resolution: CardResolution): CardOffer | undefined {
  const gs = useGlobalSettingsStore();
  if (!resolution) return undefined;
  // 触发计数（每张触发卡 +1，供统计页「每卡触发」榜）
  for (const t of resolution.triggered) {
    const owned = gs.settings.card_collection[t.card.id];
    if (!owned) continue;
    owned.trigger_count += 1;
    recordCardTrigger(t.card.id);
  }
  // v70 触发磨损（与 trigger_count 同门控）：归零 → 破损 + 自动卸下
  resolution.brokenCards = applyDurabilityLoss(resolution);
  if (resolution.brokenCards.length > 0) {
    for (const b of resolution.brokenCards) {
      toastr.warning(t`「${b.card.name}"The durability is exhausted and has been removed from the deck - you can repair or replace other cards on the collection page`);
    }
  }
  // 行动币收支（结局驱动；0 时失败不再减，不扣穿）
  if (resolution.currencyDelta !== 0) {
    if (resolution.currencyDelta > 0) {
      gs.settings.card_currency += resolution.currencyDelta;
    } else if (gs.settings.card_currency > 0) {
      gs.settings.card_currency = Math.max(0, gs.settings.card_currency + resolution.currencyDelta);
    }
    recordCurrencyOutcome(resolution.currencyDelta, resolution.outcome);
  }
  // 幸运命中 → 开卡包：开包统计，返回 offer 供组件弹窗
  if (resolution.luckyHit && resolution.packOffer) {
    recordPackOpened();
    recordCardLuckyHit();
    // 触发角色主题池懒生成（fire-and-forget）：本次 offer 用现有池，生成后进后续混合池
    ensureCharacterPool();
    return resolution.packOffer;
  }
  return undefined;
}

// ── 开卡包选择（幸运 / 卡牌页购买共用） ──────────────────────────────────

/** 应用一次 3 选 1 的选择：新卡 → 建 CardOwned；已拥有 → 按 CARD_DUPLICATE_VALUE 折算行动币。
 *  via：'lucky'|'shop'（shop 已扣币，仅影响统计埋点）。 */
export function applyPackSelection(offer: CardOffer, chosenIdx: number, via: 'lucky' | 'shop'): void {
  const gs = useGlobalSettingsStore();
  const opt = offer.options[chosenIdx];
  if (!opt) return;
  void via;
  acquireOrConvert(gs.settings, opt.card);
  recordCardsObtained();
}

/** 新得或折算一张卡（开卡包共用）：未拥有 → 建持有条目（满耐久）；已拥有 → 折算小额行动币
 *  （卡为永久收藏，重复获得给币让 3 选 1 始终有意义）。v70：**破损卡抽到也照常折算**——
 *  折算只给币、不刷新耐久（破损保持破损），修复经济不被开包绕开。 */
function acquireOrConvert(s: GlobalSettings, card: Card): void {
  // 历史获得记录：新得/重复抽中都累计 → 图鉴/成就/套装永久保留
  const rec = s.card_obtained[card.id] ?? { card_id: card.id, obtained_at: Date.now(), count: 0 };
  rec.count += 1;
  if (!rec.obtained_at) rec.obtained_at = Date.now();
  s.card_obtained[card.id] = rec;

  const existing = s.card_collection[card.id];
  if (existing) {
    const gain = CARD_DUPLICATE_VALUE[card.star] ?? 1;
    s.card_currency += gain;
    toastr.info(t`「${card.name}"Already owned, converted +${gain} Action Coins`);
    return;
  }
  s.card_collection[card.id] = {
    card_id: card.id,
    obtained_at: Date.now(),
    trigger_count: 0,
    durability: cardMaxDurability(card),
    max_durability: cardMaxDurability(card),
    broken: false,
    source: card.source,
  };
}

// ── 卡组编辑（CardDeckEditor 用） ────────────────────────────────────────
// 生效槽/自动编组/槽规整等解析函数已拆至 cards-deck.ts（本模块顶部 import + 透传）。

/** 新手 starter（一次性）：启用卡牌且收藏为空时赠 4 张 1★（每类型一张），auto-deck 立即满编、
 *  让首次使用即刻有卡可触发。幂等：已发放或已有收藏则跳过。
 *  在 resolveCardRoll（判定真正接入卡）与 CardPoolEditor 开启开关时调用，作为双保险。 */
export function ensureStarterCards(): void {
  const gs = useGlobalSettingsStore();
  if (!gs.settings.card_enabled || gs.settings.card_starter_granted) return;
  gs.settings.card_starter_granted = true;
  if (Object.keys(gs.settings.card_collection).length > 0) return; // 已有收藏，跳过发放
  const starterIds = ['builtin_weapon_1', 'builtin_spell_1', 'builtin_blessing_1', 'builtin_trial_1'];
  for (const id of starterIds) {
    const def = cardDefById(id);
    if (!def) continue;
    gs.settings.card_collection[id] = {
      card_id: id,
      obtained_at: Date.now(),
      trigger_count: 0,
      durability: cardMaxDurability(def),
      max_durability: cardMaxDurability(def),
      broken: false,
      source: 'builtin',
    };
    // 首次发放同样计入历史获得，保证套装/成就进度完整
    const rec = gs.settings.card_obtained[id] ?? { card_id: id, obtained_at: Date.now(), count: 0 };
    rec.count += 1;
    rec.obtained_at = rec.obtained_at || Date.now();
    gs.settings.card_obtained[id] = rec;
  }
}

/** 把一张卡装进其类型槽后，整组星级预算是否通过（纯投影，不落库）。 */
export function canEquipInDeck(configId: string, card: Card): { ok: boolean; errors: string[] } {
  const slots = resolveDeckSlots(configId);
  const projected = slots
    .map(s => (s.type === card.type ? card : cardDefById(s.card_id)))
    .filter((c): c is Card => !!c);
  return checkDeckBudget(projected);
}

/** 装备一张卡到其类型对应的固定槽位（替换该槽旧卡 + 全组星级预算校验）。返回 { ok, errors[] }。
 *  先按当前生效投影（auto=自动编组、手动=存储卡组，resolveDeckSlots 模式感知）完成
 *  「已装备/预算」校验，全部通过后才快照 auto 并落槽——失败/取消路径零副作用。此前
 *  「先切手动再校验」会让预算不过时 auto 已被静默关闭且无提示（auto 分支的切换 toast
 *  也被短路）。auto 态下校验基数与写卡后的卡组内容一致（快照=投影），顺序无行为差。 */
export function equipCard(configId: string, cardId: string): { ok: boolean; errors: string[] } {
  const gs = useGlobalSettingsStore();
  const card = cardDefById(cardId);
  const owned = gs.settings.card_collection[cardId];
  if (!card || !owned) return { ok: false, errors: ['Card does not exist or is not owned'] };
  if (isCardBroken(owned)) return { ok: false, errors: ['This card is damaged and needs to be repaired before it can be equipped'] };
  if (!CARD_SLOT_TYPES.includes(card.type)) return { ok: false, errors: ['There is no corresponding slot for this type of card'] };
  if (resolveDeckSlots(configId).some(s => s.card_id === cardId)) return { ok: false, errors: ['The card is equipped'] };
  const budget = canEquipInDeck(configId, card);
  if (!budget.ok) return budget;
  const deck = (gs.settings.card_decks[configId] ??= { config_id: configId, slots: [] });
  // 手动装备即接管：校验通过后快照 auto 编组并关开关（与卡组页 snapshotFromAuto 同语义）
  if (gs.settings.auto_deck_enabled) {
    deck.slots = autoDeckCards();
    gs.settings.auto_deck_enabled = false;
    toastr.info(t`Switched to a manual deck (re-enable auto-deck on the Deck page)`);
  }
  deck.slots = normalizeDeckSlots(deck.slots);
  const slot = deck.slots.find(s => s.type === card.type);
  if (slot) slot.card_id = cardId;
  return { ok: true, errors: [] };
}

/** 卸下一张卡：先规整槽位（历史脏数据下原始 slots 与展示口径可能不一致），再清空其所在固定槽。 */
export function unequipCard(configId: string, cardId: string): void {
  const gs = useGlobalSettingsStore();
  const deck = gs.settings.card_decks[configId];
  if (!deck) return;
  deck.slots = normalizeDeckSlots(deck.slots);
  const slot = deck.slots.find(s => s.card_id === cardId);
  if (slot) slot.card_id = '';
}

// ── 修复（v70 破损经济闭环） ─────────────────────────────────────────────

/** 修复一张破损卡：扣行动币（cardRepairCost，与卡包同量级）恢复满耐久、清破损态。
 *  未破损报「无需修复」；余额不足报错。修复是行动币支出闭环的一环（与开卡包并列），
 *  破损卡不能装备/触发，修复后才可重新入组。 */
export function repairCard(cardId: string): { ok: boolean; errors: string[]; cost?: number } {
  const gs = useGlobalSettingsStore();
  const card = cardDefById(cardId);
  const owned = gs.settings.card_collection[cardId];
  if (!card || !owned) return { ok: false, errors: ['Card does not exist or is not owned'] };
  if (!isCardBroken(owned)) return { ok: false, errors: ['「' + card.name + '"Not broken, no need to repair'] };
  const cost = cardRepairCost(card);
  if (gs.settings.card_currency < cost) {
    return { ok: false, errors: [`Insufficient action coins, need to repair ${cost} coins`] };
  }
  gs.settings.card_currency -= cost;
  owned.durability = owned.max_durability || cardMaxDurability(card);
  owned.broken = false;
  recordCurrencySpent(cost);
  toastr.success(t`「${card.name}"Repaired to full durability`);
  return { ok: true, errors: [], cost };
}

// ── 购买卡包（行动币消费出口，另一出口为 v70 破损修复） ───────────────────

/** 购买卡包：恒定 CARD_PACK_PRICE，扣币后返回 offer 立即开。 */
export function buyPack(configId: string): { ok: boolean; errors: string[]; offer?: CardOffer } {
  const gs = useGlobalSettingsStore();
  if (gs.settings.card_currency < CARD_PACK_PRICE) {
    return { ok: false, errors: [`Insufficient action coins (required ${CARD_PACK_PRICE}）`] };
  }
  gs.settings.card_currency -= CARD_PACK_PRICE;
  recordCurrencySpent(CARD_PACK_PRICE);
  // 购买开包同样计一次「开包次数」（与幸运命中开包同口径），否则统计页三数字互相矛盾
  recordPackOpened();
  // 购买开包同样触发角色主题池懒生成（幂等）：不依赖幸运数命中，本次 offer 仍用现有池，
  // 生成后进后续混合池
  ensureCharacterPool();
  return { ok: true, errors: [], offer: samplePackOffer(configId) };
}

// ── 角色主题池懒生成（§6，见 cards-ai.ts） ───────────────────────────────

/** 清空某角色的主题池及其关联卡数据（定义/收藏/历史获得）——供「重新生成」测试/换新风格用。
 *  破坏性：会删除已收集的该角色主题卡；调用方须先确认。
 *  挂起的卡包（parkedCardPack）持有的卡来自旧池：清池后卡定义已删，重开选中会让
 *  acquireOrConvert 为已无定义的卡新建收藏条目（永不掉落/展示的僵尸条目），故一并作废
 *  并明示——幸运包无成本，购买包已扣币属极端时序（先挂起再清池），toast 说明。 */
export function clearCharacterPool(charId: string): void {
  const gs = useGlobalSettingsStore();
  const pool = gs.settings.card_character_pools[charId];
  if (!pool) return;
  for (const id of pool.card_ids) {
    delete gs.settings.card_definitions[id];
    delete gs.settings.card_collection[id];
    delete gs.settings.card_obtained[id];
  }
  delete gs.settings.card_character_pools[charId];
  // 仅当挂起包的候选卡确属被清角色时才作废：其他角色的挂起包不受本次清池影响，误丢即是白扣
  const parked = parkedCardPack.value;
  if (parked && parked.offer.options.some(o => o.card.character_id === charId)) {
    parkedCardPack.value = null;
    toastr.info(t`Parked card pack discarded along with the cleared pool`);
  }
}

let poolGenRunning = false;
let poolGenPending = false;

/** 触发当前角色主题池的**分批**懒生成（fire-and-forget）：池未满（上限 CARD_POOL_MAX_CARDS）时
 *  异步调 AI 补一批（首批 CARD_POOL_FIRST_BATCH、之后每批 CARD_POOL_BATCH_SIZE，见 cards-ai.ts）。
 *  分批的意义：每批吃到触发时刻的剧情上下文（激活的绿灯世界书 + 最近聊天记录），池随剧情阶段
 *  逐步变宽，化解一次性整池生成只反映开局面导致的内容窄化。生成过程 toastr 提示（开始/成功/失败）。
 *  未配置副 API（用户未启用 AI 池，常态）/ 无当前角色 → 静默；失败回退现有池/内置池，不影响本次开卡包；
 *  生成中重复调用去重排队。 */
export function ensureCharacterPool(): void {
  const gs = useGlobalSettingsStore();
  const charId = gs.currentCharacterId;
  if (charId == null) return;
  // 未配置副 API：AI 主题池功能未启用，静默退出（不开包流程受影响，纯内置池照常）
  if (!resolveCustomApi(gs.settings.active_api_id, gs.settings.apis)) return;
  const pool = gs.settings.card_character_pools[charId];
  if ((pool?.card_ids.length ?? 0) >= CARD_POOL_MAX_CARDS) return;
  if (poolGenRunning) {
    poolGenPending = true;
    return;
  }
  poolGenRunning = true;
  void (async () => {
    try {
      const name = getStCharacter(charId)?.name ?? '';
      toastr.info(t`Working on "${name}"Generate theme card...`);
      const cards = await generateCharacterPool(charId);
      if (cards.length > 0) {
        // 卡名清单先算再插值：插值里嵌反引号模板会让运行时 i18n 键与对账提取口径错位
        const names = cards.map(c => `「${c.name}」`).join('');
        toastr.success(t`「${name}》Theme Card +${cards.length} ${names}`);
      } else {
        toastr.warning(t`「${name}"The theme card generation failed. This card opening package will use the existing pool first. It will automatically retry next time.`);
      }
    } catch {
      /* 防御兜底：generateCharacterPool 内部已全 catch，正常不会走到 */
    } finally {
      poolGenRunning = false;
      if (poolGenPending) {
        poolGenPending = false;
        ensureCharacterPool();
      }
    }
  })();
}

// ── 统计记录（stats_enabled 门控，见 core/stats.ts） ─────────────────────

import {
  recordCardTrigger,
  recordCardLuckyHit,
  recordPackOpened,
  recordCardsObtained,
  recordCurrencySpent,
  recordCurrencyOutcome,
} from '@/core/stats';
