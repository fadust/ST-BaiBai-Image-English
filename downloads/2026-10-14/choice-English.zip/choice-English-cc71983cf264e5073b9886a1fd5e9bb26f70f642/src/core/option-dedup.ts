// 生成后去重：标题判定 + 字符 bigram Jaccard，纯本地字符串运算，零 API 成本。
// 参照集 = 上一 AI 楼层当前代 ∪ 当前楼层既有代（同楼重新生成也防）。

type DedupDetail = {
  candidate: string;
  reason: 'title' | 'jaccard';
  matchedRef: string;
  score?: number;
};

type DedupResult = {
  kept: string[];
  droppedCount: number;
  details: DedupDetail[];
};

export function dedupOptions(candidates: string[], references: string[], threshold: number): DedupResult {
  // 阈值防御：非有限输入（未钳制的表单值，如 ''/NaN）兜底默认——'' 会使 titleGate=0 且
  // score>=threshold 恒真，去重「全杀」并空转补齐请求
  const t = Number.isFinite(threshold) ? Math.min(1, Math.max(0, threshold)) : 0.75;
  // 标题匹配的内容门槛 = max(0, 用户阈值 - 0.35)。默认 0.75 → 0.4，保持现状；
  // 用户调高阈值时标题门槛同步上浮，调低时标题门槛下探至 0（单靠标题即可判重）。
  const titleGate = Math.max(0, t - 0.35);
  const titleOf = (s: string): string | null => {
    const m = s.match(/^\s*[[【]([^\]】]+)[\]】]/);
    return m ? m[1] : null;
  };
  // 剥掉开头 [标题]/【标题】后返回正文：标头在开头时 search 恒返回 0，
  // 不能拿它当下标切片（slice(0) 返回含标头的整串，标头 bigram 虚增标题相同
  // 选项的 Jaccard 相似度导致误杀），必须 match 取整个匹配串再按其长度跳过
  const contentOf = (s: string): string => {
    const m = s.match(/^\s*[[【][^\]】]+[\]】]\s*/);
    return m ? s.slice(m[0].length).trim() : s.trim();
  };
  const normalize = (s: string): string => s.replace(/\s+/g, '').trim();
  const bigrams = (s: string): Set<string> => {
    const t = normalize(s);
    const out = new Set<string>();
    for (let i = 0; i < t.length - 1; i++) out.add(t.slice(i, i + 2));
    return out;
  };
  const jaccard = (a: Set<string>, b: Set<string>): number => {
    let inter = 0;
    let union = 0;
    for (const x of a) {
      union++;
      if (b.has(x)) inter++;
    }
    for (const x of b) {
      if (!a.has(x)) union++;
    }
    return union === 0 ? 0 : inter / union;
  };
  // 标题精确匹配后增加内容 bigram Jaccard 门槛（>0.4），避免 type 相同但内容不同的选项被误杀。
  const isDup = (cand: string, ref: string): { dup: boolean; detail?: DedupDetail } => {
    // 归一化全文恒等 = 完全重复：bigram 集对 1 字符内容为空集（Jaccard 恒 0），
    // 不短路会让两条完全相同的单字选项同时保留
    if (normalize(cand) !== '' && normalize(cand) === normalize(ref)) {
      return { dup: true, detail: { candidate: cand, reason: 'jaccard', matchedRef: ref, score: 1 } };
    }
    const ct = titleOf(cand);
    const rt = titleOf(ref);
    if (ct && rt && ct === rt) {
      // 标题匹配的内容门槛由用户阈值派生，保持与 UI 同步。
      const contentJaccard = jaccard(bigrams(contentOf(cand)), bigrams(contentOf(ref)));
      if (contentJaccard > titleGate) {
        return { dup: true, detail: { candidate: cand, reason: 'title', matchedRef: ref, score: contentJaccard } };
      }
    }
    const score = jaccard(bigrams(contentOf(cand)), bigrams(contentOf(ref)));
    if (score >= t) {
      return { dup: true, detail: { candidate: cand, reason: 'jaccard', matchedRef: ref, score } };
    }
    return { dup: false };
  };

  const kept: string[] = [];
  let dropped = 0;
  const details: DedupDetail[] = [];
  // 参照集 = 外部参照 + 本批已保留：AI 单次响应内的重复/近似选项（弱模型高发）此前只对
  // 批外参照查重，批内互重全部漏过（重复按钮直接进面板）。收敛在实现里，调用方无需拼
  // 已保留集（generator 的 refill 轮手动传 [...refs, ...kept] 与此兼容，仅冗余）。
  const refs = [...references];
  for (const cand of candidates) {
    let dup = false;
    let detail: DedupDetail | undefined;
    for (const ref of refs) {
      const result = isDup(cand, ref);
      if (result.dup) {
        dup = true;
        detail = result.detail;
        break;
      }
    }
    if (dup) {
      dropped++;
      if (detail) details.push(detail);
    } else {
      kept.push(cand);
      refs.push(cand);
    }
  }
  return { kept, droppedCount: dropped, details };
}
