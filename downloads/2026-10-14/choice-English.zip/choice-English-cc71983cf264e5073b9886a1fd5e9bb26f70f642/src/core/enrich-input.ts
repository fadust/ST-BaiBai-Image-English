import { callSecondaryApiWithRetry } from './api-client';
import {
  buildMessages,
  resolveCustomApi,
  applyWIExcl,
  parseOptions,
  resolveCount,
  resolveWIParticipation,
  runWIExclWindow,
} from './generator';
import type { Ctx } from './generator';
import { useGlobalSettingsStore } from '@/store/global-settings';
import { useChatSettingsStore } from '@/store/chat-settings';
import { pinia } from '@/pinia';
import { DEFAULT_MODULES } from '@/type/settings';

let enrichController: AbortController | null = null;

export function cancelEnrich() {
  enrichController?.abort();
  enrichController = null;
}

/** 调用副 API 润色用户输入，返回解析后的选项文本数组。
 *  复用 buildMessages 模块管线，包含聊天历史、世界书、角色描述等上下文。
 *  用户输入通过 {{input}} 变量在 enrich_prompt 模块中占位，由 buildMessages 自动替换。 */
export async function enrichUserInput(input: string): Promise<string[]> {
  const gs = useGlobalSettingsStore(pinia);
  const cs = useChatSettingsStore(pinia);
  const api = resolveCustomApi(gs.settings.active_api_id, gs.settings.apis);
  if (!api) {
    throw new Error('Not configured to build API');
  }

  const sourceModules = gs.sortedEnabledModules.length > 0 ? gs.sortedEnabledModules : DEFAULT_MODULES;
  let modules = sourceModules;

  // 若 enrich_prompt 模块被禁用或不存在，从 DEFAULT_MODULES 临时注入其 JSON 默认内容。
  // 不再用代码常量覆盖 content：JSON 是模块内容的单一事实源（choice-prompts-optimized.json），
  // 代码常量会让此路径回退到早已演进的旧文案，与编辑器/生成链路出现双来源漂移
  if (!modules.some(m => m.id === 'enrich_prompt')) {
    const defaultEnrich = DEFAULT_MODULES.find(m => m.id === 'enrich_prompt');
    if (defaultEnrich) {
      modules = [...modules, { ...defaultEnrich }];
    }
  }

  const enrichCount = resolveCount(gs.settings.ui.enrich_count);
  const pr = gs.settings.prompt_rules;
  const enrichCtx: Ctx = {
    count: enrichCount,
    pinnedCount: 0,
    pinned: '',
    poolSelected: '',
    input,
    minChars: pr.enrich_min_chars,
    maxChars: pr.enrich_max_chars,
    enrichPersonStyle:
      pr.enrich_person_style || (pr.enrich_person ? `Use uniformly${pr.enrich_person} {{user}} is the subject` : ''),
    optionPerson: pr.option_person || 'third person',
    enrichPerson: pr.enrich_person || 'third person',
    prevOptions: '',
  };

  const gwi = gs.settings.world_info;
  const cwi = cs.settings.world_info;

  // controller 随入口创建：WI 窗口构建消息可达秒级，此间取消也要能 abort——此前在
  // API 调用前才创建，构建期取消无对象可 abort，照发请求白耗 token（同 generateOptions）
  enrichController = new AbortController();
  const signal = enrichController.signal;

  try {
    // WI 排他窗口（互斥 + 即用即还，见 generator.runWIExclWindow）：仅消息构建读取世界书，
    // 构建完成立即还原，与选项生成/卡牌池链路并发时不再交错践踏全局 WI 状态
    const messages = await runWIExclWindow(async () => {
      const { allExcl, enabled } = await resolveWIParticipation(gwi, cwi);
      const restore = gwi.enabled
        ? await applyWIExcl(allExcl, enabled, cwi.book_entry_modes, cwi.book_entry_overrides)
        : null;
      try {
        return await buildMessages(modules, enrichCtx, gwi, gs.settings.prompt_rules.context_rounds, true);
      } finally {
        restore?.restore();
      }
    });

    const raw = await callSecondaryApiWithRetry(
      messages,
      api,
      gs.settings.retry_count,
      gs.settings.retry_interval,
      signal,
    );
    return parseOptions(raw, enrichCount);
  } catch (e) {
    // 取消（AbortError）原样上抛、不 console.error：正常路径由调用方 triggerEnrich 的
    // AbortError 分支静默处理；此前吞掉返回 [] 会让调用方把空代落库污染润色翻页
    if ((e as Error)?.name !== 'AbortError') {
      console.error('[Choice] Polishing failed', e);
    }
    throw e;
  } finally {
    enrichController = null;
  }
}
