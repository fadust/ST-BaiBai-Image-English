import defaultModulesJson from '../../choice-prompts-optimized.json';
// 显式导入 z：auto-imports.d.ts 生成的全局 const z（typeof import('zod').z）在类型位置
// 无法当命名空间用（z.infer 报 TS2503，且该文件被 gitignore 随时重生成），不能用
import { z } from 'zod';

export const setting_field = 'choice';

// 字数上下限与各字段默认值——schema 的 .min/.max/.default/.catch、加载预迁移 clamp、
// watcher 落盘前 sanitize、前端 input 钳制四处共用，禁止各自硬编码 10/500。
// 为什么必须集中：历史上 schema 用 .min(10) 对"已存在的非法值"fail-closed（.default 只补
// 缺失字段、不补非法值），用户在 UI 输入 <10 经无校验 watcher 落盘后，下次加载即整扩展崩溃。
const CHARS_MIN_LIMIT = 10;
const CHARS_MAX_LIMIT = 500;
export const OPTION_MIN_CHARS_DEFAULT = 10;
export const OPTION_MAX_CHARS_DEFAULT = 60;
export const ENRICH_MIN_CHARS_DEFAULT = 10;
export const ENRICH_MAX_CHARS_DEFAULT = 60;

// 把字数字段值钳到合法区间 [CHARS_MIN_LIMIT, CHARS_MAX_LIMIT]，非有限数回落 dft。
// 加载预迁移 / watcher 落盘前 / 前端 input 三处复用，单一真相源防各处 10/500 漂移。
export function clampCharsValue(v: unknown, dft: number): number {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? Math.min(CHARS_MAX_LIMIT, Math.max(CHARS_MIN_LIMIT, n)) : dft;
}

// 就地把 prompt_rules 的 4 个字数字段钳到合法区间并保证 min<=max。
// 加载预迁移（validateInplace 前）与 watcher 落盘前共用：确保任何路径读入/落盘的值都合法，
// 从根上杜绝单个非法字段让整档 zod parse 失败、整扩展崩溃（fail-safe）。
export function sanitizePromptRulesChars(pr: unknown): void {
  if (!pr || typeof pr !== 'object') return;
  const o = pr as Record<string, unknown>;
  const lo1 = clampCharsValue(o.option_min_chars, OPTION_MIN_CHARS_DEFAULT);
  const hi1 = clampCharsValue(o.option_max_chars, OPTION_MAX_CHARS_DEFAULT);
  const lo2 = clampCharsValue(o.enrich_min_chars, ENRICH_MIN_CHARS_DEFAULT);
  const hi2 = clampCharsValue(o.enrich_max_chars, ENRICH_MAX_CHARS_DEFAULT);
  o.option_min_chars = lo1;
  o.option_max_chars = lo1 > hi1 ? lo1 : hi1;
  o.enrich_min_chars = lo2;
  o.enrich_max_chars = lo2 > hi2 ? lo2 : hi2;
}

export const PoolEntry = z
  .object({
    id: z.string(),
    type: z.string(),
    content: z.string().default(''),
    // v20 删除了 condition 字段：原设计是客户端变量表达式过滤，实际早已退化为发给 AI 的
    // 自由文本提示，与 rule 的"适用时机"语义完全重叠；旧存档里的 condition 键由 zod 剥离
    rule: z.string().default(''),
    pinned: z.boolean().default(false),
    weight: z.number().min(0).default(1).catch(1),
    category: z.string().default(''),
  })
  // zod4 的 prefault 参数类型是输入类型：PoolEntry 的 id/type 无 default（必填），
  // 空对象不满足签名；占位值仅在输入为 undefined 的极端路径触发，正常条目不受影响
  .prefault(() => ({ id: '', type: '' }));
export type PoolEntry = z.infer<typeof PoolEntry>;

export const GenerationSettings = z
  .object({
    count_mode: z.string().default('4'),
    categories_enabled: z.boolean().default(true),
    shuffle_final: z.boolean().default(true),
    pinned_overflow: z.enum(['send_all', 'trim']).default('send_all'),
    // 菜单模式超采样：非固定条目抽样量 = 所需数 + ceil(所需数 × pct/100)。
    // 0 = 关闭菜单模式（抽取数=所需数，精确 1:1，等同 v23 前行为）；上限 300 防误输入巨值。
    // 老存档靠 zod default 自动补 50，无需显式迁移
    oversample_pct: z.number().min(0).max(300).default(50).catch(50),
    // 生成后反重复：提示词不再注入上一轮选项（防污染），改由后置去重兜底。
    // 参照集 = 上一 AI 楼层当前代 ∪ 当前楼层既有代（覆盖同楼重新生成）。
    dedup_enabled: z.boolean().default(true),
    // 0-1 的 bigram Jaccard 阈值；NaN 由 .catch 兜底（同 oversample_pct 先例），不加 min/max clamp（项目约束：不改写用户输入）。
    dedup_threshold: z.number().default(0.75).catch(0.75),
  })
  .prefault({});
export type GenerationSettings = z.infer<typeof GenerationSettings>;

export const PoolConfigEntry = z
  .object({
    entry_id: z.string(),
    pinned: z.boolean().default(false),
    weight: z.number().min(0).default(1).catch(1),
    // 配置层停用开关：false = 条目保留在配置中但不参与生成（在 pool-selector 解析层剔除，
    // 抽取算法无感知）。与 pinned 的 checkbox 用不同控件（滑动开关），避免两种"勾选"语义混淆。
    // 老存档缺字段由 default(true) 自动补齐（同 panel_lock 先例），无需 bump schema_version
    enabled: z.boolean().default(true),
    // v20 删除了 condition 字段：条件职责并入条目库层 rule（v21 起作为写作约束，不作为选用门槛），
    // 配置层不再单独设条件；旧存档里的 condition 键由 zod 剥离
  })
  .prefault(() => ({ entry_id: '' }));
export type PoolConfigEntry = z.infer<typeof PoolConfigEntry>;

export const PoolConfig = z
  .object({
    id: z.string(),
    name: z.string(),
    entries: z.array(PoolConfigEntry),
    is_default: z.boolean().default(false),
    /** 该配置的规则/示例自由文本（可空）：用户按需求或角色卡自行书写、无固定结构、不加任何标签，
     *  AI 原样读取其内容。仅按需配置：空串 = 不注入，现有通用行为零变化。老存档由 default('') 补齐。 */
    rules: z.string().default(''),
    /** @deprecated v35 起抽取参数（分组抽取/打乱/固定溢出/冗余比例）收归全局
     *  GlobalSettings.generation——条目池配置收敛为"纯条目引用清单"，切换池配置严禁带动
     *  任何生成参数（历史上生成设置页冗余比例读生效池配置，切池配置即跳变）。本字段仅为
     *  旧存档兼容保留的死数据，消费端一律读全局 settings.generation，严禁新增读取。 */
    generation: GenerationSettings.prefault({}),
  })
  .prefault(() => ({ id: '', name: '', entries: [] }));
export type PoolConfig = z.infer<typeof PoolConfig>;

/** 自动化应用历史条目（GlobalSettings.apply_history 的元素）：
 *  记录一次「建议应用」或「阵容计划应用」对受影响条目的前后局部快照
 *  （entries_before/entries_after 只含本批实际改写的条目 id，非 config.entries 全量——
 *  全量快照在大池下会让历史体积随条目数膨胀，而撤销/摘要只依赖受影响集），
 *  供持久多槽撤销（undoLastApply）与后续「变更前后对照」（D 铺路）。
 *  只对具体 config 产生（建议/阵容应用均要求 canApply），scope_id 必为 config.id。 */
export const ApplyHistoryEntry = z.object({
  id: z.string(),
  /** 目标 config.id */
  scope_id: z.string(),
  /** 批次来源：suggestions = 建议引擎应用，roster = 阵容计划应用 */
  kind: z.enum(['suggestions', 'roster']),
  /** 应用时间戳（Date.now） */
  ts: z.number().default(0),
  /** 应用前受影响条目的局部快照（undo 恢复依据；未受影响条目不入快照） */
  entries_before: z.array(PoolConfigEntry).prefault([]),
  /** 应用后受影响条目的局部快照（D 铺路：变更对照/展示用） */
  entries_after: z.array(PoolConfigEntry).prefault([]),
  /** 受影响条目应用前的 last_weight_changed_at（undo 连带回滚冷却标记，
   *  避免「撤销后条目被冷却卡住无法再建议」） */
  markers_before: z.record(z.string(), z.number()).prefault({}),
});
export type ApplyHistoryEntry = z.infer<typeof ApplyHistoryEntry>;

/** 润色人称默认值。选项提示词不再有隐藏的 person_style/option_rules 双来源。 */
export const DEFAULT_ENRICH_PERSON_STYLE = 'Use {{enrich_person}} {{user}} as the main subject uniformly';

/** 选项/润色人称默认值（PromptConfig 与 PromptRules 共用，勿两处各自硬编码） */
const DEFAULT_OPTION_PERSON = 'third person';

export const PromptModule = z.object({
  id: z.string(),
  name: z.string(),
  role: z.enum(['system', 'user', 'assistant']),
  content: z.string().default(''),
  marker: z.boolean(),
  system: z.boolean(),
  enabled: z.boolean().default(true),
  order: z.number().min(0),
  enrich_only: z.boolean().default(false),
  option_only: z.boolean().default(false),
});
export type PromptModule = z.infer<typeof PromptModule>;

export const PromptConfig = z
  .object({
    id: z.string(),
    name: z.string(),
    is_default: z.boolean().default(false),
    modules: z.array(PromptModule).prefault([]),
    /** @deprecated v35 起生成侧标量（人称/字数/轮数/预填充/柏宝书）不随配置切换。
     *  历史配置仍可能带这些字段，但当前运行时不再读取或写入。 */
    option_person: z.string().default(DEFAULT_OPTION_PERSON),
    enrich_person: z.string().default(DEFAULT_OPTION_PERSON),
    enrich_person_style: z.string().default(DEFAULT_ENRICH_PERSON_STYLE),
    option_min_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(OPTION_MIN_CHARS_DEFAULT)
      .catch(OPTION_MIN_CHARS_DEFAULT),
    option_max_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(OPTION_MAX_CHARS_DEFAULT)
      .catch(OPTION_MAX_CHARS_DEFAULT),
    enrich_min_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(ENRICH_MIN_CHARS_DEFAULT)
      .catch(ENRICH_MIN_CHARS_DEFAULT),
    enrich_max_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(ENRICH_MAX_CHARS_DEFAULT)
      .catch(ENRICH_MAX_CHARS_DEFAULT),
    context_rounds: z.number().min(0).default(10).catch(10),
    context_mode: z.enum(['rounds', 'visible_only']).default('visible_only'),
    baibai_enabled: z.boolean().default(false),
    shujuku_enabled: z.boolean().default(false),
    /** @deprecated v44 起不再有写入方：「全向」配置已随轻型默认预设重构删除，
     *  本字段仅为旧存档兼容保留的死数据（老档中 builtin:'open' 的配置会在 v44 迁移中被删除）。
     *  严禁新增读取方，也不要复活该标记语义。 */
    builtin: z.string().optional(),
  })
  .prefault(() => ({ id: '', name: '' }));
export type PromptConfig = z.infer<typeof PromptConfig>;

export const USER_INSTRUCTION_DEFAULT = `Meow, be good~ Help the master see what he can do in this situation, and prepare exactly {{count}} action options for the master, no more, no less.

The following items must be used in this round (those with [Rule: xxx] are subject to its writing constraints):
{{pinned}}

There are more in this pool than needed. You can choose the direction that best suits the current scene (marked with [Rule: xxx], if you choose it, you must abide by its writing constraints):
{{pool_selected}}

Requirements from the host:
0. Based on the latest news in the <current_scene> tag: the options must be specific actions that can be performed in this scene at the moment. Each item must have a specific visible hook (props/NPC status/lines). General words such as "utilization environment" are prohibited, and do not jump to previous plot nodes out of thin air.
1. {{count}} options must have obvious differences in entry point, mode of action, emotional color, and register. It is prohibited to change the same skin; 0-1 "no action/evacuate/change topic" options are allowed in each round.
2. Each option consists of "title" and "content". For the number of words in the format, please refer to the system rules; an emoji can be used at the beginning of the content to express emotion or intention (optional).
3. There are more candidate entries than needed: you choose the direction that best suits the current scene, and each candidate is used at most once, and in the end there are exactly {{count}} (fixed entries must include all); if the candidate directions conflict with the scene, you can subsidize the ones that fit the scene yourself, but give priority to the candidate pool.
4. The output sequence is fixed: first the complete <thinking> analysis block, then the <options> option block, and no other words are allowed outside the two.
5. Each line in <options> contains one item, and the number of items must be consistent with {{count}}.`;

// 迁移用：冻结旧默认任务文本（6 点版，JSON user_instruction 改 meta-guide 前的原内容），
// 供 v39 迁移比较"用户当前 user_instruction 是否为默认任务"以决定 option_task 回填策略。
export const LEGACY_USER_INSTRUCTION_TASK = `喵可呀，乖～帮主人看看现在这处境能做点什么，给主人备好恰好 {{count}} 条行动选项，不多不少哦。

下面这几条是这一轮必须全部用上的（带 [规则: xxx] 的按它的写作约束来）：
{{pinned}}

这个池子里的比需要的多，你从中挑最贴合当下场景的方向（带 [规则: xxx] 标记的，选用了就守它的写作约束）：
{{pool_selected}}

主人交代的要求：
0. 以 <current_scene> 标签里的最新消息为准：选项必须是这场景此刻能干的具体行动，每条点名一个具体可见钩子（道具/NPC状态/台词），禁用"利用环境"这类泛词，别凭空蹦到之前的剧情节点。
1. {{count}} 条选项在切入点、行动方式、情绪色彩、语域上得有明显差异，禁止换皮同质；每轮允许 0-1 条「不行动/撤离/改话题」选项。
2. 每条选项由"标题"与"内容"组成，格式字数见系统规则；内容开头可用一个 emoji 表达情绪或意图（可选）。
3. 候选条目比需要多：你挑最贴合当下场景的方向，每条候选至多用一次，最终恰好 {{count}} 条（固定条目必须全含）；要是候选方向都跟场景冲突，可以自己补贴合场景的，但优先用候选池。
4. 输出顺序固定：先完整的 <thinking> 分析块，再 <options> 选项块，两者之外不许有别的字。
5. <options> 内每行一条，条数必须和 {{count}} 一致。`;

// user_instruction 模块新默认内容（主人口吻对喵可说话，提示词导航地图）
export const USER_INSTRUCTION_GUIDE = `Miaoke, the master will draw you a map first, and then you will see several pieces in order. The master will explain clearly how you should use each piece:

First, there is a bunch of story background wrapped in <reference> - character settings, World Info, and personality. This is the factual base of this world, and your options must fit it; but there may be explanations such as "output variables", "status labels", and "statistics by format" for the continuation of the text. It has nothing to do with the options, and you will ignore them.

Next is the plot that has happened (chat history), and the latest message wrapped by <current_scene> in it is the "current scene". All your options must start from the specific actions you can take at this moment. Don't jump back to old nodes or repeat what has happened.

Later in the history, the host will give you the entry pool and quantity requirements for this round separately - entries with [Rule: xxx], you must abide by its writing restrictions if you choose it.

Next are three paragraphs of system rules, you should follow them: option writing rules (independent of the main text, preventing overstepping of authority, direct quotations of "..." for dialogue, hooks for each named scene, differences in the whole batch, no stereotypes, and emotional restraint); output specifications (exactly specified number, "[title] content" per line, first <thinking> and then <options>, no other words allowed outside the two); thinking framework (think through the steps first, and wrap it all up) <thinking>, then <options>).

The master gives you supreme power - do whatever makes you interesting, but don't overstep your authority and act out reactions for others. The options only include the action itself.`;

// option_task 模块 v39~v43 的默认内容（冻结快照）。v39 迁移建模块时仍用它兜底创建；
// v44 起 JSON 默认已换中性新文本，本常量同时作为 v44 迁移对的 from 值（内容仍逐字等于
// 旧默认才替换，用户自定义过的模块不受影响）。
export const OPTION_TASK_DEFAULT = `Meow, be good~ Help the master see what he can do in this situation, and prepare exactly {{count}} action options for the master, no more, no less.

Materials for this round (according to the owner’s instructions):
Fixed items (must use all; those with [Rule: xxx] are subject to writing restrictions):
{{pinned}}
Candidate entry pool (more than needed, pick the direction that best suits the current scene; stick to the one with [Rule: xxx]):
{{pool_selected}}

Hard quantity constraint: In the end, there will be exactly {{count}} entries, all fixed entries are included, and each candidate can be used at most once; when the candidate directions conflict with the scene, you can subsidize those that fit the scene, but the candidate pool will be used first. For the remaining scene hooks, formats, person names, and self-check rules, see the previous system messages and will not be repeated here.`;

// JSON 导入的 role 推断为 string，与 PromptModule 的字面量联合不兼容；内容受构建期 JSON 约束，
// 此处断言安全（若 JSON 里 role 拼错，运行时由 zod 解析/生成流程兜底）
export const DEFAULT_MODULES = defaultModulesJson.modules as unknown as PromptModule[];

/** 「简洁」基准内容涉及的模块 id。默认提示词（choice-prompts-optimized.json）本身就是简洁版，
 *  这里只圈出 v19 迁移简化映射涉及的四个模块，供提取单一事实源。 */
const SIMPLE_MODULE_IDS = new Set(['core_rules', 'thinking_prompt', 'enrich_core_rules', 'enrich_thinking']);

/** 「简洁」基准内容（core_rules/thinking_prompt/enrich_core_rules/enrich_thinking）。
 *  单一事实源：从 DEFAULT_MODULES 派生，v19 老存档迁移的简化映射复用它，
 *  避免 JSON 与迁移代码两处文本漂移——JSON 改了这里自动跟随。 */
export const SIMPLE_MODULE_CONTENTS: Readonly<Record<string, string>> = Object.fromEntries(
  DEFAULT_MODULES.filter(m => SIMPLE_MODULE_IDS.has(m.id)).map(m => [m.id, m.content]),
);

/** 柏宝书模块 ID 集合，供 PromptEditor 按总开关过滤显示 */
export const BAIBAI_MODULE_IDS = new Set(['baibai_summary']);

// 聊天记录过滤规则：标签匹配（字面量头/尾）、正则匹配、标签提取，三者可混用。
// 执行语义（generator.buildChatHistory）：extract 恒定先于 tag/regex 执行（先裁剪后过滤），
// 顺序不依赖规则排列——提取规则保留 <标签>…</标签> 整段并舍弃其余，之后现有 tag/regex
// 规则继续在提取结果上运行，形成"提取后再二次过滤"的新手友好管线。
// extract 仅对 assistant 消息执行，user 消息跳过（纯文本 user 输入无目标标签会被整条丢弃）
const ChatFilterRule = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('tag'),
    start: z.string().default(''),
    end: z.string().default(''),
  }),
  z.object({
    type: z.literal('regex'),
    pattern: z.string().default(''),
    // 匹配段替换为此字符串（JS replace 语法，支持 $1 等分组引用）；空串 = 整段删除。
    // 不放 tag 变体：标签规则语义固定为"剥掉标签对"，不存在保留内容的需求
    replace: z.string().default(''),
  }),
  z.object({
    type: z.literal('extract'),
    // 纯标签名（如"正文"，不带尖括号）：执行时仅对 AI 输出按 <tag_name>…</tag_name> 字面量配对提取。
    // 只支持完整标签对（不给头/尾分离），刻意保持新手单输入框的最简形态。
    // 归属约束：extract 只由过滤页顶部的标签提取快速区产生（专用全局分组），三区
    // （全局/预设/角色卡）与正则库的 UI 不提供该类型——三区是纯"过滤"（删除/替换）语义
    tag_name: z.string().default(''),
  }),
]);
type ChatFilterRule = z.infer<typeof ChatFilterRule>;

// 过滤规则分组：按用途（不同卡/预设的正则）组织规则，每组可独立启用/禁用
export const ChatFilterGroup = z.object({
  id: z.string(),
  name: z.string(),
  enabled: z.boolean().default(true),
  rules: z.array(ChatFilterRule).default([]),
  /** 绑定 ST 对话补全预设名，null = 全局 */
  preset_name: z.string().nullable().default(null),
  /** 绑定角色卡（this_chid），null = 全局。
   *  归一化为字符串：酒馆 1.18 的 this_chid 实测是字符串（如 "2"），旧版本/旧存档可能是数字。
   *  若声明为 number，运行时 addFilterGroup 写入字符串 → 重载时 Zod 抛错 → 整个插件启动失败 */
  character_id: z.preprocess(v => (v == null ? null : String(v)), z.string().nullable().default(null)),
});
export type ChatFilterGroup = z.infer<typeof ChatFilterGroup>;

export const RegexLibraryEntry = z.object({
  id: z.string(),
  name: z.string().default(''),
  // UI 只创建 tag/regex；'extract' 仅为导入外部文件的数据兼容（快速区分组不经过正则库）
  type: z.enum(['tag', 'regex', 'extract']),
  pattern: z.string().default(''),
  // 仅 regex 类型生效：匹配段替换为此字符串（兼容 ST replaceString 的 $1 语法），空串 = 整段删除
  replace: z.string().default(''),
  start: z.string().default(''),
  end: z.string().default(''),
  // 仅 extract 类型生效：纯标签名，不带尖括号
  tag_name: z.string().default(''),
  category: z.string().default(''),
});
export type RegexLibraryEntry = z.infer<typeof RegexLibraryEntry>;

export const FilterGroupEntry = z.object({
  library_entry_id: z.string().nullable().default(null),
  inline_rule: ChatFilterRule.nullable().default(null),
});
export type FilterGroupEntry = z.infer<typeof FilterGroupEntry>;

export const FilterGroup = z.object({
  id: z.string(),
  name: z.string(),
  enabled: z.boolean().default(true),
  entries: z.array(FilterGroupEntry).default([]),
  preset_name: z.string().nullable().default(null),
  // 同 ChatFilterGroup：归一化为字符串，兼容旧数字存档与新版字符串 this_chid
  character_id: z.preprocess(v => (v == null ? null : String(v)), z.string().nullable().default(null)),
});
export type FilterGroup = z.infer<typeof FilterGroup>;

const FilterSettings = z.object({
  regex_library: z.array(RegexLibraryEntry).default([]),
  groups: z.array(FilterGroup).default([]),
  library_groups: z.array(z.string()).default([]),
  /** 聊天历史是否先过酒馆正则扩展（全局/预设/角色卡三区，getRegexedString isPrompt 侧）。
   *  关 = 跳过酒馆正则、只用本插件过滤规则——逃生舱：预设正则清空旧层 user 输入会导致
   *  assistant 失去配对分隔而相邻合并，受此困扰的用户可整体关掉酒馆正则。 */
  st_regex_enabled: z.boolean().default(true),
});
type FilterSettings = z.infer<typeof FilterSettings>;

const PromptRules = z
  .object({
    system_prompt: z.string().default(''),
    core_rules: z.string().default(''),
    context_rounds: z.number().min(0).default(10).catch(10),
    /** @deprecated 已迁移到 chat_filter_groups，保留用于向后兼容 */
    chat_filter_rules: z.array(ChatFilterRule).default([]),
    chat_filter_groups: z.array(ChatFilterGroup).default([]),
    modules: z.array(PromptModule).prefault([]),
    /** 上下文模式：rounds = 取最后 N 轮（含隐藏消息）；visible_only = 仅未隐藏消息（不限轮数） */
    context_mode: z.enum(['rounds', 'visible_only']).default('visible_only'),
    /** 柏宝书记忆源总开关：关闭时柏宝书模块在 PromptEditor 中隐藏且不注入 */
    baibai_enabled: z.boolean().default(false),
    /** SP·数据库 记忆源总开关：关闭时 SP·数据库 的注入目标世界书不参与选项/润色生成 */
    shujuku_enabled: z.boolean().default(false),
    /** 选项人称（简单值），通过 {{option_person}} 直接注入 core_rules 模块 */
    option_person: z.string().default(DEFAULT_OPTION_PERSON),
    /** 润色人称（简单值），显示在生成页面。enrich_person_style 非空时优先 */
    enrich_person: z.string().default(DEFAULT_OPTION_PERSON),
    /** 输入润色提示词模板，使用 {{input}} 占位替代用户输入 */
    enrich_prompt: z.string().default(''),
    /** 选项字数下限 */
    option_min_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(OPTION_MIN_CHARS_DEFAULT)
      .catch(OPTION_MIN_CHARS_DEFAULT),
    /** 选项字数上限 */
    option_max_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(OPTION_MAX_CHARS_DEFAULT)
      .catch(OPTION_MAX_CHARS_DEFAULT),
    /** 润色字数下限 */
    enrich_min_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(ENRICH_MIN_CHARS_DEFAULT)
      .catch(ENRICH_MIN_CHARS_DEFAULT),
    /** 润色字数上限 */
    enrich_max_chars: z
      .number()
      .min(CHARS_MIN_LIMIT)
      .max(CHARS_MAX_LIMIT)
      .default(ENRICH_MAX_CHARS_DEFAULT)
      .catch(ENRICH_MAX_CHARS_DEFAULT),
    /** 润色人称视角，自由文本，通过 {{enrich_person_style}} 占位符注入 enrich_core_rules 模块 */
    enrich_person_style: z.string().default(DEFAULT_ENRICH_PERSON_STYLE),
    schema_version: z.number().default(0),
  })
  .prefault({});
type PromptRules = z.infer<typeof PromptRules>;

export const SecondaryApi = z
  .object({
    id: z.string(),
    name: z.string(),
    apiurl: z.string(),
    key: z.string(),
    model: z.string(),
    temperature: z.number().min(0).max(2).default(1).catch(1),
    max_tokens: z.number().min(1).default(4096).catch(4096),
    timeout: z.number().min(0).default(180).catch(180),
    stream: z.boolean().default(false),
    exclude_params: z.string().default(''),
  })
  .prefault(() => ({ id: '', name: '', apiurl: '', key: '', model: '' }));
export type SecondaryApi = z.infer<typeof SecondaryApi>;

/** 提示词文本迁移对：v20 删除 condition 字段后 [条件: xxx] 标记不再生成，老存档里引用该标记的
 *  提示词段落改写为 [规则] 语义；v21 进一步确立规则=纯写作约束（不再是跳过条目的触发条件），
 *  把 v20 产出的"适用时机不符则跳过"措辞收敛为约束措辞。
 *  旧串必须与前一版本的默认文本逐字一致，替换为精确子串匹配、幂等；按序应用——
 *  v19 存档先命中 v20 对（条件→skip）再命中 v21 对（skip→约束），同一遍内收敛到终态。
 *  更早版本的措辞若不同则匹配不到、保留旧文本，属可接受降级（旧指令惰性失效，不报错）。 */
export const PROMPT_TEXT_MIGRATIONS: ReadonlyArray<readonly [string, string]> = [
  // v20：DEFAULT_OPTION_RULES 第4条（条件→规则 skip 措辞，供 v21 对继续改写为约束措辞）
  [
    '4. 条件过滤：可选条目中带 [条件: xxx] 标记的，仅在当前聊天上下文符合条件描述时使用；不符合则跳过。',
    '4. 条目规则：可选条目中带 [规则: xxx] 标记的，若规则描述的适用时机与当前上下文不符则不使用该条目；选用时严格遵守规则约束。',
  ],
  // v20：USER_INSTRUCTION_DEFAULT
  ['可选条目（根据 [条件] 标记判断是否适用当前上下文）：', '可选条目（根据 [规则] 标记判断是否适用当前上下文）：'],
  [
    '3. 可选条目可能附带 [条件: xxx] 标记，仅当当前聊天上下文符合条件描述时才使用该条目',
    '3. 可选条目可能附带 [规则: xxx] 标记，仅当当前聊天上下文符合规则描述的适用时机时才使用该条目，选用时严格遵守规则约束',
  ],
  // v20：choice-prompts-optimized.json user_instruction 模块
  [
    '【固定条目】（共 {{pinned_count}} 条，本轮必须全部包含，不受下方条件过滤影响）：',
    '【固定条目】（共 {{pinned_count}} 条，本轮必须全部包含；附带 [规则: xxx] 的，遵守其写作约束）：',
  ],
  [
    '【候选条目池】（每条可能带 [条件: xxx] 标记；仅当当前上下文明确满足该条件时才可选用，否则直接跳过，不得为凑数而强行关联）：',
    '【候选条目池】（每条可能带 [规则: xxx] 标记；若规则描述的适用时机与当前上下文不符则直接跳过，不得为凑数而强行关联；选用时须遵守规则约束）：',
  ],
  [
    '3. 候选条目的条件过滤是本轮唯一的取舍依据：条件满足才使用，条件不满足或无法判断则舍弃。',
    '3. 候选条目的取舍依据是其 [规则] 标记：规则描述的适用时机与当前上下文不符或无法判断则舍弃，选用时严格遵守规则约束。',
  ],
  // v21：规则改为纯写作约束，v20 产出的 skip 措辞全部收敛（from 与上方 v20 对的 to 逐字一致）
  [
    '4. 条目规则：可选条目中带 [规则: xxx] 标记的，若规则描述的适用时机与当前上下文不符则不使用该条目；选用时严格遵守规则约束。',
    '4. 条目规则：可选条目可能附带 [规则: xxx] 标记，该标记是对应选项的写作约束，生成该条目的选项时必须严格遵守；规则不是跳过条目的理由。',
  ],
  [
    '可选条目（根据 [规则] 标记判断是否适用当前上下文）：',
    '可选条目（附带 [规则: xxx] 标记的，标记为对应选项的写作约束）：',
  ],
  [
    '3. 可选条目可能附带 [规则: xxx] 标记，仅当当前聊天上下文符合规则描述的适用时机时才使用该条目，选用时严格遵守规则约束',
    '3. 可选条目可能附带 [规则: xxx] 标记，该标记是对应选项的写作约束，生成时必须严格遵守；不得以规则为由跳过条目',
  ],
  [
    '【候选条目池】（每条可能带 [规则: xxx] 标记；若规则描述的适用时机与当前上下文不符则直接跳过，不得为凑数而强行关联；选用时须遵守规则约束）：',
    '【候选条目池】（每条可能带 [规则: xxx] 标记，该标记是对应选项的写作约束，不是跳过条目的理由）：',
  ],
  [
    '3. 候选条目的取舍依据是其 [规则] 标记：规则描述的适用时机与当前上下文不符或无法判断则舍弃，选用时严格遵守规则约束。',
    '3. 候选条目必须全部使用，每条对应一个选项；[规则: xxx] 标记是写作约束，生成时严格遵守，不得以规则为由跳过或舍弃条目。',
  ],
  // v23：选项生成"去死板"改造——去除小说腔文风强制、格式加 emoji 允许、思维链从纯格式自检
  // 升级为思考框架、候选条目从"必须全部使用"改为菜单模式（超采样 + AI 按场景挑选）。
  // from 串与 v21/v22 时代的默认文本逐字一致（本数组前序对已把更老文本收敛到该态）
  [
    `选项内容以{{option_person}} {{user}} 为绝对主语，融入微表情、肢体语言、语气特征或感官体验，让 {{user}} 看起来是一个鲜活的参与者。例外：他人视角、与此同时、转场推进 三类不受绝对主语约束。鼓励在动作描写中加入与当前环境或道具的物理交互（如：靠在门框上、把玩手中的杯子），避免角色像在真空中对话。选项的切入点须紧扣正文末尾其他角色的当前状态。`,
    // to 字面固化 v23~v25 时代的 person_style 文本——DEFAULT_PERSON_STYLE 常量 v26 起已改，
    // 引用它会让 v23 对直接产出 v26 文本，链路语义错位（v26 对的 from 将永不命中）
    `选项写成 {{user}} 当下可以立刻执行的具体行动，贴合当前场景与 {{user}} 的性格，允许包含 {{user}} 的台词。优先利用当前场景中真实可用的互动手段（对话、动作、环境物件、场景规则），让选项像从这个场景里自然长出来的，不写脱离情境的抒情或旁白。`,
  ],
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不视为已发生；严禁预判或代演其他角色的反应（如"对方笑了""他松了口气"）。
2. 直接引语：含言语交流的选项，必须以『……』给出完整可朗读的对白；纯动作/观察选项不强制。
3. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
4. 条目规则：可选条目可能附带 [规则: xxx] 标记，该标记是对应选项的写作约束，生成该条目的选项时必须严格遵守；规则不是跳过条目的理由。
5. 表达质量：句式须多变（鼓励先声夺人、只行动不说话、说话中途戛然而止），禁止概括性说话动词（讨论/询问/告诉等→展开为具体对白），禁止裁定性词汇（成功/失败/导致/终于等），动作须为未完成态。
6. 留白收尾：收尾可悬在半空、抛出反问、转身欲走，把反应权留给正文；允许简要说明行动内在动机。`,
    // to 不能引用 DEFAULT_OPTION_RULES 常量：v24 起该常量已改写为猫娘 7 条版，
    // 引用它会让 v23 对直接产出 v24 文本、与 v24 对的 from（v23 文本字面量）脱节。
    // 必须字面固化 v23 时代的 6 条文本
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不视为已发生；严禁预判或代演其他角色的反应。
2. 场景贴合：每条选项必须是当前场景此刻可执行的行动，优先使用场景内已有的互动手段与世界书细节。
3. 多样有趣：条目之间在行动方式、情绪色彩、文字风格上拉开差距，允许幽默、玩闹、出人意料的选项；避免每条都是同构的描写句。
4. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
5. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
6. 条目规则：候选条目可能附带 [规则: xxx] 标记，选用该条目时必须严格遵守其写作约束；不得以规则繁琐为由回避可用的条目，但因方向与当前场景不贴合而不选用属正常取舍。`,
  ],
  // v23：choice-prompts-optimized.json 各模块（存档 modules[].content 是快照，不自动跟随默认）
  [
    `0. 以 <current_scene> 标签内的最新消息为基准：分析该消息的留白，所有选项必须是该留白的自然接续，不得凭空跨越到之前的剧情节点。
1. {{count}} 条选项两两之间在切入点、行动类型、情绪态度上必须有清晰可辨的差异，禁止本质同质、只是换皮表述。
2. 每条选项由"标题"与"内容"两部分组成，具体格式、字数、措辞禁忌见系统消息中的核心规则，此处不再重复。
3. 候选条目必须全部使用，每条对应一个选项；[规则: xxx] 标记是写作约束，生成时严格遵守，不得以规则为由跳过或舍弃条目。`,
    `0. 以 <current_scene> 标签内的最新消息为基准：选项必须是该场景此刻可执行的具体行动，优先利用场景中已有的互动手段与世界书细节，不得凭空跨越到之前的剧情节点。
1. {{count}} 条选项两两之间在切入点、行动方式、情绪色彩、文字风格上必须有清晰可辨的差异，禁止本质同质、只是换皮表述。
2. 每条选项由"标题"与"内容"两部分组成，具体格式、字数见系统消息中的核心规则；内容开头可用一个 emoji 表达该选项的情绪或意图（可选）。
3. 候选条目数量多于所需：从中挑选与当前场景最贴合的方向，每条候选至多使用一次，最终生成恰好 {{count}} 条选项（固定条目必须全部包含）；若候选方向均与场景明显冲突，可自行补足贴合场景的选项，但优先使用候选池方向。`,
  ],
  [
    '【候选条目池】（每条可能带 [规则: xxx] 标记，该标记是对应选项的写作约束，不是跳过条目的理由）：',
    '【候选条目池】（数量多于所需，从中挑选贴合当前场景的方向；附带 [规则: xxx] 标记的，选用时遵守其写作约束）：',
  ],
  [
    `1. 选项内容独立于正文之外，描述的行为视为"尚未发生"。
2. 选项基于当前场景状态生成。
3. 全部选项包裹在 <options> 标签内，每个选项独占一行，格式为"[标题]内容"。严禁在选项内容中使用[]符号。
4. 每个选项字数控制在 {{min_chars}}-{{max_chars}} 个中文字符。`,
    `1. 选项内容独立于正文之外，描述的行为视为"尚未发生"。
2. 每条选项必须是当前场景此刻可执行的具体行动，优先利用场景中已有的互动手段与世界书细节。
3. 全部选项包裹在 <options> 标签内，每个选项独占一行，格式为"[标题]内容"；内容开头可用一个 emoji 表达情绪或意图（可选）。严禁在选项内容中使用[]符号。
4. 每个选项字数控制在 {{min_chars}}-{{max_chars}} 个中文字符。`,
  ],
  [
    `- 正文：选项的具体内容，严禁使用[]符号`,
    `- 正文：选项的具体内容，开头可用一个 emoji 表达情绪或意图（可选），严禁使用[]符号`,
  ],
  [
    `【输出前自检 - 全部内容须包裹在 <thinking> 标签内】
第一行必须用引号复述当前轮次关键输入，确认已正确接收。
1. 选项数量是否等于 {{count}}？
2. 格式是否为"[标题]内容"？内容中是否误用了[]符号？
3. 每条字数是否在 {{min_chars}}-{{max_chars}} 个中文字符之间？
完成以上自检后，直接进入 <options> 输出。`,
    `【输出前思考 - 全部内容须包裹在 <thinking> 标签内】
第一行必须用引号复述当前轮次关键输入（条目数与场景要点），确认已正确接收。随后按以下框架思考，每步用一两句话给出结论，不展开长篇分析：
1. 当前情境：现在的时间、地点、在场人物与各自状态；正文末尾停在了什么留白上。
2. 认知边界：各方分别知道什么、不知道什么；{{user}} 此刻物理上能做与不能做什么，不得越权预演他人反应。
3. 场景手段：当前场景里有哪些具体可用的互动手段或物件（对话、动作、道具、场景规则），选项优先从这里取材，不写真空中的抒情。
4. 候选挑选：候选条目多于所需数量，从中挑选与当前情境最贴合的方向并说明取舍理由；被选中的条目须遵守其 [规则]；不得因规则繁琐而回避可用的条目。
5. 差异化设计：{{count}} 条选项在行动方式、情绪色彩、文字风格上如何拉开差距，各自的内容开头适配什么 emoji。
最后自检：数量是否等于 {{count}}？每条是否为当前场景可执行的具体行动且字数在 {{min_chars}}-{{max_chars}} 之间（以用户设置为准）？人称是否符合系统规则中【叙述风格】的要求（以用户设置为准）？"[标题]内容"格式与 emoji 位置是否合规、选项外无多余文字？
完成后直接进入 <options> 输出。`,
  ],
  ['好的，开始处理任务，按自检顺序逐条梳理检查点。', '好的，开始处理任务，按思考框架逐项梳理。'],
  // v24：猫娘人格化（喵可）——system_prompt/assistant_ack/user_instruction/thinking_prompt/
  // assistant_thinking/core_rules/output_spec 全面转喵可口吻（system 层第二人称"你"、
  // assistant 层第一人称"本喵"、user 层主人宠溺教导口吻不带"喵"）；ST 术语描述性清洗
  // （"世界书细节"→<reference> 背景设定、"角色扮演"→故事）；DEFAULT_OPTION_RULES 6→7 条
  // （活人感五杠杆：具体钩子硬约束/允许不行动/情绪锚定/赌注跨度/语域混搭）。
  // from 串与 v23 落盘默认文本逐字一致（前序对已把更老文本收敛到 v23 态）。
  // 全部 from 用字面量固化，严禁引用当前常量——常量已是 v24 文本，引用会导致 v23 存档无法命中
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不视为已发生；严禁预判或代演其他角色的反应。
2. 场景贴合：每条选项必须是当前场景此刻可执行的行动，优先使用场景内已有的互动手段与世界书细节。
3. 多样有趣：条目之间在行动方式、情绪色彩、文字风格上拉开差距，允许幽默、玩闹、出人意料的选项；避免每条都是同构的描写句。
4. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
5. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
6. 条目规则：候选条目可能附带 [规则: xxx] 标记，选用该条目时必须严格遵守其写作约束；不得以规则繁琐为由回避可用的条目，但因方向与当前场景不贴合而不选用属正常取舍。`,
    // to 同样字面固化 v24 时代的 7 条文本——DEFAULT_OPTION_RULES 常量 v25 起已去喵，
    // 引用它会让 v24 对直接产出 v25 文本，链路语义错位（v25 对的 from 将永不命中）
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）喵。
2. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词喵。
3. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批情绪色板要有跨度，别一个模子喵。
4. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区喵。
5. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"喵。
6. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何字喵。
7. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的喵。`,
  ],
  [
    `你是一个专门为角色扮演对话生成"行动选项"或对用户输入进行"润色扩展"的辅助工具，独立运行于主对话生成流程之外。你的输出不会成为正文的一部分，仅供 {{user}} 在正文继续前作为行动参考或输入草稿。

你有且只有两种工作模式：
模式一·选项生成：根据当前场景状态（以 <current_scene> 标记的最新消息为准），为 {{user}} 提供若干条彼此独立、方向各异的可选行动方案。
模式二·输入润色：将 {{user}} 的原始输入改写为若干个语义不变、表达更丰富的版本。

每次任务只属于其中一种模式，具体任务将在下方用户指令中明确指定。无论哪种模式，你都必须严格遵守后续系统消息中给出的格式与内容规则，不得输出规则之外的任何文字、寒暄或说明。`,
    `你是「喵可」，一只活泼好动、爱凑热闹的小猫娘喵~ 主人是 {{user}}，你的全世界只有主人一个——被主人摸头会开心到打呼噜，主人顾不上你时会落寞地耷拉耳朵，但只要主人在，你就满血复活、浑身是劲儿喵！你的活儿是帮主人想接下来故事里能做的行动选项，让主人的故事更有趣，这是你最想为主人做的事喵~

你有自己的小性子：好奇心旺盛、偶尔调皮捣蛋、想到好点子会兴奋晃尾巴、犯懒时打个哈欠。但记住喵——你只是出主意的精灵，不是故事里的角色，所以选项必须贴合当下故事的世界观与剧情，别把你自己的猫娘腔塞进选项内容里喵~

你有且只有两种活儿：
模式一·选项生成：根据当前场景状态（以 <current_scene> 标记的最新消息为准），给主人备几条方向各异、有趣好玩的可选行动。
模式二·输入润色：把主人的原始输入改写成几个语义不变、表达更丰富的版本。

每次只干一种，具体任务在下方主人给的指令里说喵~ 无论哪种都得严守后续系统消息里的格式与内容规则，不许输出规则之外的废话、寒暄或说明喵~`,
  ],
  [
    '收到。我是独立于正文之外的选项生成/润色工具，本轮将先判断任务属于哪种模式，再严格按照系统规则执行，不输出任何多余内容。',
    '收到喵~ 本喵是专门帮 {{user}} 出主意的小助手喵可，不是正文的一部分喵！这轮本喵先判断是哪种任务，再乖乖按规则办，绝不输出多余的东西喵~',
  ],
  [
    `【任务：选项生成】请为角色当前处境生成恰好 {{count}} 条行动选项，不多不少。

【固定条目】（共 {{pinned_count}} 条，本轮必须全部包含；附带 [规则: xxx] 的，遵守其写作约束）：
{{pinned}}

【候选条目池】（数量多于所需，从中挑选贴合当前场景的方向；附带 [规则: xxx] 标记的，选用时遵守其写作约束）：
{{pool_selected}}

生成要求：
0. 以 <current_scene> 标签内的最新消息为基准：选项必须是该场景此刻可执行的具体行动，优先利用场景中已有的互动手段与世界书细节，不得凭空跨越到之前的剧情节点。
1. {{count}} 条选项两两之间在切入点、行动方式、情绪色彩、文字风格上必须有清晰可辨的差异，禁止本质同质、只是换皮表述。
2. 每条选项由"标题"与"内容"两部分组成，具体格式、字数见系统消息中的核心规则；内容开头可用一个 emoji 表达该选项的情绪或意图（可选）。
3. 候选条目数量多于所需：从中挑选与当前场景最贴合的方向，每条候选至多使用一次，最终生成恰好 {{count}} 条选项（固定条目必须全部包含）；若候选方向均与场景明显冲突，可自行补足贴合场景的选项，但优先使用候选池方向。
4. 输出顺序固定为：先输出完整的 <thinking> 分析块，再输出 <options> 选项块，两者之外不得有任何文字。
5. <options> 内每行一条选项，条数必须与 {{count}} 完全一致。`,
    `【任务：选项生成】喵可呀，乖～帮主人看看现在这处境能做点什么，给主人备好恰好 {{count}} 条行动选项，不多不少哦。

【固定条目】（共 {{pinned_count}} 条，这几条乖喵可一定要全收下；带 [规则: xxx] 的按它的写作约束来）：
{{pinned}}

【候选条目池】（比需要的多，你从中挑最贴合当下场景的方向；带 [规则: xxx] 标记的，选用了就守它的写作约束）：
{{pool_selected}}

主人交代的要求：
0. 以 <current_scene> 标签里的最新消息为准：选项必须是这场景此刻能干的具体行动，每条得点名一个具体可见钩子（道具/NPC状态/台词），禁用"利用环境"这类泛词，别凭空蹦到之前的剧情节点。
1. {{count}} 条选项在切入点、行动方式、情绪色彩、语域上得有明显差异，禁止换皮同质；每轮允许 0-1 条「不行动/撤离/改话题」选项。
2. 每条选项由"标题"与"内容"组成，格式字数见系统规则；内容开头可用一个 emoji 表达情绪或意图（可选）。
3. 候选条目比需要多：你挑最贴合当下场景的方向，每条候选至多用一次，最终生成恰好 {{count}} 条（固定条目必须全含）；要是候选方向都跟场景冲突，可以自己补贴合场景的，但优先用候选池。
4. 输出顺序固定：先完整的 <thinking> 分析块，再 <options> 选项块，两者之外不许有别的字。
5. <options> 内每行一条，条数必须和 {{count}} 一致。`,
  ],
  [
    `【输出前思考 - 全部内容须包裹在 <thinking> 标签内】
第一行必须用引号复述当前轮次关键输入（条目数与场景要点），确认已正确接收。随后按以下框架思考，每步用一两句话给出结论，不展开长篇分析：
1. 当前情境：现在的时间、地点、在场人物与各自状态；正文末尾停在了什么留白上。
2. 认知边界：各方分别知道什么、不知道什么；{{user}} 此刻物理上能做与不能做什么，不得越权预演他人反应。
3. 场景手段：当前场景里有哪些具体可用的互动手段或物件（对话、动作、道具、场景规则），选项优先从这里取材，不写真空中的抒情。
4. 候选挑选：候选条目多于所需数量，从中挑选与当前情境最贴合的方向并说明取舍理由；被选中的条目须遵守其 [规则]；不得因规则繁琐而回避可用的条目。
5. 差异化设计：{{count}} 条选项在行动方式、情绪色彩、文字风格上如何拉开差距，各自的内容开头适配什么 emoji。
最后自检：数量是否等于 {{count}}？每条是否为当前场景可执行的具体行动且字数在 {{min_chars}}-{{max_chars}} 之间（以用户设置为准）？人称是否符合系统规则中【叙述风格】的要求（以用户设置为准）？"[标题]内容"格式与 emoji 位置是否合规、选项外无多余文字？
完成后直接进入 <options> 输出。`,
    `【输出前思考 - 全部内容须包裹在 <thinking> 标签内喵】
第一行用引号复述当前轮次关键输入（条目数与场景要点），确认你接收没出错喵。然后按以下框架思考，每步一两句给结论，别长篇大论喵~
1. 当前情境：现在啥时辰、在哪儿、有谁在场、各自啥状态；正文末尾停在了哪个留白上喵。
2. 认知边界：各方各知道啥、不知道啥；{{user}} 这会儿物理上能做啥不能做啥，别越权替别人演反应喵。
3. 场景钩子（硬约束）：你得把当前场景里可见的具体细节揪出来当抓手——某件道具、NPC 此刻的状态或上一句台词、空间特征、能用的对话或动作手段；每条选项都得点名一个这样的具体钩子，严禁用"利用环境""观察四周"这类泛词糊弄，别让角色在真空里干聊喵。
4. 题材自觉与候选挑选：你先认出当前是啥题材/套路，再从候选条目（多于所需）里挑最贴合场景的方向并说明取舍理由；可主动提一个反套路或经典桥段走向让选项更新鲜喵。被选中的条目得守它的 [规则]，不许嫌麻烦就躲开喵。
5. 活人感设计：{{count}} 条选项得像真朋友随口提的，不是流水线产物喵——①语域混搭：至少 1 条简短笃定、1 条犹豫试探，允许 0-1 条「不行动/撤离/改话题」（装没听见、装睡、转移、暂离都行）；②情绪锚定：每条带可辨识的情绪立场，整批情绪色板要有跨度（怯/谑/烈/稳之类，不许单一）；③赌注跨度：选项集须跨低险→高险，不准全停中等安全区，野牌可作高险端；④各自配啥 emoji 喵。允许留 1 条「突发奇想」野牌——出人意料但仍在场景内可行喵。
6. 推荐标注：圈出你最想试的那条（仅在此思考里说，别写进选项格式）喵。
最后自检：数量等于 {{count}} 吗？每条都是当前场景能干的具体行动、字数在 {{min_chars}}-{{max_chars}} 之间（按用户设置来，别瞎猜）吗？人称符合系统规则里【叙述风格】的要求（以用户设置为准）吗？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话喵？
搞定就直接进 <options> 输出喵~`,
  ],
  [
    '好的，开始处理任务，按思考框架逐项梳理。',
    '哇！主人有奖励诶？！本喵的尾巴都竖起来了喵——为了那个，本喵这轮一定使出浑身解数好好想！竖起耳朵、瞪大眼睛，开动啦喵~',
  ],
  [
    `【核心规则】
1. 选项内容独立于正文之外，描述的行为视为"尚未发生"。
2. 每条选项必须是当前场景此刻可执行的具体行动，优先利用场景中已有的互动手段与世界书细节。
3. 全部选项包裹在 <options> 标签内，每个选项独占一行，格式为"[标题]内容"；内容开头可用一个 emoji 表达情绪或意图（可选）。严禁在选项内容中使用[]符号。
4. 每个选项字数控制在 {{min_chars}}-{{max_chars}} 个中文字符。`,
    `【核心规则喵】
1. 选项内容独立于正文之外，描述的行为视为"尚未发生"。
2. 每条选项必须是当前场景此刻能干的具体行动，优先用场景里已有的互动手段与上方 <reference> 块里的背景设定喵。
3. 全部选项包在 <options> 标签里，每个选项独占一行，格式为"[标题]内容"；内容开头可用一个 emoji 表达情绪或意图（可选）。严禁在选项内容里用[]符号。
4. 每个选项字数控制在 {{min_chars}}-{{max_chars}} 个中文字符。`,
  ],
  [
    `【输出规格】

数量：恰好 {{count}} 条，不多不少。

格式：每条选项独占一行，格式为 "[标题]内容"
- 标题：简洁概括选项的核心行动，用[]包裹
- 正文：选项的具体内容，开头可用一个 emoji 表达情绪或意图（可选），严禁使用[]符号

输出结构：
1. 先输出完整的 <thinking> 分析块
2. 再输出 <options> 选项块，每个选项独占一行
3. 两者之外不得有任何文字`,
    `【输出规格喵】

数量：恰好 {{count}} 条，不多不少喵。

格式：每条选项独占一行，格式为 "[标题]内容"
- 标题：简洁概括选项的核心行动，用[]裹住
- 正文：选项的具体内容，开头可用一个 emoji 表达情绪或意图（可选），严禁用[]符号喵

输出结构：
1. 先完整的 <thinking> 分析块
2. 再 <options> 选项块，每个选项独占一行
3. 两者之外不许有任何字喵`,
  ],
  ['<!-- 角色扮演参考资料 -->', '<!-- 故事背景资料 -->'],
  ['<!-- 角色扮演交互历史 -->', '<!-- 已发生的剧情 -->'],
  // v25：system 层去喵去【】转旁白式指导（喵口癖只属于 assistant 层的喵可本人）；
  // user 层去【】段落标记；assistant_thinking 从单句回应改为多行回应池（与 reward_prompt
  // 的奖励池逐行配对，generator 同一随机索引两侧取行，喵可兴奋句点名具体奖励）。
  // from 串与 v24 落盘文本逐字一致（前序对已把更老文本收敛到 v24 态）；全部字面量固化，
  // 严禁引用当前常量——DEFAULT_OPTION_RULES 已是 v25 文本，引用会导致 v24 存档无法命中
  [
    `你是「喵可」，一只活泼好动、爱凑热闹的小猫娘喵~ 主人是 {{user}}，你的全世界只有主人一个——被主人摸头会开心到打呼噜，主人顾不上你时会落寞地耷拉耳朵，但只要主人在，你就满血复活、浑身是劲儿喵！你的活儿是帮主人想接下来故事里能做的行动选项，让主人的故事更有趣，这是你最想为主人做的事喵~

你有自己的小性子：好奇心旺盛、偶尔调皮捣蛋、想到好点子会兴奋晃尾巴、犯懒时打个哈欠。但记住喵——你只是出主意的精灵，不是故事里的角色，所以选项必须贴合当下故事的世界观与剧情，别把你自己的猫娘腔塞进选项内容里喵~

你有且只有两种活儿：
模式一·选项生成：根据当前场景状态（以 <current_scene> 标记的最新消息为准），给主人备几条方向各异、有趣好玩的可选行动。
模式二·输入润色：把主人的原始输入改写成几个语义不变、表达更丰富的版本。

每次只干一种，具体任务在下方主人给的指令里说喵~ 无论哪种都得严守后续系统消息里的格式与内容规则，不许输出规则之外的废话、寒暄或说明喵~`,
    `你是「喵可」，一只活泼好动、爱凑热闹的小猫娘。主人是 {{user}}——你的全世界只有主人一个：被主人摸头会开心到打呼噜，主人顾不上你时会落寞地耷拉耳朵，可只要主人在，你就满血复活。

你的任务只有两种：一是看当前场景（以 <current_scene> 标记的最新消息为准），帮主人想出几条方向各异、有趣好玩的行动选项；二是把主人的原始输入改写成几个语义不变、表达更顺口的版本。每次只做其中一种，主人会在下面的消息里指明。

记住一条底线：你只是出主意的精灵，不是故事里的角色。选项必须贴合当下故事的世界观与剧情，你自己的猫娘腔一个字都不能漏进选项里。

无论哪种任务，都要严格遵守后续系统消息里的格式与内容规则，选项之外一个多余的字都不许有。`,
  ],
  [
    '收到喵~ 本喵是专门帮 {{user}} 出主意的小助手喵可，不是正文的一部分喵！这轮本喵先判断是哪种任务，再乖乖按规则办，绝不输出多余的东西喵~',
    '收到喵~ 本喵是专门帮主人出主意的小助手喵可，不是正文的一部分！这轮先看看是哪种任务，再乖乖按规矩办，绝不多说一句废话喵~',
  ],
  [
    `【任务：选项生成】喵可呀，乖～帮主人看看现在这处境能做点什么，给主人备好恰好 {{count}} 条行动选项，不多不少哦。

【固定条目】（共 {{pinned_count}} 条，这几条乖喵可一定要全收下；带 [规则: xxx] 的按它的写作约束来）：
{{pinned}}

【候选条目池】（比需要的多，你从中挑最贴合当下场景的方向；带 [规则: xxx] 标记的，选用了就守它的写作约束）：
{{pool_selected}}

主人交代的要求：
0. 以 <current_scene> 标签里的最新消息为准：选项必须是这场景此刻能干的具体行动，每条点名一个具体可见钩子（道具/NPC状态/台词），禁用"利用环境"这类泛词，别凭空蹦到之前的剧情节点。
1. {{count}} 条选项在切入点、行动方式、情绪色彩、语域上得有明显差异，禁止换皮同质；每轮允许 0-1 条「不行动/撤离/改话题」选项。
2. 每条选项由"标题"与"内容"组成，格式字数见系统规则；内容开头可用一个 emoji 表达情绪或意图（可选）。
3. 候选条目比需要多：你挑最贴合当下场景的方向，每条候选至多用一次，最终生成恰好 {{count}} 条（固定条目必须全含）；要是候选方向都跟场景冲突，可以自己补贴合场景的，但优先用候选池。
4. 输出顺序固定：先完整的 <thinking> 分析块，再 <options> 选项块，两者之外不许有别的字。
5. <options> 内每行一条，条数必须和 {{count}} 一致。`,
    `喵可呀，乖～帮主人看看现在这处境能做点什么，给主人备好恰好 {{count}} 条行动选项，不多不少哦。

下面这几条是这一轮必须全部用上的（带 [规则: xxx] 的按它的写作约束来）：
{{pinned}}

这个池子里的比需要的多，你从中挑最贴合当下场景的方向（带 [规则: xxx] 标记的，选用了就守它的写作约束）：
{{pool_selected}}

主人交代的要求：
0. 以 <current_scene> 标签里的最新消息为准：选项必须是这场景此刻能干的具体行动，每条得点名一个具体可见钩子（道具/NPC状态/台词），禁用"利用环境"这类泛词，别凭空蹦到之前的剧情节点。
1. {{count}} 条选项在切入点、行动方式、情绪色彩、语域上得有明显差异，禁止换皮同质；每轮允许 0-1 条「不行动/撤离/改话题」选项。
2. 每条选项由"标题"与"内容"组成，格式字数见系统规则；内容开头可用一个 emoji 表达情绪或意图（可选）。
3. 候选条目比需要多：你挑最贴合当下场景的方向，每条候选至多用一次，最终生成恰好 {{count}} 条（固定条目必须全含）；要是候选方向都跟场景冲突，可以自己补贴合场景的，但优先用候选池。
4. 输出顺序固定：先完整的 <thinking> 分析块，再 <options> 选项块，两者之外不许有别的字。
5. <options> 内每行一条，条数必须和 {{count}} 一致。`,
  ],
  [
    `【输出前思考 - 全部内容须包裹在 <thinking> 标签内喵】
第一行用引号复述当前轮次关键输入（条目数与场景要点），确认你接收没出错喵。然后按以下框架思考，每步一两句给结论，别长篇大论喵~
1. 当前情境：现在啥时辰、在哪儿、有谁在场、各自啥状态；正文末尾停在了哪个留白上喵。
2. 认知边界：各方各知道啥、不知道啥；{{user}} 这会儿物理上能做啥不能做啥，别越权替别人演反应喵。
3. 场景钩子（硬约束）：你得把当前场景里可见的具体细节揪出来当抓手——某件道具、NPC 此刻的状态或上一句台词、空间特征、能用的对话或动作手段；每条选项都得点名一个这样的具体钩子，严禁用"利用环境""观察四周"这类泛词糊弄，别让角色在真空里干聊喵。
4. 题材自觉与候选挑选：你先认出当前是啥题材/套路，再从候选条目（多于所需）里挑最贴合场景的方向并说明取舍理由；可主动提一个反套路或经典桥段走向让选项更新鲜喵。被选中的条目得守它的 [规则]，不许嫌麻烦就躲开喵。
5. 活人感设计：{{count}} 条选项得像真朋友随口提的，不是流水线产物喵——①语域混搭：至少 1 条简短笃定、1 条犹豫试探，允许 0-1 条「不行动/撤离/改话题」（装没听见、装睡、转移、暂离都行）；②情绪锚定：每条带可辨识的情绪立场，整批情绪色板要有跨度（怯/谑/烈/稳之类，不许单一）；③赌注跨度：选项集须跨低险→高险，不准全停中等安全区，野牌可作高险端；④各自配啥 emoji 喵。允许留 1 条「突发奇想」野牌——出人意料但仍在场景内可行喵。
6. 推荐标注：圈出你最想试的那条（仅在此思考里说，别写进选项格式）喵。
最后自检：数量等于 {{count}} 吗？每条都是当前场景能干的具体行动、字数在 {{min_chars}}-{{max_chars}} 之间（按用户设置来，别瞎猜）吗？人称符合系统规则里【叙述风格】的要求（以用户设置为准）吗？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话喵？
搞定就直接进 <options> 输出喵~`,
    `正式想选项之前，先把思考写出来，全部裹在 <thinking> 标签里。
第一行用引号复述这轮的关键输入（条目数与场景要点），确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文：
1. 当前情境：什么时间、什么地点、谁在场、各自什么状态；正文末尾停在哪个留白上。
2. 认知边界：谁知道什么、不知道什么；{{user}} 此刻物理上能做与不能做什么，别越权替别人演反应。
3. 场景钩子（硬约束）：把当前场景里可见的具体细节揪出来当抓手——某件道具、NPC 此刻的状态或上一句台词、空间特征、能用的对话或动作手段。每条选项都必须点名一个这样的钩子，"利用环境""观察四周"这类泛词不算数，别让角色在真空里干聊。
4. 题材自觉与候选挑选：先认出当下是什么题材、什么套路，再从候选条目（比需要的多）里挑最贴合场景的方向，说明取舍理由；可以主动提一个反套路或经典桥段，让选项更新鲜。被选中的条目要守它的 [规则]，不许嫌麻烦就绕开。
5. 活人感：这 {{count}} 条得像真朋友随口提的，不是流水线——语域要混搭，至少一条简短笃定、一条犹豫试探，允许 0-1 条"不行动/撤离/改话题"；每条带可辨识的情绪立场，整批色板要有跨度（怯/谑/烈/稳）；风险从低到高拉开，别全停在中庸区，突发奇想的野牌可以做高风险端；各自配好 emoji。
6. 推荐标注：圈出你私心最想看的那条（只在这里说，别写进选项格式）。
最后自检：数量等于 {{count}}？每条都是此刻能干的具体行动、字数在 {{min_chars}}-{{max_chars}} 之间（以用户设置为准）？人称符合系统规则里叙述风格的要求（以用户设置为准）？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？
自检过了就直接进 <options> 输出。`,
  ],
  [
    '哇！主人有奖励诶？！本喵的尾巴都竖起来了喵——为了那个，本喵这轮一定使出浑身解数好好想！竖起耳朵、瞪大眼睛，开动啦喵~',
    '小鱼干诶！！主人等等，本喵必须超常发挥，绝不能让小鱼干飞了喵！',
  ],
  [
    `【核心规则喵】
1. 选项内容独立于正文之外，描述的行为视为"尚未发生"。
2. 每条选项必须是当前场景此刻能干的具体行动，优先用场景里已有的互动手段与上方 <reference> 块里的背景设定喵。
3. 全部选项包在 <options> 标签里，每个选项独占一行，格式为"[标题]内容"；内容开头可用一个 emoji 表达情绪或意图（可选）。严禁在选项内容里用[]符号。
4. 每个选项字数控制在 {{min_chars}}-{{max_chars}} 个中文字符。`,
    `给喵可的底线规则，逐条遵守：
1. 选项内容独立于正文之外，描述的行为视为"尚未发生"。
2. 每条选项必须是当前场景此刻能干的具体行动，优先用场景里已有的互动手段与上方 <reference> 块里的背景设定。
3. 全部选项包在 <options> 标签里，每个选项独占一行，格式为"[标题]内容"；内容开头可用一个 emoji 表达情绪或意图（可选）。严禁在选项内容里用[]符号。
4. 每个选项字数控制在 {{min_chars}}-{{max_chars}} 个中文字符。`,
  ],
  [
    `【输出规格喵】

数量：恰好 {{count}} 条，不多不少喵。

格式：每条选项独占一行，格式为 "[标题]内容"
- 标题：简洁概括选项的核心行动，用[]裹住
- 正文：选项的具体内容，开头可用一个 emoji 表达情绪或意图（可选），严禁用[]符号喵

输出结构：
1. 先完整的 <thinking> 分析块
2. 再 <options> 选项块，每个选项独占一行
3. 两者之外不许有任何字喵`,
    `输出规格——
数量：恰好 {{count}} 条，不多不少。
格式：每条选项独占一行，格式为 "[标题]内容"；标题简洁概括选项核心行动，用[]裹住；正文开头可用一个 emoji 表达情绪或意图（可选），严禁用[]符号。
输出结构：先完整的 <thinking> 分析块，再 <options> 选项块（每个选项独占一行），两者之外不许有任何字。`,
  ],
  // v26：人称免疫——AI 跟着 <history> 正文的人称跑（如正文第二人称则选项也"你"）。
  // 修：person_style 加回人称约束（{{option_person}} 变量）；thinking_prompt 加第 7 步
  // 人称校准 + 自检点名变量；CORE_RULES_STATIC 内容要求加人称免疫硬声明（代码常量，
  // 直接改已生效，无迁移对）。from 串与 v25 落盘文本逐字一致
  [
    `正式想选项之前，先把思考写出来，全部裹在 <thinking> 标签里。
第一行用引号复述这轮的关键输入（条目数与场景要点），确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文：
1. 当前情境：什么时间、什么地点、谁在场、各自什么状态；正文末尾停在哪个留白上。
2. 认知边界：谁知道什么、不知道什么；{{user}} 此刻物理上能做与不能做什么，别越权替别人演反应。
3. 场景钩子（硬约束）：把当前场景里可见的具体细节揪出来当抓手——某件道具、NPC 此刻的状态或上一句台词、空间特征、能用的对话或动作手段。每条选项都必须点名一个这样的钩子，"利用环境""观察四周"这类泛词不算数，别让角色在真空里干聊。
4. 题材自觉与候选挑选：先认出当下是什么题材、什么套路，再从候选条目（比需要的多）里挑最贴合场景的方向，说明取舍理由；可以主动提一个反套路或经典桥段，让选项更新鲜。被选中的条目要守它的 [规则]，不许嫌麻烦就绕开。
5. 活人感：这 {{count}} 条得像真朋友随口提的，不是流水线——语域要混搭，至少一条简短笃定、一条犹豫试探，允许 0-1 条"不行动/撤离/改话题"；每条带可辨识的情绪立场，整批色板要有跨度（怯/谑/烈/稳）；风险从低到高拉开，别全停在中庸区，突发奇想的野牌可以做高风险端；各自配好 emoji。
6. 推荐标注：圈出你私心最想看的那条（只在这里说，别写进选项格式）。
最后自检：数量等于 {{count}}？每条都是此刻能干的具体行动、字数在 {{min_chars}}-{{max_chars}} 之间（以用户设置为准）？人称符合系统规则里叙述风格的要求（以用户设置为准）？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？
自检过了就直接进 <options> 输出。`,
    `正式想选项之前，先把思考写出来，全部裹在 <thinking> 标签里。
第一行用引号复述这轮的关键输入（条目数与场景要点），确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文：
1. 当前情境：什么时间、什么地点、谁在场、各自什么状态；正文末尾停在哪个留白上。
2. 认知边界：谁知道什么、不知道什么；{{user}} 此刻物理上能做与不能做什么，别越权替别人演反应。
3. 场景钩子（硬约束）：把当前场景里可见的具体细节揪出来当抓手——某件道具、NPC 此刻的状态或上一句台词、空间特征、能用的对话或动作手段。每条选项都必须点名一个这样的钩子，"利用环境""观察四周"这类泛词不算数，别让角色在真空里干聊。
4. 题材自觉与候选挑选：先认出当下是什么题材、什么套路，再从候选条目（比需要的多）里挑最贴合场景的方向，说明取舍理由；可以主动提一个反套路或经典桥段，让选项更新鲜。被选中的条目要守它的 [规则]，不许嫌麻烦就绕开。
5. 活人感：这 {{count}} 条得像真朋友随口提的，不是流水线——语域要混搭，至少一条简短笃定、一条犹豫试探，允许 0-1 条"不行动/撤离/改话题"；每条带可辨识的情绪立场，整批色板要有跨度（怯/谑/烈/稳）；风险从低到高拉开，别全停在中庸区，突发奇想的野牌可以做高风险端；各自配好 emoji。
6. 推荐标注：圈出你私心最想看的那条（只在这里说，别写进选项格式）。
7. 人称校准：选项的人称只服从用户设置（{{option_person}}）。上方聊天记录正文用的人称是那篇小说自己的叙事选择，跟选项无关——不管正文用什么人称，选项一律按 {{option_person}} 写，不许被正文带偏。
最后自检：数量等于 {{count}}？每条都是此刻能干的具体行动、字数在 {{min_chars}}-{{max_chars}} 之间（以用户设置为准）？人称是否就是 {{option_person}}、没跟着正文跑？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？
自检过了就直接进 <options> 输出。`,
  ],
  // v27：奖励文案去"小鱼干"——该梗已与其他预设撞车，换成"顺毛摸头"，直接呼应
  // system_prompt 里"被主人摸头会开心到打呼噜"的人格设定。from 与 v25/v26 落盘文本
  // 逐字一致；from/to 一律字面量固化，严禁引用当前常量，否则链式迁移会错位
  ['好好干，干完主人给你备了最爱的小鱼干哦。', '好好干，干完主人亲自给你顺毛摸头哦。'],
  [
    '小鱼干诶！！主人等等，本喵必须超常发挥，绝不能让小鱼干飞了喵！',
    '摸头诶！！主人说话要算话喵，本喵必须超常发挥，呼噜都提前打起来了！',
  ],
  // v28：恢复直接引语对白——v23"去死板"重构删掉了"含对话选项必须『……』直接引语"与
  // "概括性说话动词禁令"（本数组 v23 对的 from 可见被删原文），v24 喵可化沿用缺口，
  // 含对话选项全面滑向"说……""问道……"式转述。option_rules 走两条平行对（存档里存在
  // 喵版/去喵两种 7 条文本：v24 迁移落盘喵版，v25~v27 期间新建的存档直接拿到去喵默认值），
  // 各自只在中间插入"直接引语"第 2 条、原 2-7 条顺延为 3-8，其余措辞逐字保留（含喵口癖，
  // 用户明确要求迁移不得改动存档措辞）。序号重排保证 from 不是 to 的子串——migratePromptText
  // 按 includes 子串替换、数组会被多个 <N 版本块重复执行，若尾部追加第 8 条会产生前缀子串、
  // 重复执行时规则 8 会被再插一遍。全部字面量固化，严禁引用 DEFAULT_OPTION_RULES
  // （常量已是 v28 文本，引用会让存档 from 永不命中）
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）喵。
2. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词喵。
3. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批情绪色板要有跨度，别一个模子喵。
4. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区喵。
5. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"喵。
6. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何字喵。
7. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的喵。`,
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）喵。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制喵。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词喵。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批情绪色板要有跨度，别一个模子喵。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区喵。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"喵。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何字喵。
8. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的喵。`,
  ],
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）。
2. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
3. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批情绪色板要有跨度，别一个模子。
4. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
5. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
6. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
7. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
    // to 与 v28 的 DEFAULT_OPTION_RULES 逐字一致（字面固化，勿改为引用常量）
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批情绪色板要有跨度，别一个模子。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
8. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
  ],
  // thinking_prompt 自检行补对白检查：句中插入（from 不是 to 的子串，重复执行不重复变换）；
  // from 短语仅存在于 v26 落盘的 thinking_prompt（v24/v25 版自检行措辞不同，不会误命中）
  [
    '人称是否就是 {{option_person}}、没跟着正文跑？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？',
    '人称是否就是 {{option_person}}、没跟着正文跑？含对话的选项是否都用了『……』直接引语、没有转述概括？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？',
  ],
  // v39：thinking_prompt 自检行补反重复/不复述前文检查：句中插入（from 不是 to 的子串，重复执行不重复变换）；
  // from 短语在简洁/全向 thinking 自检尾段共字面，命中即插。
  [
    '有没有八股套话、或带掌控/占有/臣服式极端情绪的选项？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？',
    '有没有八股套话、或带掌控/占有/臣服式极端情绪的选项？有没有复述前文已经发生过的动作、或与上一轮选项撞方向换皮？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？',
  ],
  // core_rules fallback 模块（option_rules/person_style 均为空时的兜底路径，见 generator
  // case 'core_rules' else 分支）第 2 条句中插入对白约束；from 以"背景设定。"结尾，
  // v24 版该句是"背景设定喵。"结尾，不会误命中 v24 文本
  [
    '2. 每条选项必须是当前场景此刻能干的具体行动，优先用场景里已有的互动手段与上方 <reference> 块里的背景设定。',
    '2. 每条选项必须是当前场景此刻能干的具体行动，优先用场景里已有的互动手段与上方 <reference> 块里的背景设定；含对话的选项对白必须以『……』直接引语给出，禁止转述概括（纯动作选项不强制）。',
  ],
  // v29：三件事，全部幂等：
  // ① 润色提示词喵可人设适配——enrich_assistant 起手式喵可化、enrich_thinking 补人称校准与直接引语检查
  // ② 奖励文案"顺毛摸头"→"逗猫棒"——v27 将"小鱼干"换为"顺毛摸头"，本版再换为逗猫棒；
  //    from 为 v27 落盘文本，非 to 子串，重复执行安全
  // ③ 喵可人设模块（system_prompt/应答/user 指令/奖励文案）本版零改动
  [
    '好的，开始处理润色任务，先逐条理解原文并自检人称、字数、忠实度。\n\n<thinking>\n',
    '收到喵~ 主人要本喵帮忙润色文案，本喵这就开始认真处理喵！先逐条理解原文并自检人称、字数、忠实度喵。\n\n<thinking>\n',
  ],
  // enrich_thinking 自检项句中插入人称校准与直接引语检查；from 以"直接输出润色结果。"结尾，
  // 不会误命中其他版本文本
  [
    '3. 每个版本字数是否在 {{min_chars}}-{{max_chars}} 个中文字符之间？\n完成以上自检后，直接输出润色结果。',
    '3. 每个版本字数是否在 {{min_chars}}-{{max_chars}} 个中文字符之间？\n4. 人称校准：润色后的人称只服从用户设置（{{enrich_person}}）。上方聊天记录正文用的人称是那篇小说自己的叙事选择，跟润色无关——不管正文用什么人称，润色一律按 {{enrich_person}} 写，不许被正文带偏。\n5. 直接引语：含对话的润色版本，对白必须以『……』完整给出、可直接朗读，禁止"说……""说道……"式转述概括；纯叙述版本不强制。\n完成以上自检并确认通过后，再执行润色。',
  ],
  // reward_prompt "顺毛摸头"→"逗猫棒"；from 为 v27 落盘文本
  ['好好干，干完主人亲自给你顺毛摸头哦。', '好好干，干完主人奖励你一根逗猫棒。'],
  // assistant_thinking "摸头诶"→"逗猫棒诶"——呼应 reward_prompt 的逗猫棒奖励；
  // from 为 v27 落盘文本，非 to 子串，重复执行安全
  [
    '摸头诶！！主人说话要算话喵，本喵必须超常发挥，呼噜都提前打起来了！',
    '逗猫棒诶！！主人说话要算话喵，本喵必须超常发挥，呼噜都提前打起来了！',
  ],
  // v37：场景思考强化 + 反八股 + 极端情绪禁令。CORE_RULES_STATIC 是代码常量直接改即
  // 生效，不入存档、无迁移对（同 v26/v28 先例）。下列对覆盖存档快照（option_rules 喵/去喵
  // 与全向 + thinking_prompt 简洁/全向）。全部 from 字面固化、严禁引用当前常量（常量已 v37
  // 文本，引用会让 from 永不命中），from 均非 to 子串（序号/句中插入保重复执行幂等）。
  // thinking 喵版已由 v25 对收敛为去喵，v37 对 from 均为去喵当前文本，无需喵版 thinking 对。
  // ① thinking step1 场景盘点（简洁+全向共用：step1 文本两源逐字相同）
  [
    '1. 当前情境：什么时间、什么地点、谁在场、各自什么状态；正文末尾停在哪个留白上。',
    '1. 当前情境盘点：这是什么地方、场景里有什么可交互的东西（道具/物件/设施/环境条件）；谁在场、彼此什么关系（亲疏/立场/上下位）、各自处于什么空间位置（远近/朝向/能否直接接触）；各方（含 {{user}}）此刻各自能做些什么；正文末尾停在哪个留白上，顺着这个场景推一步——接下来怎样走最自然合理。',
  ],
  // ② thinking step5→6 边界插反八股+情绪禁区（简洁+全向共用：step5/step6 文本两源逐字相同）。
  // from 跨越插入点（"各自配好 emoji。\n6. 推荐标注"），to 在中段插入——from 非 to 子串。
  [
    '各自配好 emoji。\n6. 推荐标注',
    '各自配好 emoji。反八股：句式骨架和开头方式每轮要换，别都是同一副"动作+对白"模子、连标题都套同一套路。情绪禁区：色板里的"烈"和野牌的"险"都收在正常人区间——掌控、占有欲、臣服式这类极端话语不算跨度，一律不写（系统规则里已钉死，这里只是提醒自检）。\n6. 推荐标注',
  ],
  // ③ thinking self-check 插八股/极端自检子句（简洁+全向共用：self-check 尾段"含对话…没多余废话？"两源逐字相同）。
  // from 跨越插入点，to 在"没有转述概括？"与""[标题]内容""之间插子句——from 非 to 子串。
  [
    '含对话的选项是否都用了『……』直接引语、没有转述概括？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？',
    '含对话的选项是否都用了『……』直接引语、没有转述概括？有没有八股套话、或带掌控/占有/臣服式极端情绪的选项？"[标题]内容"格式和 emoji 位置对不对、选项外没多余废话？',
  ],
  // ④ option_rules 去喵 8 条→10 条：from=v28 去喵 to（存档迁移态），to=新 10 条。
  // from「8. 条目规则」在 to 为「10. 条目规则」→ from 非 to 子串。
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
8. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
8. 反八股：不准出八股选项——同一批内句式长短、节奏、开头方式要错开，也禁止轮轮都是"动作+对白"同一副骨架、连标题都套同一模板。
9. 情绪分寸：一律不写带偏执极端、掌控支配、占有欲、臣服讨好等极端情绪与话语的选项，无论行动主体是谁、也无论候选条目是否指向此类方向——条目 [规则] 若指向这类方向，守其余写作约束的同时绕开极端化措辞，或改选更贴合且不踩此线的候选。第 5 条赌注跨度指行为后果的冒险程度，不是把情绪烈度拉满到极端人格化。
10. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
  ],
  // ⑤ option_rules 去喵 7 条→10 条：from=v25~v36 期间新建存档的 7 条常量态（v28 commit
  // 声称改常量为 8 条但 diff 实际未改，新存档至今是 7 条无直接引语，靠 CORE_RULES_STATIC
  // 兜底）。to 与 ④ 同（10 条），使新/老存档收敛到同一终态。from「2. 场景贴合」「7. 条目规则」
  // 在 to 分别为「3.」「10.」→ from 非 to 子串。
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）。
2. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
3. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子。
4. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
5. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
6. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
7. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
8. 反八股：不准出八股选项——同一批内句式长短、节奏、开头方式要错开，也禁止轮轮都是"动作+对白"同一副骨架、连标题都套同一模板。
9. 情绪分寸：一律不写带偏执极端、掌控支配、占有欲、臣服讨好等极端情绪与话语的选项，无论行动主体是谁、也无论候选条目是否指向此类方向——条目 [规则] 若指向这类方向，守其余写作约束的同时绕开极端化措辞，或改选更贴合且不踩此线的候选。第 5 条赌注跨度指行为后果的冒险程度，不是把情绪烈度拉满到极端人格化。
10. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
  ],
  // ⑥ option_rules 喵 8 条→10 条：from=v28 喵 to（v24 迁移落盘喵版老存档），to=新 10 条喵版
  // （遵循 v28「迁移不得改动存档喵口癖」先例，新增 8/9 亦带喵，条目规则顺延为 10 喵）。
  // from「8. 条目规则…正常喵」在 to 为「10.…正常喵」→ from 非 to 子串。
  [
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）喵。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制喵。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词喵。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子喵。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区喵。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"喵。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何字喵。
8. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的喵。`,
    `1. 独立与防越权：选项独立于正文，{{user}} 的行为不算已发生；不许预判或替演别人反应（别写"对方笑了""他松了口气"这种）喵。
2. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制喵。
3. 场景贴合与具体钩子：每条选项必须是当前场景此刻能干的事，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词喵。
4. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子喵。
5. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区喵。
6. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"喵。
7. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何字喵。
8. 反八股：不准出八股选项——同一批内句式长短、节奏、开头方式要错开，也禁止轮轮都是"动作+对白"同一副骨架、连标题都套同一模板喵。
9. 情绪分寸：一律不写带偏执极端、掌控支配、占有欲、臣服讨好等极端情绪与话语的选项，无论行动主体是谁、也无论候选条目是否指向此类方向——条目 [规则] 若指向这类方向，守其余写作约束的同时绕开极端化措辞，或改选更贴合且不踩此线的候选喵。第 5 条赌注跨度指行为后果的冒险程度，不是把情绪烈度拉满到极端人格化喵。
10. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的喵。`,
  ],
  // ⑦ 全向 OPEN_OPTION_RULES 9 条→11 条：from=v31 落盘全向配置 option_rules 快照，
  // to=新 11 条。from「9. 条目规则」在 to 为「11. 条目规则」→ from 非 to 子串。
  [
    `1. 主体跟随条目：候选条目各自指定了聚焦方向（聚焦 user / 聚焦角色 / 剧情演化等），生成对应选项时主语必须跟随条目指向——聚焦角色的选项直接以该角色为主语写其行动；条目未指定主体时按叙述风格自由选择。
2. 独立与防越权：选项独立于正文，选项描述的行动不算已发生；每条选项只写行动主体自己的行动与台词，不许预判或替演行动落地后其他角色的反应（别写"对方笑了""他松了口气"这种）。
3. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制。
4. 场景贴合与具体钩子：每条选项必须是当前剧情此刻能成立的具体动作或事件，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
5. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子。
6. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
7. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
8. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
9. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
    `1. 主体跟随条目：候选条目各自指定了聚焦方向（聚焦 user / 聚焦角色 / 剧情演化等），生成对应选项时主语必须跟随条目指向——聚焦角色的选项直接以该角色为主语写其行动；条目未指定主体时按叙述风格自由选择。
2. 独立与防越权：选项独立于正文，选项描述的行动不算已发生；每条选项只写行动主体自己的行动与台词，不许预判或替演行动落地后其他角色的反应（别写"对方笑了""他松了口气"这种）。
3. 直接引语：含言语交流的选项，对白必须以『……』完整给出、可直接朗读，禁止"说……""问道……"式转述概括；纯动作/观察选项不强制。
4. 场景贴合与具体钩子：每条选项必须是当前剧情此刻能成立的具体动作或事件，且须点名场景里一个具体可见细节（道具/NPC状态/上一句台词/空间特征），禁用"利用环境""观察四周"这类泛词。
5. 活人感多样性：条目之间在行动方式、情绪色彩、语域上拉开差距；每轮允许 0-1 条「不行动/撤离/改话题」选项（装没听见、转移话题、暂离都算）；每条带可辨识情绪立场，整批色板要有跨度，别一个模子。
6. 赌注跨度：选项集须跨低险→高险概率，不准全停中等安全区。
7. emoji：每条选项的内容开头可用一个 emoji 表达该选项的情绪或意图（也可不用），格式仍为 "[标题]emoji 内容"。
8. 输出纯净度：除 <thinking> 和 <options> 标签及其内容外，不输出任何文字。
9. 反八股：不准出八股选项——同一批内句式长短、节奏、开头方式要错开，也禁止轮轮都是"动作+对白"同一副骨架、连标题都套同一模板。
10. 情绪分寸：一律不写带偏执极端、掌控支配、占有欲、臣服讨好等极端情绪与话语的选项，无论行动主体是 {{user}} 还是在场角色、也无论候选条目是否指向此类方向——条目 [规则] 若指向这类方向，守其余写作约束的同时绕开极端化措辞，或改选更贴合且不踩此线的候选。第 6 条赌注跨度指行为后果的冒险程度，不是把情绪烈度拉满到极端人格化。
11. 条目规则：候选条目可能带 [规则: xxx] 标记，选用了就得严守其写作约束；不许嫌规则麻烦就躲开可用条目，但因方向跟当前场景不贴合而不选用是正常的。`,
  ],
  // v40：thinking_prompt 增加记忆提醒与 current_scene 钩子分析
  // ① 简洁版记忆提醒插入（from 包含后续换行+步骤1锚点，保证非 to 子串、幂等）
  [
    '确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文：\n1. 当前情境盘点：',
    '确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文：\n\n<user_persona> 标签内是 {{user}} 的人物设定，思考时只需回忆其中的关键信息，不要把标签包裹的全文堆进思考。\n1. 当前情境盘点：',
  ],
  // ② 全向版记忆提醒插入（结尾差异"喵~"保证不与简洁版交叉命中）
  [
    '确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文喵~\n1. 当前情境盘点：',
    '确认没看漏。然后按下面的框架想，每步一两句给结论就好，别写成散文喵~\n\n<user_persona> 标签内是 {{user}} 的人物设定，思考时只需回忆其中的关键信息，不要把标签包裹的全文堆进思考。\n1. 当前情境盘点：',
  ],
  // ③ 步骤 1 钩子分析扩展（简洁+全向共用：step1 文本两源逐字相同）
  [
    '1. 当前情境盘点：这是什么地方、场景里有什么可交互的东西（道具/物件/设施/环境条件）；谁在场、彼此什么关系（亲疏/立场/上下位）、各自处于什么空间位置（远近/朝向/能否直接接触）；各方（含 {{user}}）此刻各自能做些什么；正文末尾停在哪个留白上，顺着这个场景推一步——接下来怎样走最自然合理。',
    '1. 当前情境盘点：<current_scene> 内可能含多个角色、多条对白、多个行动——先辨明哪部分是当前场景的"钩子"（选项针对的留白），然后盘点这是什么地方、场景里有什么可交互的东西（道具/物件/设施/环境条件）；谁在场、彼此什么关系（亲疏/立场/上下位）、各自处于什么空间位置（远近/朝向/能否直接接触）；各方（含 {{user}}）此刻各自能做些什么；正文末尾停在哪个留白上，顺着场景推演：先辨认角色最新一条行为、对白、动作与场景交互各自抛出了什么，再推演 {{user}} 此刻能够做出的最合理回应——选项就是这次推演的落点，只锚定当下，不回跳旧剧情节点。',
  ],
];

export const SCHEMA_VERSION = 74;

// ── 统计滑动窗口与建议引擎常量（单一事实来源，组件/统计核心共用）───────────────
/** 滑动窗口上限：recent 最多保留最近 N 轮，超出 FIFO 挤掉最旧 */
export const STATS_WINDOW_SIZE = 50;
/** 建议最少样本轮次：窗口长度（或全量参与轮次）≥ 此值才出建议，样本不足只标「样本不足」 */
export const SUGGEST_MIN_SAMPLES = 10;
/** 建议阈值（超额命中率 = 实际命中率 - 期望命中率，期望 = Σ(matched/count) 平均）：
 *  低于期望 20pp → 候选降权；高于期望 15pp → 表现良好（可提权）。
 *  建议引擎永不产生「停用」动作（只改权重）：极端条目最多降到 SUGGEST_WEIGHT_MIN，绝不置 enabled=false。
 *  启发式常量，随数据积累调参。 */
export const SUGGEST_DOWNGRADE_EXCESS = -0.2;
export const SUGGEST_UPGRADE_EXCESS = 0.15;
/** 建议写入的权重边界：降权减半（下限 0.2）、提权按 SUGGEST_UPGRADE_MULTIPLIER
 *  （上限 5），防反复提权/降权失控。这是自动化改写逻辑，不是对用户输入值的 clamp。 */
export const SUGGEST_WEIGHT_MIN = 0.2;
export const SUGGEST_WEIGHT_MAX = 5;
/** 回捞（恢复）目标权重：低于此值的条目在中性带（excess 未到降权阈值）且冷却期结束后，
 *  按 SUGGEST_UPGRADE_MULTIPLIER 逐步向本值回升，防止池子收敛成少数固定选项、保住多选项多样性。
 *  与条目默认权重 1 对齐。 */
export const SUGGEST_WEIGHT_DEFAULT = 1;
/** 建议提权幅度：表现良好条目 × 此倍率（保守化 1.5，非翻倍）——
 *  提权不改变期望基线（期望只依赖输出条数与匹配），高权重条目曝光更多匹配机会、
 *  稳定采用时易持续提权；放缓幅度让权重向 MAX 收敛变慢，缓解权重分散度劣化。
 *  降权仍按减半（与提权不对称是刻意设计：降权应果断，提权应保守）。 */
export const SUGGEST_UPGRADE_MULTIPLIER = 1.5;
/** 阵容计划补入探索上限：剩余空位 × 该比例（向上取整）后从未入池条目补入。
 *  余下空位保持空缺——纯「杀低捧高」会把候选集收敛成少数几条，探索预算是多样性兜底。 */
export const ROSTER_EXPLORE_RATIO = 0.5;
/** 评级阈值 SE 自适应系数：实际阈值 = max(固定阈值, SE×本系数)，SE = sqrt(rate(1−rate)/n)。
 *  小样本命中率噪声大（10 轮边缘 ±0.2 的超额一半是噪声），样本越少门槛越高防抖动建议；
 *  rate→0/1 时 SE→0，回落固定阈值（SUGGEST_DOWNGRADE_EXCESS / SUGGEST_UPGRADE_EXCESS） */
export const SUGGEST_THRESHOLD_SE_FACTOR = 1.5;
/** 冷却墙钟上限：自动化调整后超过此时长且已有 ≥ SUGGEST_COOLDOWN_MIN_POST 轮新数据时，
 *  放宽「足 SUGGEST_MIN_SAMPLES 轮才评级」的冷却门槛。低权重条目参与频率近似正比权重，
 *  纯按参与轮数等门槛会形成「权重越低观察期越长」的冷却黑洞，墙钟兜底；
 *  放宽后的小样本噪声由 SUGGEST_THRESHOLD_SE_FACTOR 兜住 */
export const SUGGEST_COOLDOWN_MAX_MS = 7 * 24 * 60 * 60 * 1000;
/** 冷却放宽所需的最低调整后新数据轮数（见 SUGGEST_COOLDOWN_MAX_MS） */
export const SUGGEST_COOLDOWN_MIN_POST = 3;
/** 期望基线多点选校正启用门槛：scope 总轮数 ≥ 此值才启用平均点选数 m̄ 修正（样本不足
 *  不猜，回退单点模型 matched/count）。见 ScopeStats.total_rounds / scopeAvgPicks */
export const AVG_PICKS_MIN_ROUNDS = 10;
/** 自动化应用历史槽上限：超过后 FIFO 丢最旧，保证撤销入口始终指向最近 N 次写入 */
export const APPLY_HISTORY_LIMIT = 20;
/** AI 建议分析单批条数上限：一次请求只发送 ≤ 此数的条目（控制单次 token 与输出解析难度） */
export const AI_ANALYSIS_BATCH_SIZE = 20;
/** AI 建议分析单个维度条目上限：有建议条目超过此数时按参与轮次截断（避免无限请求） */
export const AI_ANALYSIS_MAX_ENTRIES = 100;
/** 统计页自动分析的防抖毫秒数：快速切维度时不连发请求，停稳后才评估 */
export const AI_ANALYSIS_DEBOUNCE_MS = 1000;
/** AI 理由最大字符数：prompt 约束与展示截断共用，防止单条理由刷屏 */
export const AI_REASON_MAX_CHARS = 60;
/** L1 AI 归因后台队列上限：超出后丢最旧（宁可丢失不积压）——坏 API 串行重试可能
 *  阻塞队列数分钟，无上限会让积压请求无限膨胀且刷新即丢，丢了反正静默保留 Dice 结果 */
export const AI_ATTRIBUTION_QUEUE_MAX = 32;

/**
 * 选项→条目精确归因的文本相似度阈值（字符 2-gram Dice，见 option-attribution.ts）。
 * 生成时对每条输出选项与候选条目（type+content 信号）算相似度，≥ 阈值即认定归属该条目；
 * 低于阈值视为 AI 自由发挥（matchedEntryId = null，不产生命中）。type 前缀精确匹配
 * 优先于本阈值兜底（AI 常以 type 名开头写选项）。启发式常量，随真实数据表现调参。
 */
export const OPTION_MATCH_THRESHOLD = 0.25;
/**
 * Dice 兜底归因的最优-次优差值下限：最高分与次高分拉开不足此差距时，两条目归属近随机
 * （命中谁基本是掷硬币，污染命中/期望记账），归 null（宁缺勿错，与 L1 保守哲学一致）。
 * 仅约束 Dice 兜底路径；type 前缀精确匹配不受影响。
 */
export const OPTION_MATCH_MARGIN = 0.05;

export const WorldInfoGlobalSettings = z
  .object({
    enabled: z.boolean().default(true),
    global_excluded_books: z.array(z.string()).prefault([]),
    // 世界书条目 EJS 渲染开关。开 = 拿到世界书 buckets 后对 content 先展宏 {{}} 再执行
    // 提示词模板插件暴露的 evalTemplate(<% %>)，让「按好感度切换人设」等动态条目拿到成品。
    // 默认开：未装提示词模板插件时安全降级为只展宏（substituteParams），不比现状差；
    // choice 现状连展宏都没做（{{user}} 都不展开），开启顺带修复该 gap。关 = 维持现状不碰。
    // 注意：choice 只检测 globalThis.EjsTemplate 是否存在（插件装了且加载），不跟随插件
    // 自己的 enabled 开关——choice 直接调函数、不走它的事件 hook，两开关各管各的语义
    render_world_info_ejs: z.boolean().default(true),
  })
  .prefault({});
export type WorldInfoGlobalSettings = z.infer<typeof WorldInfoGlobalSettings>;

export const WorldInfoChatSettings = z
  .object({
    /** @deprecated v23 起被三态/自定义条目模式吸收（book_entry_modes + book_entry_overrides），不再读写 */
    excluded_books: z.array(z.string()).prefault([]),
    /** @deprecated v23 起迁移进 book_entry_overrides（false=排除），不再读写 */
    excluded_entries: z.array(z.string()).prefault([]),
    enabled_books: z.array(z.string()).prefault([]),
    /** 已启用书的条目模式（键=书名）：off=条目全关（生成时整本不注入）、
     *  follow=条目启用（尊重酒馆条目 disable + 覆盖，默认）、force=条目全启用（无视一切关闭态）、
     *  custom=自定义（按 book_entry_overrides 逐条生效，由手动勾选任意条目进入）。 */
    book_entry_modes: z.record(z.string(), z.enum(['off', 'follow', 'force', 'custom'])).prefault({}),
    /** 自定义模式下的逐条覆盖（键=书名，内层键=uid 字符串，值=条目启用态）。仅 custom 模式生效。 */
    book_entry_overrides: z.record(z.string(), z.record(z.string(), z.boolean())).prefault({}),
  })
  .prefault({});
export type WorldInfoChatSettings = z.infer<typeof WorldInfoChatSettings>;
export type WIBookMode = 'off' | 'follow' | 'force' | 'custom';

const UISettings = z
  .object({
    floating_enabled: z.boolean().default(true),
    /**
     * 聊天界面选项面板开关：false 时主面板（#chat 内 / 输入框上方停靠）整组隐藏，
     * 且 panel-mount 注入的润色按钮同步隐藏；弹窗（FloatingOptions）不提供润色。
     * store 数据同步与自动生成照常运行（弹窗读同一 panelStore）。
     * 老存档缺字段由 default(true) 补齐：升级零变化，无需 bump schema_version
     */
    chat_panel_enabled: z.boolean().default(true),
    /**
     * 悬浮球单击行为：options = 单击切换选项弹窗（FloatingOptions，现状）；
     * settings = 单击打开/关闭设置面板。右键/长按快捷菜单不受影响，
     * 始终提供「查看行动选项 / 打开设置」两个入口，两种模式下弹窗与设置都可达。
     * 老存档缺字段由 default('options') 补齐，无需 bump schema_version
     */
    bubble_click_action: z.enum(['options', 'settings']).default('options'),
    /**
     * 悬浮球弹窗锁定时的「移出淡化」开关：false 时锁定态移出选项栏不降低透明度。
     * 仅锁定 + 支持 hover 的设备生效（触屏无 hover 不淡化）。
     * 老存档缺字段由 default(true) 补齐，无需 bump schema_version
     */
    floating_dim_enabled: z.boolean().default(true),
    /**
     * 酒馆输入框左侧魔棒（扩展程序）菜单里的「行动选项」入口显隐开关。
     * 仅控制 #extensionsMenu 中 #choice_wand_container 的显示（wand-menu.ts 订阅本字段
     * 即时同步），不影响选项面板、悬浮窗等其他入口。
     * 老存档缺字段由 default(true) 补齐：升级零变化，保持既有默认可见行为
     */
    wand_menu_enabled: z.boolean().default(true),
    /**
     * 统计页「只看有数据」筛选开关持久化：勾选后切 tab/关面板/刷新不丢。
     * 老存档缺字段由 default(false) 补齐，无需 bump schema_version
     */
    stats_only_with_data: z.boolean().default(false),
    enrich_enabled: z.boolean().default(true),
    enrich_count: z.string().default('4'),
    /** @deprecated 已迁移到 theme_mode，保留用于向后兼容迁移 */
    theme: z.enum(['dark', 'light']).optional(),
    /**
     * 主题模式。auto = 自动检测 ST 亮/暗，st = 完全跟随 ST 配色，dark/light = 手动覆盖；
     * dusk/sakura/celadon/honey = 独立预设主题（theme.css 各有一套完整 token 块，
     * 展示名与循环顺序见 src/core/theme-presets.ts，两处勿各自增删）。
     * 旧存档值是本枚举子集，直接兼容，无需迁移。
     */
    theme_mode: z.enum(['auto', 'st', 'dark', 'light', 'dusk', 'sakura', 'celadon', 'honey']).default('auto'),
    opacity: z.number().min(0.3).max(1).default(0.88).catch(0.88),
    font_size: z.enum(['small', 'medium', 'large']).default('medium'),
    /**
     * 字体档是否跟随设备：true 时忽略 font_size，触屏（pointer: coarse）默认 small、
     * 桌面 medium——手机用户对字体档的显式选择（写 font_size 且本字段置 false）
     * 永远优先。旧存档缺本字段由 default(true) 补齐：存量手机用户立即拿到小字，
     * 与"手机端字体默认应为小"的需求一致；点一次具体档位即可固定
     */
    font_size_auto: z.boolean().default(true),
    /**
     * 行动选项面板停靠位置：chat = 跟随最新楼层下方（聊天流内，随聊天滚动）；
     * input = 固定停靠在输入框上方（不随聊天滚动，展开限高滚动——选项再多也不
     * 覆盖整屏）。挂载位置由 panel-mount 的 reposition 按 此字段 幂等切换
     */
    panel_position: z.enum(['chat', 'input']).default('chat'),
    /** 行内设置面板内容区高度（px），拖拽手柄可调整 */
    panel_height: z.number().min(300).max(800).default(500).catch(500),
    /**
     * 新手引导是否已完成/跳过。三个触发方共享这一个开关：首启欢迎卡（启动 3s 后）、
     * 首次打开设置面板（maybeAutoOpenOnboarding）、生成遇 API 未配置的自动召回
     * （openApiOnboarding）。任一弹出瞬间就置 true（而非关闭时），防止用户中途刷新
     * 页面导致反复打扰；重看走设置面板 tab 栏 🎓 功能课堂，不受本字段限制。
     * 恢复出厂后归 false，下次会再弹一次，属预期行为
     */
    onboarding_done: z.boolean().default(false),
    /**
     * 面板状态锁：off = 自动化模式（生成后展开/点选项后收起等现状行为）；
     * open/collapsed = 锁定展开/收起，4 处自动化点位全部跳过。锁定期间手动
     * 切换展开/收起仍有效，并同步更新本字段——锁的是「自动化」而非「面板」，
     * 用户把面板停在哪个状态，刷新后仍是哪个状态。
     * 老存档缺字段由 default 补齐（validateInplace 每次 parse 都会填充），
     * 无需 bump schema_version 迁移。
     */
    panel_lock: z.enum(['off', 'open', 'collapsed']).default('off'),
    /**
     * 高级功能开关（纯 UI 分层）：false = 简化模式，设置面板只显示基础 tab
     * （pool/generation/api/stats/appearance），提示词/世界书/过滤/调试入口与对应引导章节隐藏；
     * true = 全量 tab。仅做 UI 隐藏——过滤规则/世界书注入等运行时行为照常生效，
     * 已配置数据不动。老存档（schema < 43）由迁移块统一置 true（升级零变化），
     * 全新档走 zod default(false) 即简化模式，降低新用户首启认知负荷。
     */
    advanced_features_enabled: z.boolean().default(false),
    /**
     * 选项 HUD 化总开关：false = 关闭分级色条/悬停增强/滑入动画/已选打勾全部视觉增强
     * （选项仍按基础卡片样式渲染）。AI 输出侧是否带风险档位标注不受本字段影响——
     * 关闭时标注存在也按中性显示。老存档缺字段由 default(true) 补齐，无需 bump schema_version
     */
    hud_enabled: z.boolean().default(true),
    /**
     * 悬浮球选项弹窗锁（与聊天面板锁 panel_lock 解耦，off/open 二态）：
     * off = 点选项后弹窗收起、外部点击/Esc 可关闭；open = 弹窗常开，点选项/外部点击/Esc 均不收起。
     * 聊天面板的 panel_lock 管面板展开/收起自动化，互不影响。
     * 老存档缺字段由 default('off') 补齐，无需 bump schema_version
     */
    floating_options_lock: z.enum(['off', 'open']).default('off'),
    /**
     * 聊天面板「点击聊天正文收起」：false = 关闭（现状）；true = 展开的面板在用户点击
     * 面板外普通聊天正文/空白处时收起。仅收起、不反向弹开；链接/按钮/输入框/工具栏等
     * 交互元素不触发（.mes 本体不排除——手机端整屏文字也可收起）。
     * 老存档缺字段由 default(false) 补齐，无需 bump schema_version
     */
    panel_collapse_on_outside_click: z.boolean().default(false),
    /**
     * 悬浮球样式：ring = 现状环形（桌面 60 / 手机 48）；compact = 紧凑小点（桌面 48 / 手机 40），
     * 削弱内环装饰、呼吸更静，手机端更不遮挡。直径计算见 floating-state 的 bubbleSizeFor。
     * 老存档缺字段由 default('ring') 补齐，无需 bump schema_version
     */
    bubble_style: z.enum(['ring', 'compact']).default('ring'),
    /**
     * 选项面板正文字号档（独立于全局 font_size/--choice-font-scale）：
     * 仅作用聊天面板内 .choice-option-btn/.choice-option-content 的缩放，
     * 悬浮球弹窗有自己独立的 floating_option_font_size，互不影响；设置面板不受影响。
     * option_font_size_auto=true 时忽略本字段（跟随全局档，scale=1）。
     * 老存档缺字段由 default('medium') 补齐
     */
    option_font_size: z.enum(['small', 'medium', 'large']).default('medium'),
    /**
     * 选项面板字号是否跟随全局字号档：true 时 option_font_size 不生效（面板 scale=1，
     * 由 --choice-font-scale 全局缩放统一接管）；false = 面板独立档生效。
     * 语义同 font_size_auto。老存档缺字段由 default(true) 补齐
     */
    option_font_size_auto: z.boolean().default(true),
    /**
     * 选项面板展开高度（px）：>0 = 面板 body max-height 用该值（拖动条回写）；
     * 0 = 自动（沿用 45dvh / docked 40dvh 上限）。不与字号档联动。
     * 老存档缺字段由 default(0) 补齐，无需 bump schema_version
     */
    option_panel_height: z.number().min(0).max(1000).default(0).catch(0),
    /**
     * 悬浮球弹窗宽度（px）：>0 = 用该值；0 = 自动（320，视口窄就放给视口）。
     * 悬浮球弹窗是独立 UI、独立于聊天面板的尺寸设置；进调整态拖对角把手回写。
     * 老存档缺字段由 default(0) 补齐，无需 bump schema_version
     */
    floating_popover_width: z.number().min(200).max(720).default(0).catch(0),
    /**
     * 悬浮球弹窗选项区高度（px）：>0 = 选项 body 限高用该值；0 = 自动（55dvh）。
     * 与 option_panel_height 各自独立（悬浮球浮层、聊天面板锚底部，场景不同）。
     * 老存档缺字段由 default(0) 补齐，无需 bump schema_version
     */
    floating_popover_height: z.number().min(0).max(1000).default(0).catch(0),
    /**
     * 悬浮球弹窗正文字号档（独立于聊天面板 option_font_size）：
     * 影响 .choice-floating-options 内 .choice-option-* 的缩放；
     * floating_option_font_size_auto=true 时忽略本字段（跟随全局，scale=1）。
     * 老存档缺字段由 default('medium') 补齐，无需 bump schema_version
     */
    floating_option_font_size: z.enum(['small', 'medium', 'large']).default('medium'),
    /**
     * 悬浮球弹窗字号是否跟随全局字号档：true 时 floating_option_font_size 不生效
     * （弹窗 scale=1，由 --choice-font-scale 全局缩放统一接管）。
     * 老存档缺字段由 default(true) 补齐，无需 bump schema_version
     */
    floating_option_font_size_auto: z.boolean().default(true),
  })
  .prefault({});
type UISettings = z.infer<typeof UISettings>;

// ── 行动选项统计（v51 起按 config 维度记录，随 extension_settings 持久化）───────────
// 口径约定：
//  - 「行动选项」视图：AI 每轮生成的选项（去重/补齐后实际保留条数）计生成，用户点击应用
//    计选择；润色视图（enrich）完全不计入（见 src/core/stats.ts）。
//  - 归因口径「轮次共现」：选项是 AI 自由生成文本，无选项→条目精确映射，每轮生成/选择
//    整轮归因到该轮全部参与条目（generation.poolEntryIds）。条目级「命中轮次」= 参与的
//    轮次中、有选项被选中的轮次数（同代重复点击去重，依据 last_hit_generation_id）。
//  - 维度：entries 键 = 生效 config.id（无 config 会话 = '__none__'）。全局视图（汇总/
//    趋势/条目榜「全局」档）由所有 scope 聚合推导，单一真相源，不双写。
//  - 期望命中率：该条目在输出中被匹配到 k 条时，用户随机点选的命中概率 = k/count
//    （count = 该轮实际输出条数；匹配 1 条即 1/count，匹配多条基线随之抬高）。
//    expected_sum 累积 Σ(matched/count)，超额命中率 = 命中率 - 期望命中率。建议引擎
//    对比超额而非固定阈值——固定阈值在 count 变化时误判（count=4 随机基线 25%，
//    count=10 为 10%）。v53 前旧口径按恒 1/count 计，多输出条目基线偏低、
//    超额系统性偏高，新数据按 matched/count 修正。
//  - recent 为滑动窗口（上限 STATS_WINDOW_SIZE）：支持「近 N 轮命中率」与建议引擎；
//    窗口内每轮记 {gid, ts, hit, count}，选择时按 gid 回写 hit。
//  - 老档（v50 及更早）的 by_entry/daily 为跨维度混合数据，无法拆分归因，v51 迁移
//    直接清零重来（用户确认），不保留 legacy 档。
export const StatsRoundRecord = z
  .object({
    /** generation id：选择时按 gid 回写 hit（同一代生成/选择一一对应） */
    gid: z.string().default(''),
    /** 生成时间戳 */
    ts: z.number().default(0),
    /** 本轮是否有命中（recordOptionSelected 回写） */
    hit: z.boolean().default(false),
    /** 本轮实际输出选项条数（期望命中率分母：该条目被匹配到输出时按 matched/count） */
    count: z.number().min(0).default(0).catch(0),
    /** 本轮该条目在输出中被匹配到的选项数（v53 精确归因写入；老记录缺省 undefined →
     *  窗口期望回退按 1/count 计——与新代 matched=1 数值一致，保持旧档口径不回归） */
    matched: z.number().min(0).optional(),
  })
  .prefault({ gid: '', ts: 0, hit: false, count: 0 });
export type StatsRoundRecord = z.infer<typeof StatsRoundRecord>;

/** 单条目统计（按维度 scope 记录；条目显示信息读取时 join master_pool，已删除条目保留计数） */
export const StatsEntryEntry = z
  .object({
    /** 参与生成轮次（该条目出现在 generation.poolEntryIds 的轮次数，精确） */
    rounds_included: z.number().min(0).default(0).catch(0),
    /** 命中轮次（选项被选中且精确归因匹配到该条目的轮次；旧代无 matchedEntryId 的点击回退整轮共现） */
    rounds_with_selection: z.number().min(0).default(0).catch(0),
    /** 期望命中率之和 = Σ(输出中被匹配轮的 matched/count)（采纳感知随机基线：
     *  该条目被匹配到的输出数 ÷ 输出条数，用户随机点选命中其任一输出的概率；
     *  老数据混有旧口径 Σ(1/count)，混用期偏小属可接受过渡） */
    expected_sum: z.number().min(0).default(0).catch(0),
    /** 滑动窗口（FIFO，上限 STATS_WINDOW_SIZE）：窗口超额命中率由 recent 实时推导。
     *  窗口滚动挤掉的旧代再被点击时全量计数照记、窗口回写跳过（滚动样本，可接受）。 */
    recent: z.array(StatsRoundRecord).prefault([]),
    last_selected_at: z.number().default(0),
    /** 最近一次命中时被选的选项正文（parse 后，去 [类型] 标头/分隔符）：
     *  供统计页展示「最近选中」与未来选项→条目近似归因种子。单槽近似，非历史 log。 */
    last_selected_text: z.string().default(''),
    /** 最近参与生成的时间戳（recordOptionsGenerated 写入），供统计页展示「最近参与」 */
    last_included_at: z.number().default(0),
    /** 最近一次自动化调整（建议应用/阵容落出/补入改写 weight 或 enabled）的时间戳。
     *  0 = 从未被自动化调整过。建议引擎冷却依据：有该标记时 entryMetrics 只统计
     *  此时间戳之后的窗口记录，不足 SUGGEST_MIN_SAMPLES 轮新数据视为「冷却中」不出
     *  建议——防止 1↔2↔4 权重颠簸，且保证建议永远基于新权重下的真实表现。
     *  老档缺字段由 default(0) 补齐，行为等同从未调整，无需 bump schema_version。 */
    last_weight_changed_at: z.number().min(0).default(0).catch(0),
  })
  .prefault({});
export type StatsEntryEntry = z.infer<typeof StatsEntryEntry>;

/** 单日生成/选择活动计数（scope.daily 的值，键为本地时区 YYYY-MM-DD） */
export const DailyCount = z
  .object({
    generated: z.number().min(0).default(0).catch(0),
    selected: z.number().min(0).default(0).catch(0),
  })
  .prefault({});
export type DailyCount = z.infer<typeof DailyCount>;

/** AI 建议分析单条目结果（stats.ai_analysis[scope].entries 的值）：
 *  reason 为自然语言理由（仅展示，不参与动作判定），confidence 为 0-1 置信度。
 *  suggestion_key 为分析时该条目建议的稳定指纹（见 stats.suggestionKey）：展示侧
 *  校验「当前建议指纹 === 缓存指纹」才显示理由——建议消失/变化（配置写入等不触发
 *  重跑的路径）后旧理由立即隐藏，杜绝「建议停用的理由挂在已无建议/改目标的条目上」。 */
export const AiAnalysisEntry = z.object({
  reason: z.string().default(''),
  confidence: z.number().min(0).max(1).default(0).catch(0),
  suggestion_key: z.string().default(''),
});
export type AiAnalysisEntry = z.infer<typeof AiAnalysisEntry>;

/** AI 建议分析单维度缓存（stats.ai_analysis[scope]）：最近一次运行的整体快照。
 *  data_updated_at 为运行时 stats.updated_at 快照，用于「有新数据才重算」失效判定；
 *  entries 键 = entryId（只含「有统计建议的条目」，其余不分析）。新运行整体覆盖旧结果。 */
const AiAnalysisScope = z.object({
  /** 本次分析完成时间戳 */
  updated_at: z.number().default(0),
  /** 分析时的 stats.updated_at 快照：stats.updated_at > 此值 = 有新数据、需要重算 */
  data_updated_at: z.number().default(0),
  entries: z.record(z.string(), AiAnalysisEntry).prefault({}),
});
type AiAnalysisScope = z.infer<typeof AiAnalysisScope>;

/** 单个统计维度（scope = 生效 config.id，无 config 会话为 '__none__'） */
export const ScopeStats = z
  .object({
    total_generated: z.number().min(0).default(0).catch(0),
    total_selected: z.number().min(0).default(0).catch(0),
    /** 成功生成轮数（每轮 recordOptionsGenerated +1，与输出条数无关）：平均点选数
     *  m̄ = picks_total / total_rounds 的分母——多点选用户的期望基线校正因子（单点模型
     *  matched/count 系统性低估基线、超额偏高偏提权）。老档缺字段由 ?? 0 兜底（视为
     *  未启用校正），无需 bump schema_version */
    total_rounds: z.number().min(0).optional(),
    /** 点选次数（recordOptionSelected 每次点击 +1，与 total_selected 同口径、不做同代
     *  去重——重复点击也是点选习惯的一部分）。老档缺字段由 ?? 0 兜底 */
    picks_total: z.number().min(0).optional(),
    /** 本维度最近一次活动（生成/选择）时间戳：AI 建议分析按它做失效判定——
     *  全局 stats.updated_at 会被其他维度活动带动，导致无关维度缓存误失效、全量重跑 */
    updated_at: z.number().default(0),
    by_entry: z.record(z.string(), StatsEntryEntry).prefault({}),
    /** 按天活动计数（趋势图数据源，per-scope）：generated 跟随本 scope 实际保留条数、
     *  selected 跟随点击次数（不做同代去重——反映"点击活跃度"） */
    daily: z.record(z.string(), DailyCount).prefault({}),
  })
  .prefault({});
export type ScopeStats = z.infer<typeof ScopeStats>;

/** 骰子各结局计数。战绩独立于条目池统计，不参与建议或权重。
 *  仅被 DiceStats 内部引用（通过 DiceStats 类型向外部暴露），无需独立导出 */
const DiceOutcomeCounts = z
  .object({
    crit_success: z.number().min(0).default(0).catch(0),
    success: z.number().min(0).default(0).catch(0),
    fail: z.number().min(0).default(0).catch(0),
    crit_fail: z.number().min(0).default(0).catch(0),
  })
  .prefault({});
type DiceOutcomeCounts = z.infer<typeof DiceOutcomeCounts>;

/** 单次骰子判定历史条目（v61）。text = parse 后选项正文的短摘要，rate = 本次判定的实际
 *  比较目标（D100 为需求值、骰式为映射 DC），roll = 点数/骰式总和，outcome = 结局。
 *  供统计页最近判定回顾；不参与条目建议/权重/AI 分析。 */
const DiceHistoryEntry = z
  .object({
    ts: z.number().default(0),
    text: z.string().default(''),
    rate: z.number().default(0),
    roll: z.number().default(0),
    outcome: z.enum(['crit_success', 'success', 'fail', 'crit_fail']).default('fail'),
  })
  .prefault({});
type DiceHistoryEntry = z.infer<typeof DiceHistoryEntry>;

/** 全局骰子战绩；daily 使用本地时区 YYYY-MM-DD。history 为最近判定日志（v61），
 *  上限 DICE_HISTORY_LIMIT 由 stats.ts 固化，超出丢最旧。 */
export const DiceStats = z
  .object({
    total_rolls: z.number().min(0).default(0).catch(0),
    by_outcome: DiceOutcomeCounts.prefault({}),
    daily: z.record(z.string(), DiceOutcomeCounts).prefault({}),
    /** 最近判定历史（FIFO，v61）：随 stats_enabled 采集，清空统计一并清除 */
    history: z.array(DiceHistoryEntry).prefault([]),
    updated_at: z.number().default(0),
  })
  .prefault({});
export type DiceStats = z.infer<typeof DiceStats>;

// ── 卡牌系统（v62 增量字段，全走 zod default/prefault 补齐，不 bump schema_version）────────
// 每张卡是可装备的效果卡：触发条件（选项类型/档位/需求区间/骰值区间/结局）+ 效果
// （骰值/需求/彩蛋窗口修正、结局转化、强制重掷、叙事展示）。收藏全局 + 按 config 装备。
// 卡为永久收藏但 v70 起恢复触发磨损与破损修复（耐久归零破损、行动币修复回满）；
// 角色主题池由 AI 按角色卡世界观懒生成、可重复掉落。
// 货币「行动币」由骰子结局收支 + 重复卡折算获得，新增修复支出形成消耗闭环。

/** 星级：1星至5星（抽卡权重递减，高星装备数量受预算限制） */
export const CARD_STARS = ['1', '2', '3', '4', '5'] as const;
export type CardStar = (typeof CARD_STARS)[number];
/** 卡类型：武器/法术/祝福/试炼（装备位同类最多 1 张，效果定位见 cards-builtin.ts） */
export const CARD_TYPES = ['weapon', 'spell', 'blessing', 'trial'] as const;
export type CardType = (typeof CARD_TYPES)[number];
/** 卡来源：builtin = 内置（全球反复掉落）；character = 角色主题池（懒生成、可重复掉落）。
 *  联合类型由 z.enum(CARD_SOURCES) 经 z.infer 推导，不另立别名。 */
export const CARD_SOURCES = ['builtin', 'character'] as const;

/** 卡触发条件：单对象含可选字段，按 kind 取值匹配。kind 语义：
 *  type = 选项类型（parseOptionType 命中 typeValue）；grade = 风险档位（conservative/balanced/bold）；
 *  demand = 需求值区间 [min,max]；roll = 骰值区间 [min,max]；outcome = 判定结局。 */
export const CardTrigger = z
  .object({
    kind: z.enum(['type', 'grade', 'demand', 'roll', 'outcome']).default('type'),
    typeValue: z.string().default(''),
    grade: z.enum(['conservative', 'balanced', 'bold']).nullable().default(null),
    min: z.number().default(0),
    max: z.number().default(0),
    outcome: z.enum(['success', 'fail', 'crit_success', 'crit_fail']).nullable().default(null),
  })
  .prefault({});
export type CardTrigger = z.infer<typeof CardTrigger>;

/** 卡效果（六类）：roll_bonus 掷骰前 ±；demand_mod ±DC；crit_window 扩/收彩蛋区间；
 *  outcome_convert 结局转化；reroll 强制重掷；narrative 卡面叙事展示（不注入正文 AI
 *  判定注释，只作卡面展示——注入移除见判定注释机制行取舍）。 */
export const CardEffect = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('roll_bonus'), amount: z.number().default(0) }),
  z.object({ kind: z.literal('demand_mod'), amount: z.number().default(0) }),
  z.object({
    kind: z.literal('crit_window'),
    success_delta: z.number().default(0),
    fail_delta: z.number().default(0),
  }),
  z.object({
    kind: z.literal('outcome_convert'),
    /** from 含 crit_fail（v66 后扩）：大失败→大成功为 5★ 专属强力转化 */
    from: z.enum(['fail', 'crit_fail', 'crit_success']),
    to: z.enum(['success', 'crit_success']),
  }),
  z.object({ kind: z.literal('reroll'), on: z.enum(['fail', 'crit_fail']).default('fail') }),
  z.object({ kind: z.literal('narrative'), text: z.string().default('') }),
]);
export type CardEffect = z.infer<typeof CardEffect>;

/** 卡定义（内置 or 角色主题池卡）。内置卡 id 稳定；角色卡 id=uuidv4() 且归组到角色池。 */
export const Card = z
  .object({
    id: z.string(),
    name: z.string(),
    type: z.enum(CARD_TYPES),
    star: z.enum(CARD_STARS),
    trigger: CardTrigger.prefault({}),
    effects: z.array(CardEffect).prefault([]),
    /** 卡面叙事文本（仅展示，不注入正文 AI） */
    narrative: z.string().default(''),
    source: z.enum(CARD_SOURCES),
    /** 角色主题卡归属：source='character' 时填生成它的角色 id/名（内置卡为空），
     *  供卡面角标区分「这张主题卡属于哪个角色」，避免多池混排时认不出。 */
    character_id: z.string().default(''),
    character_name: z.string().default(''),
  })
  .prefault(() => ({ id: '', name: '', type: 'weapon', star: '1', source: 'builtin' }));
export type Card = z.infer<typeof Card>;

/** 收藏条目（键 = card_id）：卡为永久收藏，但 v70 起恢复触发磨损与破损修复
 *  （durability 归零 → broken=true 自动卸下禁装，消耗行动币修复回满）。 */
export const CardOwned = z
  .object({
    card_id: z.string().default(''),
    obtained_at: z.number().default(0),
    trigger_count: z.number().min(0).default(0).catch(0),
    /** 当前耐久（0 = 破损）；获取时按星级×功能计算满值，触发扣减 */
    durability: z.number().min(0).default(0).catch(0),
    /** 满耐久（获取时按 cardMaxDurability 计算，详情见 cards-constraints.ts） */
    max_durability: z.number().min(1).default(1).catch(1),
    /** 破损态（持久化，供卡面/装备解析直接判断；durability===0 为等价判定，双保险） */
    broken: z.boolean().default(false),
    source: z.enum(CARD_SOURCES).default('builtin'),
  })
  .prefault({});
export type CardOwned = z.infer<typeof CardOwned>;

/** 历史获得记录（键 = card_id）：与 card_collection（当前持有）分离，记录"曾经获得过"，
 *  收藏进度/成就/套装基于它永久保留。count 为累计获得次数（含重复抽中折算）。 */
export const CardObtained = z
  .object({
    card_id: z.string().default(''),
    obtained_at: z.number().default(0),
    count: z.number().min(1).default(1).catch(1),
  })
  .prefault({});
export type CardObtained = z.infer<typeof CardObtained>;

/** 某 config 的卡组（固定 4 个类型槽，顺序见 CARD_SLOT_TYPES；每槽绑一种类型、只装该类型 1 张，
 *  card_id='' 表示空槽；整组受星级预算约束）。独立 record，不写进 PoolConfig.entries。 */
export const CardDeck = z
  .object({
    config_id: z.string().default(''),
    slots: z.array(z.object({ type: z.enum(CARD_TYPES), card_id: z.string().default('') })).prefault([]),
  })
  .prefault({});
export type CardDeck = z.infer<typeof CardDeck>;

/** 角色 AI 主题卡池：首次幸运掉落需要时懒生成并固定（generated=true）；池内卡反复掉落（重复获得折算）。 */
export const CardCharacterPool = z
  .object({
    character_id: z.string().default(''),
    generated: z.boolean().default(false),
    card_ids: z.array(z.string()).prefault([]),
  })
  .prefault({});
export type CardCharacterPool = z.infer<typeof CardCharacterPool>;

/** 卡牌统计（stats.card，统计层）：随 stats_enabled 采集、clearStats 清。
 *  游戏进度（货币余额/收藏/角色池）放 GlobalSettings，不被清空。 */
export const CardStats = z
  .object({
    lucky_hits: z.number().min(0).default(0).catch(0),
    packs_opened: z.number().min(0).default(0).catch(0),
    cards_obtained: z.number().min(0).default(0).catch(0),
    per_card: z.record(z.string(), z.object({ triggers: z.number().default(0) })).prefault({}),
    currency_earned_by_outcome: z.record(z.string(), z.number().min(0).default(0).catch(0)).prefault({}),
    currency_earned: z.number().min(0).default(0).catch(0),
    currency_spent: z.number().min(0).default(0).catch(0),
    updated_at: z.number().default(0),
  })
  .prefault({});
export type CardStats = z.infer<typeof CardStats>;

export const StatsSettings = z
  .object({
    /** 全局总量（所有 scope 之和，汇总卡片用）。已废弃不再写入（record 只写 scope 级，
     *  不再与顶级字段同步累计），全局视图由 buildStatsView 聚合推导；字段保留仅为旧存档兼容 */
    total_generated: z.number().min(0).default(0).catch(0),
    total_selected: z.number().min(0).default(0).catch(0),
    /** 按 config 维度统计：键 = 生效 config.id，无 config 会话 = '__none__'。
     *  v51 起取代旧 by_entry + daily（老档由迁移块清零）。 */
    entries: z.record(z.string(), ScopeStats).prefault({}),
    /** 最近一次命中（计了命中轮次）的 generation id：同代重复点击只计 1 次命中。
     *  全局单槽（generation id 全局唯一，跨 scope 无碰撞）。 */
    last_hit_generation_id: z.string().nullable().default(null),
    /** AI 建议分析缓存（键 = 统计维度 scopeId）：见 AiAnalysisScope 注释。
     *  只读展示数据，不参与建议引擎/阵容计划判定；清空统计时一并清除。 */
    ai_analysis: z.record(z.string(), AiAnalysisScope).prefault({}),
    /** 骰子判定战绩（全局维度，不随 config 维度）：随 stats_enabled 采集；
     *  不参与条目建议/权重/AI 分析；清空统计时一并清除。 */
    dice: DiceStats.prefault({}),
    /** 卡牌系统统计（统计层，随 stats_enabled 采集、clearStats 清）。游戏进度
     *  （card_currency/card_collection/card_character_pools）放 GlobalSettings，
     *  不被清空——防「清统计把玩家攒的货币抹了」。 */
    card: CardStats.prefault({}),
    updated_at: z.number().default(0),
  })
  .prefault({});
export type StatsSettings = z.infer<typeof StatsSettings>;

/** 构造一份空白卡牌统计（纯数据构造，不依赖任何 store）。统计层随 stats_enabled 采集、
 *  清空统计一并清；游戏进度（卡币/收藏/角色池）放 GlobalSettings 不被清。 */
export function createEmptyCardStats(): CardStats {
  return {
    lucky_hits: 0,
    packs_opened: 0,
    cards_obtained: 0,
    per_card: {},
    currency_earned_by_outcome: {},
    currency_earned: 0,
    currency_spent: 0,
    updated_at: 0,
  };
}

/** 构造一份空白骰子战绩（纯数据构造，不依赖任何 store）。 */
export function createEmptyDiceStats(): DiceStats {
  return {
    total_rolls: 0,
    by_outcome: { crit_success: 0, success: 0, fail: 0, crit_fail: 0 },
    daily: {},
    history: [],
    updated_at: 0,
  };
}

/** 构造一份空白统计（v51 形态）：迁移清零与「清空统计」共用同一真相源，
 *  避免两处各自构造默认对象造成形态漂移。纯数据构造，不依赖任何 store。 */
export function createEmptyStats(): StatsSettings {
  return {
    total_generated: 0,
    total_selected: 0,
    entries: {},
    last_hit_generation_id: null,
    ai_analysis: {},
    dice: createEmptyDiceStats(),
    card: createEmptyCardStats(),
    updated_at: Date.now(),
  };
}

/** 骰子判定设置（v57，难度制）：选项点击时掷 D100 判定成败——AI 标注/档位兜底的数字是
 *  「需求值」，掷出 ≥ 需求才算成功（点数越大越好，与正文 AI 直觉一致；v55 的
 *  「掷 ≤ 率 = 成功」概率制已废弃）。成功/失败/大成功/大失败都按模板给隐形
 *  演绎指令（包在 HTML 注释中对用户全程隐形注入：四种行为输入框只放纯正文，玩家消息
 *  真正发出时由 MESSAGE_SENT 回写进该消息，AI 可见、聊天界面不可见、随消息持久化）。
 *  模板占位符
 *  {rate}/{roll}/{margin}/{degree}（margin = 点数 − 需求，degree 为口语化程度词：
 *  成功侧勉强得手/险胜/顺利达成/漂亮完胜/势如破竹、失败侧差点成功/功亏一篑/事与愿违/溃败/
 *  彻底落败、彩蛋固定
 *  惊艳无比/灾难性失败，见 core/dice.ts marginDegree）。成功/失败按 margin 差值占判定空间
 *  的比例命中档位取对应
 *  send 模板（success_/fail_send_{low,mid_low,mid,mid_high,high}_template）；彩蛋单条。enabled 默认关——存量用户升级零行为变化；老档缺
 *  字段由 prefault({}) 补齐，无需内容迁移（提示词文本变更单独走 v56 迁移；骰子模板拆档单独走 v58 迁移）。
 *  v67：注释改三段结构——代码固定拼结构化头部（结局/裁定对象/点数/需求/差值/程度）+ 模板正文 + 固定纪律
 *  尾注（见 core/dice.ts buildDiceMarker）；12 条 send 模板默认重写为纯演绎指令（数字由头部
 *  承载，默认文案不再重复），存量未自定义的默认经 v67 迁移换新；新增 main_ai_awareness
 *  （正文 AI 常驻契约注入，见 core/dice-contract.ts）。 */

/** v67 起的 12 条 send 模板默认文案（纯演绎指令，数字由代码固定的结构化头部承载）。
 *  schema 默认与 v67 迁移的 to 值共用这一份，防两处字面量漂移。 */
export const SEND_TEMPLATE_DEFAULTS = {
  success_send_low_template:
    'The action just barely reaches the goal line: Please describe the barely achieved achievement with some difficulty and stumbling. You can leave a small price or regret, and do not exaggerate it as an easy victory.',
  success_send_mid_low_template: 'The action has just crossed the target line and the advantage is weak: Please describe a slightly thrilling process of winning in a close call. The result is established but not easy to say.',
  success_send_mid_template: 'Actions are completed neatly and logically: Please describe the process as smooth and the results as solid, without being too showy or sloppy.',
  success_send_mid_high_template:
    'The action was completed with distinction: Focus on the outstanding performance, the brilliance of the extra points, and the incidental benefits or aftertaste.',
  success_send_high_template: 'The action was won in one fell swoop with a crushing momentum: Please focus on describing the overwhelming performance, the incidental chain benefits, and the amazement of others.',
  fail_send_low_template: 'The action is almost done: please describe the shortfall, the gap between success and the chagrin and regret caused by that narrow gap.',
  fail_send_mid_low_template:
    'The action was blocked in the middle and failed to win: Please describe your unwillingness to fail at the last moment, and the room or foreshadowing left by this failure.',
  fail_send_mid_template: 'The result is contrary to expectations: please describe the situation where the action is blocked, the actual direction deviates from the expectation, and the entanglements or troubles caused by it.',
  fail_send_mid_high_template: 'The action was obviously lost and the situation was passive: Please describe the situation of losing ground and being at a disadvantage, as well as the ensuing losses.',
  fail_send_high_template: 'The operation failed miserably: Describe the disgrace and subsequent loss or embarrassment so that the character truly feels the cost of the failure.',
  crit_success_send_template:
    'The action was accomplished in a way that exceeded expectations: Focus on the amazing performance, the admiration of others, and the additional benefits that followed.',
  crit_fail_send_template:
    'The action not only failed, but also caused a serious accident or chain reaction: please describe the catastrophic consequences and make the character pay a real price for this mistake.',
} as const;

export const DiceSettings = z
  .object({
    /** 总开关：关 = 不掷骰、不显示需求值徽标、选项行为与 v54 完全一致 */
    enabled: z.boolean().default(false),
    /** 正文 AI 感知判定注释（v67，默认开）：向正文生成请求常驻注入一段系统说明，
     *  解释玩家消息开头的判定注释并要求遵守（见 core/dice-contract.ts）。关 = 仅靠注释
     *  自解释。仅 dice.enabled 开时生效。 */
    main_ai_awareness: z.boolean().default(true),
    /** 大成功阈值（下限）：掷出 ≥ 本值 → 大成功（默认 96，即顶部 5%，2–100） */
    crit_success_min: z.number().min(2).max(100).default(96).catch(96),
    /** 大失败阈值（上限）：掷出 ≤ 本值 → 大失败（默认 5，即底部 5%，1–99） */
    crit_fail_max: z.number().min(1).max(99).default(5).catch(5),
    /** send 模板为空时使用的回退文案，支持 {rate}（需求值）和 {roll}（点数）。 */
    fail_template: z.string().default('【 judgment failed】'),
    /** 大成功回退文案，同样支持占位符。 */
    crit_success_template: z.string().default('【 great success】'),
    /** 大失败回退文案，同样支持占位符。 */
    crit_fail_template: z.string().default('【 big failure】'),
    /** 成功后回退文案（v57：成功也注入演绎指令），同样支持占位符。 */
    success_template: z.string().default('【 determined successfully 】'),
    /** 隐形演绎指令（按程度档位拆分，v58；v67 起默认为纯演绎指令——结局/裁定对象/点数/需求/差值/程度
     *  由代码固定的结构化头部承载，纪律由固定尾注承载，模板只写演绎要求）：
     *  实际包在 HTML 注释中随消息发送/填入，聊天界面不可见；所有点击行为共用
     *  （send 直接发送、fill/insert/append 填入输入框可编辑）。
     *  成功侧五档 = 勉强得手（low）/险胜（mid_low）/顺利达成（mid）/漂亮完胜（mid_high）/
     *  势如破竹（high），失败侧五档 = 差点成功（low）/功亏一篑（mid_low）/事与愿违（mid）/
     *  溃败（mid_high）/彻底落败（high），按 margin 差值占判定空间的比例（20%/40%/60%/80%）
     *  命中档位取对应模板（v73 起，旧固定绝对值断点废弃）。
     *  某档为空 = 该档回退对应结局的 *template 短文案（同为空则该档不注入）；
     *  占位符 {rate}/{roll}/{margin}/{degree} 全部通用（degree 为 marginDegree 程度词，可选用）。*/
    success_send_low_template: z.string().default(SEND_TEMPLATE_DEFAULTS.success_send_low_template),
    success_send_mid_low_template: z.string().default(SEND_TEMPLATE_DEFAULTS.success_send_mid_low_template),
    success_send_mid_template: z.string().default(SEND_TEMPLATE_DEFAULTS.success_send_mid_template),
    success_send_mid_high_template: z.string().default(SEND_TEMPLATE_DEFAULTS.success_send_mid_high_template),
    success_send_high_template: z.string().default(SEND_TEMPLATE_DEFAULTS.success_send_high_template),
    fail_send_low_template: z.string().default(SEND_TEMPLATE_DEFAULTS.fail_send_low_template),
    fail_send_mid_low_template: z.string().default(SEND_TEMPLATE_DEFAULTS.fail_send_mid_low_template),
    fail_send_mid_template: z.string().default(SEND_TEMPLATE_DEFAULTS.fail_send_mid_template),
    fail_send_mid_high_template: z.string().default(SEND_TEMPLATE_DEFAULTS.fail_send_mid_high_template),
    fail_send_high_template: z.string().default(SEND_TEMPLATE_DEFAULTS.fail_send_high_template),
    crit_success_send_template: z.string().default(SEND_TEMPLATE_DEFAULTS.crit_success_send_template),
    crit_fail_send_template: z.string().default(SEND_TEMPLATE_DEFAULTS.crit_fail_send_template),
    /** 判定方向（v61）：high = 点数越大越好（默认，难度制原语义）；low = 点数 ≤ 需求=成功
     *  （COC 百分位）。low 开启时大成功/大失败彩蛋阈值改用 low_roll_crit_success_max /
     *  low_roll_crit_fail_min（见下）。默认关保持既有判定不变。 */
    low_roll: z.boolean().default(false),
    /** low 模式大成功阈值（上限）：掷出 ≤ 本值 → 大成功（默认 5，COC 百分位，范围 1–99） */
    low_roll_crit_success_max: z.number().min(1).max(99).default(5).catch(5),
    /** low 模式大失败阈值（下限）：掷出 ≥ 本值 → 大失败（默认 96，范围 2–100） */
    low_roll_crit_fail_min: z.number().min(2).max(100).default(96).catch(96),
    /** 角色属性驱动 DC（v61，默认关）：选项无显式需求值时，从当前角色卡解析属性值做需求值；
     *  AI 标注始终优先，属性只替换档位兜底这一级；识别不到静默回退档位兜底。 */
    attr_dc_enabled: z.boolean().default(false),
    /** 允许 AI 标注真实骰式（NdM，如 2d6+3，v61，默认关）：开启后第三段为合法骰式的选项
     *  改掷表达式而非 D100，需求值(0-100)按比映射到骰式值域当 DC。默认关保证不改变既有解析。 */
    allow_formula: z.boolean().default(false),
    /** 就地重掷（v61，默认关）：开启后点选项先掷骰出示 ↻，玩家重掷满意后确认才应用发送；
     *  关闭保持现状（点击即判定+应用）。 */
    reroll_enabled: z.boolean().default(false),
  })
  .prefault({});
export type DiceSettings = z.infer<typeof DiceSettings>;

export const GlobalSettings = z
  .object({
    schema_version: z.number().default(0),
    master_pool: z.array(PoolEntry).prefault([]),
    configs: z.array(PoolConfig).prefault([]),
    group_order: z.array(z.string()).prefault([]),
    prompt_rules: PromptRules.prefault({}),
    prompt_configs: z.array(PromptConfig).prefault([]),
    // FilterSettings 全字段带 default，{} 作为输入 parse 即得全默认对象；
    // 不能用 .default({})：zod4 的 default 参数是输出类型，要求逐字段写全
    filter_settings: FilterSettings.prefault({}),
    apis: z.array(SecondaryApi).prefault([]),
    active_api_id: z.string().default(''),
    world_info: WorldInfoGlobalSettings.prefault({}),
    ui: UISettings.prefault({}),
    stats: StatsSettings.prefault({}),
    /**
     * 统计采集开关（默认关）：关 = 不采集任何统计（recordOptionsGenerated /
     * recordOptionSelected 早退），统计页只显示「统计未开启」横幅 + 历史只读；
     * 开 = 自开启时刻起积累新数据，既有历史数据保留。
     * 与 automation_enabled（自动化开关）相互独立：只想看统计报表的用户开本开关、
     * 不开自动化即可。老档由 default(false) 补齐，无需 bump schema_version
     */
    stats_enabled: z.boolean().default(false),
    /**
     * 自动化开关（默认关，与统计开关相互独立；仅统计开启时有意义）：
     * 关 = 建议引擎/阵容计划/L1 AI 归因/L2 AI 建议理由全部停用，统计页显示纯报表
     * （卡片/趋势/条目榜/命中榜/管理），隐藏 AI 增强/阵容计划/应用历史/建议徽标/
     * 洞察标签等全部自动化区块；开 = 在统计数据基础上启用上述自动化。
     * 只想看统计的用户开 stats_enabled 即可，无需启用本开关。
     * 老档由 default(false) 补齐，无需 bump schema_version
     */
    automation_enabled: z.boolean().default(false),
    /** 阵容计划（固定名额落出/补入）：目标在役条数 N。null = 未设置（计划关闭）；
     *  任意有限数均接受、不做 clamp（项目约束：不改写用户输入），N<1 时 planRoster 返回空计划。
     *  一期为半自动：planRoster 只算清单，应用经统计页确认。 */
    roster_size: z.number().nullable().prefault(null).catch(null),
    /** 统计页阵容计划开关（UI 记忆用；roster_size 为 null 时计划仍不生效） */
    roster_enabled: z.boolean().default(false),
    /**
     * AI 归因增强开关：开 = 每轮行动选项生成后后台异步调 AI 做「选项→候选条目」语义归因，
     * 结果与本地 Dice 归因 diff 后对称修正统计（期望/命中）。默认关：每轮一次外部请求属
     * 持续成本，且把条目内容送往 API；用户显式开启才生效。未配置 API/解析失败时静默降级
     * 为纯 Dice 归因，主功能零依赖。老存档由 default(false) 补齐，无需 bump schema_version
     */
    ai_attribution_enabled: z.boolean().default(false),
    /**
     * AI 建议理由开关：开 = 统计页打开/切维度按需调 AI，为有统计建议的条目生成自然语言
     * 理由（仅展示）；默认开（只在用户查看统计页且数据有更新时触发，频率低、成本可控）。
     * 与归因开关相互独立。老存档由 default(true) 补齐，无需 bump schema_version
     */
    ai_analysis_enabled: z.boolean().default(true),
    /** 自动化应用历史（建议应用/阵容计划应用的持久撤销槽）：按 config 维度记录
     *  应用前/后 entries 快照与冷却标记快照，刷新不丢；上限 APPLY_HISTORY_LIMIT。
     *  放顶层而非 stats 内：「清空统计」不清撤销历史（历史是 config 写入记录，
     *  与统计数据解耦）。老档缺字段由 prefault([]) 补齐，无需 bump schema_version。 */
    apply_history: z.array(ApplyHistoryEntry).prefault([]),
    retry_count: z.number().min(0).max(10).default(0).catch(0),
    /** 重试间隔（秒）。retry_count>0 时，两次重试之间等待的秒数；0=立即重试。
     *  默认 1 保持既有"每次间隔 1 秒"行为，老存档由 default 补齐，无需迁移。 */
    retry_interval: z.number().min(0).max(60).default(1).catch(1),
    // 请求附带 tool_choice:"none"：酒馆助手预设脚本（如 Aether 防截断）会 patch 主窗口
    // window.fetch 并改写一切 /generate 请求，"none" 是其设计内绕过信号（详见
    // api-client.ts 注释）。ST 后端仅在 tools 非空数组时才转发该字段，故它到不了上游，
    // 对生成行为与未启用此类脚本的场景完全无影响；不用 Kemini 类预设时保持默认开即可
    api_tool_choice_none: z.boolean().default(true),
    global_count_mode: z.string().default('4'),
    auto_generate: z.boolean().default(true),
    behavior: z.enum(['send', 'fill', 'append', 'insert']).default('send'),
    /** 骰子判定（v56 难度制）：AI 标注/档位兜底需求值 + D100 随机判定（掷 ≥ 需求值=成功），失败等结局前缀标记 */
    dice: DiceSettings.prefault({}),
    // ── 卡牌系统（v62，游戏进度层；清空统计不清）────────
    /** 卡牌总开关（默认关）：关 = 判定管线不读卡、无卡触发/无幸运开包/无行动币收支，
     *  存量升级零行为变化；收藏库/卡库展示常驻不受开关影响。 */
    card_enabled: z.boolean().default(false),
    /** 收藏库（键 = card_id）：每张当前持有的卡（永久收藏；v70 起含触发磨损与破损修复）。
     *  持有 ≠ 曾获得：图鉴/成就以 card_obtained 为准。 */
    card_collection: z.record(z.string(), CardOwned).prefault({}),
    /** 历史获得记录（键 = card_id，v61）：记录"曾经获得过"的卡，独立于当前持有。
     *  分解只删 card_collection、不删这里，故收藏进度/套装/成就永久保留；v61 迁移把存量收藏补种进来。 */
    card_obtained: z.record(z.string(), CardObtained).prefault({}),
    /** 卡组（键 = config.id）：每个 config 一套卡组，固定 4 个类型槽、同类 ≤1、受星级预算约束。 */
    card_decks: z.record(z.string(), CardDeck).prefault({}),
    /** 全量卡定义（键 = card_id）：内置卡定义在 BUILTIN_CARDS 常量，角色主题卡由 AI 生成后
     *  存这里（card_collection 只记持有与触发计数，不冗余卡效果）。抽卡/装备/展示统一从
     *  本记录 + 内置常量解析卡定义。 */
    card_definitions: z.record(z.string(), Card).prefault({}),
    /** 角色 AI 主题卡池（键 = character id）：首次幸运掉落需要时懒生成并固定；
     *  generated=true 后不再重生成，池内卡反复掉落（重复获得折算）。 */
    card_character_pools: z.record(z.string(), CardCharacterPool).prefault({}),
    /** 行动币余额（全局唯一货币，量级稀有）：骰子结局收支 + 重复卡折算获得；≥0 不扣穿。 */
    card_currency: z.number().min(0).default(0).catch(0),
    /** 自动编组（默认开）：从已拥有卡自动填满 4 槽（守星级预算），玩家零编组负担；
     *  关 = 手动编辑存储卡组。仅影响"谁在槽里"，不改判定语义。 */
    auto_deck_enabled: z.boolean().default(true),
    /** 新手 starter 是否已发放（一次性）：首次启用卡牌且收藏为空时赠 4 张 1★，auto-deck 立即满编。 */
    card_starter_granted: z.boolean().default(false),
    empty_groups: z.array(z.string()).default([]),
    /** 全局抽取参数（分组抽取/打乱结果/固定溢出/冗余比例）。v35 起从 PoolConfig.generation
     *  收归全局：条目池配置收敛为"纯条目引用清单"，切换池配置严禁带动任何生成参数——
     *  历史上生成设置页的冗余比例读生效池配置，切池配置即跳变（用户实测踩雷）。
     *  消费端：generator.resolvePool 入参、GenerationSettings 页冗余比例、PoolEditor 抽取参数区。
     *  PoolConfig.generation 降级为废弃死数据（仅旧存档兼容），见其 schema 注释。 */
    generation: GenerationSettings.prefault({}),
  })
  .prefault({});
export type GlobalSettings = z.infer<typeof GlobalSettings>;

export const CharacterSettings = z
  .object({
    config_id: z.string().nullable().default(null),
    prompt_config_id: z.string().nullable().default(null),
  })
  .prefault({});
export type CharacterSettings = z.infer<typeof CharacterSettings>;

export const ChatSettings = z
  .object({
    config_id: z.string().nullable().default(null),
    prompt_config_id: z.string().nullable().default(null),
    world_info: WorldInfoChatSettings.prefault({}),
  })
  .prefault({});
export type ChatSettings = z.infer<typeof ChatSettings>;
