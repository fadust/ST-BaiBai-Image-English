<template>
  <div class="choice-prompt-editor">
    <div class="choice-section">
      <h4 class="choice-section-title"><i class="fa-solid fa-sliders"></i>{{ t`Context settings` }}</h4>
      <div class="choice-page-toolbar" data-tour="prompt-toolbar">
        <label
          class="choice-context-rounds"
          :title="
            t`Rounds mode: take the last N rounds of unhidden messages; Visible-only: no round limit. Both exclude hidden floors, so history matches SillyTavern's own generation — prompt-side SillyTavern regex effects (depth truncation, hiding old floors, etc.) apply here too`
          "
        >
          <select v-model="rules.context_mode" class="choice-select">
            <option value="rounds">{{ t`Rounds Mode` }}</option>
            <option value="visible_only">{{ t`Visible Only` }}</option>
          </select>
          <input
            v-if="rules.context_mode === 'rounds'"
            v-model.number="rules.context_rounds"
            class="choice-input choice-input-w-sm"
            type="number"
            min="1"
            :title="t`How many recent message rounds each generation carries; 0/negative falls back to 1 (0 does not mean unlimited)`"
            @change="rules.context_rounds = Math.max(1, Math.round(Number(rules.context_rounds)) || 1)"
          />
        </label>
        <label class="choice-context-rounds" :title="t`Enable Baibai book memory source (summary+status) as a prompt module`">
          <input v-model="rules.baibai_enabled" type="checkbox" />
          {{ t`BaiBai Book` }}
        </label>
        <label
          class="choice-context-rounds"
          :title="
            t`When on, the World Info book targeted by the SP·Database bridge joins option/enrichment generation; when off it doesn't. If the target is the character card's main World Info, turning this off has no effect — use the tri-state/exclusion controls on the World Info page`
          "
        >
          <input v-model="rules.shujuku_enabled" type="checkbox" />
          {{ t`Database` }}
        </label>
      </div>
    </div>

    <div class="choice-section">
      <h4 class="choice-section-title"><i class="fa-solid fa-diagram-project"></i>{{ t`Prompt Config` }}</h4>
      <div class="choice-config-bar">
        <div class="choice-config-row">
          <label class="choice-config-label">{{ t`Prompt Config` }}</label>
          <select v-model="selectedPromptConfigId" class="choice-config-select">
            <option v-for="cfg in promptConfigs" :key="cfg.id" :value="cfg.id">{{ cfg.name }}</option>
          </select>
          <button
            class="choice-btn-sm"
            :disabled="!selectedPromptConfig"
            :title="t`Rename`"
            @click="startRenamePromptConfig"
          >
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <div class="choice-config-actions">
            <button
              class="choice-btn-sm"
              :disabled="selectedPromptConfig?.is_default"
              :title="t`Set as Default`"
              @click="setPromptDefault"
            >
              <i class="fa-solid fa-star"></i>
            </button>
            <button
              class="choice-btn-sm"
              :class="{ active: selectedPromptConfigId === chatStore.settings.prompt_config_id }"
              :title="
                selectedPromptConfigId === chatStore.settings.prompt_config_id
                  ? t`Bound to current chat (click to unbind)`
                  : t`Bind to current chat`
              "
              @click="bindPromptChat"
            >
              <i class="fa-solid fa-comment"></i>
            </button>
            <button
              class="choice-btn-sm"
              :class="{ active: selectedPromptConfigId === characterStore.settings.prompt_config_id }"
              :disabled="!currentCharAvailable"
              :title="
                !currentCharAvailable
                  ? t`Select a character card in SillyTavern first`
                  : selectedPromptConfigId === characterStore.settings.prompt_config_id
                    ? t`Bound to current character (click to unbind)`
                    : t`Bind to current character`
              "
              @click="bindPromptCharacter"
            >
              <i class="fa-solid fa-user"></i>
            </button>
            <button
              class="choice-btn-sm choice-btn-del"
              :disabled="selectedPromptConfig?.is_default"
              :title="t`Delete`"
              @click="removePromptConfig"
            >
              <i class="fa-solid fa-trash-can"></i>
            </button>
            <button class="choice-btn-sm choice-btn-new" :title="t`New`" @click="showCreatePromptConfig = true">
              <i class="fa-solid fa-plus"></i> {{ t`New` }}
            </button>
          </div>
        </div>
        <div class="choice-config-status">
          <span class="choice-config-status-label">{{ t`Active` }}:</span>
          <span class="choice-config-status-name">{{ effectiveConfigName }}</span>
          <span v-if="chatStore.settings.prompt_config_id" class="choice-bound-badge">{{ t`Chat` }}</span>
          <span v-if="characterStore.settings.prompt_config_id" class="choice-bound-badge choice-bound-char">{{
            t`Character`
          }}</span>
        </div>

        <!-- 已绑定当前提示词配置的角色卡徽章（反向视角：角色卡→配置 的绑定关系列表，同过滤页角色卡区） -->
        <ConfigBindings :config-id="selectedPromptConfigId" kind="prompt" />
      </div>
    </div>

    <div class="choice-section">
      <h4 class="choice-section-title"><i class="fa-solid fa-list-ul"></i>{{ t`Module list` }}</h4>
      <div class="choice-module-toolbar">
        <div class="choice-module-toolbar-left">
          <div v-if="globalStore.settings.ui.enrich_enabled" class="choice-mode-switch">
            <button
              class="choice-mode-btn"
              :class="{ 'choice-mode-btn--active': promptMode === 'all' }"
              @click="promptMode = 'all'"
            >
              {{ t`All` }} ({{ totalCount }})
            </button>
            <button
              class="choice-mode-btn"
              :class="{ 'choice-mode-btn--active': promptMode === 'option' }"
              @click="promptMode = 'option'"
            >
              {{ t`Option Generation` }} ({{ optionCount }})
            </button>
            <button
              class="choice-mode-btn"
              :class="{ 'choice-mode-btn--active': promptMode === 'enrich' }"
              @click="promptMode = 'enrich'"
            >
              {{ t`Enrich` }} ({{ enrichCount }})
            </button>
          </div>
        </div>
        <div class="choice-module-toolbar-right">
          <div class="choice-export-wrap">
            <button
              class="menu_button choice-export-btn"
              :title="t`Add a new prompt module`"
              @click.stop="showAddMenu = !showAddMenu"
            >
              <span>{{ t`Add Module` }}</span>
              <i
                class="fa-solid fa-chevron-down choice-export-caret"
                :class="{ 'choice-export-caret--open': showAddMenu }"
              ></i>
            </button>
            <div v-if="showAddMenu" class="choice-export-dropdown">
              <button
                @click="
                  addModule(false, false);
                  showAddMenu = false;
                "
              >
                {{ t`General Module` }}
              </button>
              <button
                @click="
                  addModule(false, true);
                  showAddMenu = false;
                "
              >
                {{ t`Options Module` }}
              </button>
              <button
                v-if="globalStore.settings.ui.enrich_enabled"
                @click="
                  addModule(true, false);
                  showAddMenu = false;
                "
              >
                {{ t`Polish Module` }}
              </button>
            </div>
          </div>
          <div class="choice-export-wrap">
            <button
              class="menu_button choice-export-btn"
              :title="t`Choose modules to export`"
              @click.stop="showExportMenu = !showExportMenu"
            >
              <span>{{ t`Export` }}</span>
              <i
                class="fa-solid fa-chevron-down choice-export-caret"
                :class="{ 'choice-export-caret--open': showExportMenu }"
              ></i>
            </button>
            <div v-if="showExportMenu" class="choice-export-dropdown">
              <button
                @click="
                  exportPrompts('all');
                  showExportMenu = false;
                "
              >
                {{ t`Export All` }}
              </button>
              <button
                @click="
                  exportPrompts('option');
                  showExportMenu = false;
                "
              >
                {{ t`Export Options Modules` }}
              </button>
              <button
                v-if="globalStore.settings.ui.enrich_enabled"
                @click="
                  exportPrompts('enrich');
                  showExportMenu = false;
                "
              >
                {{ t`Export Polish Modules` }}
              </button>
            </div>
          </div>
          <button class="menu_button" :title="t`Import prompt modules from JSON file`" @click="importPrompts">
            {{ t`Import` }}
          </button>
          <button
            class="menu_button"
            :title="t`Restore all prompt modules to defaults (order, enabled state, content)`"
            @click="resetPromptToDefaults"
          >
            {{ t`Restore Default` }}
          </button>
        </div>
      </div>

      <div class="choice-module-list" @dragover.prevent="onListDragOver" @drop.prevent="onListDrop">
        <template v-for="(mod, idx) in allModules" :key="mod.id">
          <div
            class="choice-module-card"
            :class="{
              'choice-module-card-marker': mod.marker,
              'choice-module-card-dragging': dragIndex === idx,
              'choice-module-card-drag-over': dragOverIndex === idx && dragIndex !== idx,
            }"
            @dragover.prevent="onDragOver($event, idx)"
            @dragleave="onDragLeave(idx)"
            @drop.prevent="onDrop(idx)"
          >
            <!-- draggable 只挂在 ☰ 把手上：整卡 draggable 时手机长按卡片文本会触发系统级
               文本选择/原生拖拽抢事件，桌面也容易误从正文发起拖拽。dragend 必须同挂在把手上——
               它只派发到拖拽源元素（span），挂在卡片上收不到，dragIndex 会永远清不掉 -->
            <span
              class="choice-module-drag"
              :draggable="true"
              :title="t`Drag to reorder`"
              @dragstart="onDragStart($event, idx)"
              @dragend="onDragEnd"
              >☰</span
            >

            <div class="choice-module-body">
              <div class="choice-module-header">
                <span v-if="renamingId !== mod.id" class="choice-module-name" @dblclick="startRename(mod)">{{
                  mod.name
                }}</span>
                <input
                  v-else
                  v-model="renameText"
                  class="choice-input choice-rename-input"
                  @blur="finishRename(mod)"
                  @keydown.enter="finishRename(mod)"
                  @keydown.escape.stop="cancelRename"
                />
                <span class="choice-module-role" :class="`choice-role-${mod.role}`">{{ mod.role }}</span>
                <span v-if="mod.enrich_only" class="choice-enrich-badge-sm">{{ t`Enrich` }}</span>
                <span v-if="mod.option_only" class="choice-option-badge-sm">{{ t`Options` }}</span>
                <span v-if="mod.marker" class="choice-module-lock" :title="t`Non-editable module`">🔒</span>
              </div>
              <div class="choice-module-preview">
                {{ previewContent(mod) }}
              </div>
            </div>

            <div class="choice-module-actions">
              <label class="choice-check" :title="mod.enabled ? t`Enable` : t`Disabled`">
                <input type="checkbox" :checked="mod.enabled" @change="toggleEnabled(mod)" />
              </label>
              <button
                v-if="!mod.marker"
                class="menu_button choice-module-btn"
                :title="t`Restore Default`"
                @click="restoreTarget = mod.id"
              >
                🔄
              </button>
              <button
                v-if="!READONLY_MODULE_IDS.has(mod.id)"
                class="menu_button choice-module-btn"
                :title="t`Copy`"
                @click="copyModule(mod.id)"
              >
                📋
              </button>
              <button
                v-if="!mod.marker"
                class="menu_button choice-module-btn"
                :title="t`Edit`"
                @click="toggleEdit(mod.id)"
              >
                {{ editingId === mod.id ? '✕' : '🖉' }}
              </button>
              <button
                v-if="!mod.system"
                class="menu_button choice-module-btn choice-delete-btn"
                :title="t`Delete`"
                @click="deleteTarget = mod.id"
              >
                <i class="fa-solid fa-trash"></i>
              </button>
            </div>
          </div>

          <div v-if="editingId === mod.id" class="choice-module-edit">
            <div class="choice-module-edit-head">
              <span>{{ t`Edit Module` }}: {{ editingModule?.name }}</span>
              <select v-if="editingModule" v-model="editingModule.role" class="choice-select">
                <option value="system">system</option>
                <option value="user">user</option>
                <option value="assistant">assistant</option>
              </select>
            </div>
            <textarea v-if="editingModule" v-model="editingModule.content" class="choice-textarea" rows="8"></textarea>
          </div>
        </template>
      </div>
    </div>

    <ConfirmDialog
      :open="deleteTarget !== null"
      :title="t`Delete Module`"
      :message="t`Delete this module? This cannot be undone.`"
      :confirm-text="t`Delete`"
      :cancel-text="t`Cancel`"
      @confirm="onDeleteConfirm"
      @cancel="deleteTarget = null"
    />

    <ConfirmDialog
      :open="restoreTarget !== null"
      :title="t`Restore Default`"
      :message="t`Restore this module to default content? Current changes will be lost.`"
      :confirm-text="t`Restore`"
      :cancel-text="t`Cancel`"
      @confirm="onRestoreConfirm"
      @cancel="restoreTarget = null"
    />

    <CreateConfigDialog
      :open="showCreatePromptConfig"
      :existing-names="promptConfigs.map(c => c.name)"
      @close="showCreatePromptConfig = false"
      @create="onCreatePromptConfig"
    />

    <PromptImportDialog
      :open="showImportDialog"
      :summary="importSummary"
      :existing-names="promptConfigs.map(c => c.name)"
      @close="showImportDialog = false"
      @confirm="onImportConfirm"
    />
  </div>
</template>

<script setup lang="ts">
import toastr from 'toastr';
import { this_chid } from '@/core/st-world-info';
import { useGlobalSettingsStore } from '@/store/global-settings';
import { useCharacterSettingsStore } from '@/store/character-settings';
import { useChatSettingsStore } from '@/store/chat-settings';
import { usePromptConfigSelectorStore } from '@/store/prompt-config-selector';
import { getStCharacter } from '@/core/st-character';
import ConfirmDialog from '@/components/ConfirmDialog.vue';
import CreateConfigDialog from '@/components/CreateConfigDialog.vue';
import PromptImportDialog from '@/components/PromptImportDialog.vue';
import ConfigBindings from '@/components/shared/ConfigBindings.vue';
import type { PromptModule } from '@/type/settings';
import { BAIBAI_MODULE_IDS, PromptModule as PromptModuleSchema } from '@/type/settings';
import { isoTimestamp } from '@/util/time';
import { toggleChatBinding, toggleCharacterBinding } from '@/core/bindings';
import { z } from 'zod';

const globalStore = useGlobalSettingsStore();
const characterStore = useCharacterSettingsStore();
const chatStore = useChatSettingsStore();
const promptConfigSelector = usePromptConfigSelectorStore();
const rules = globalStore.settings.prompt_rules;

/** 只读模块：仅允许移动和开关，不可编辑/删除/复制 */
const READONLY_MODULE_IDS = new Set([
  'world_info_before',
  'persona_description',
  'char_description',
  'char_personality',
  'char_scenario',
  'world_info_after',
  'chat_history',
  'baibai_summary',
  'wi_depth_before',
  'wi_depth_after',
]);
const DEPRECATED_MODULE_IDS = new Set(['baibai_state']);

const allModules = computed(() => {
  let modules = globalStore.allModules.filter(m => !DEPRECATED_MODULE_IDS.has(m.id));
  if (!rules.baibai_enabled) {
    modules = modules.filter(m => !BAIBAI_MODULE_IDS.has(m.id));
  }
  // 润色关闭时强制隐藏所有 enrich_only 模块，忽略 promptMode
  if (!globalStore.settings.ui.enrich_enabled) {
    modules = modules.filter(m => !m.enrich_only);
  } else if (promptMode.value === 'option') {
    modules = modules.filter(m => !m.enrich_only);
  } else if (promptMode.value === 'enrich') {
    modules = modules.filter(m => !m.option_only);
  }
  return modules;
});

type PromptMode = 'all' | 'option' | 'enrich';
const promptMode = ref<PromptMode>('all');
const showExportMenu = ref(false);
const showAddMenu = ref(false);

const baibaiFilteredModules = computed(() => {
  let modules = globalStore.allModules.filter(m => !DEPRECATED_MODULE_IDS.has(m.id));
  if (!rules.baibai_enabled) {
    modules = modules.filter(m => !BAIBAI_MODULE_IDS.has(m.id));
  }
  return modules;
});

const totalCount = computed(() => baibaiFilteredModules.value.length);
const optionCount = computed(() => baibaiFilteredModules.value.filter(m => !m.enrich_only).length);
const enrichCount = computed(() => baibaiFilteredModules.value.filter(m => !m.option_only).length);

watch(
  () => globalStore.settings.ui.enrich_enabled,
  enabled => {
    if (!enabled) promptMode.value = 'all';
  },
);

const editingId = ref<string | null>(null);
const renamingId = ref<string | null>(null);
const renameText = ref('');
const deleteTarget = ref<string | null>(null);
const restoreTarget = ref<string | null>(null);

// 提示词配置栏
const promptConfigs = computed(() => globalStore.settings.prompt_configs);
const effectiveConfig = computed(() => promptConfigSelector.effectiveConfig);
const effectiveConfigName = computed(() => effectiveConfig.value?.name ?? '—');
const selectedPromptConfigId = ref<string | null>(null);
const showCreatePromptConfig = ref(false);

watch(
  [promptConfigs, effectiveConfig],
  () => {
    if (promptConfigs.value.length === 0) {
      selectedPromptConfigId.value = null;
      return;
    }
    if (!selectedPromptConfigId.value || !promptConfigs.value.find(c => c.id === selectedPromptConfigId.value)) {
      selectedPromptConfigId.value = effectiveConfig.value?.id ?? promptConfigs.value[0].id;
    }
  },
  { immediate: true },
);

const selectedPromptConfig = computed(
  () => promptConfigs.value.find(c => c.id === selectedPromptConfigId.value) ?? null,
);

watch(selectedPromptConfigId, newId => {
  if (newId) {
    try {
      globalStore.switchPromptConfig(newId);
    } catch (e) {
      console.warn('[Choice] switchPromptConfig failed', e);
    }
  }
});

function startRenamePromptConfig() {
  const cfg = selectedPromptConfig.value;
  if (!cfg) return;
  const name = prompt(t`Enter new name`, cfg.name);
  const trimmed = name?.trim();
  if (!trimmed || trimmed === cfg.name) return;
  // 重名检测：与其他提示词配置同名会让下拉歧义，提醒后放弃修改
  if (promptConfigs.value.some(c => c.id !== cfg.id && c.name === trimmed)) {
    toastr.warning(t`Configuration name "${trimmed}” already exists`);
    return;
  }
  globalStore.renamePromptConfig(cfg.id, trimmed);
}

function setPromptDefault() {
  if (!selectedPromptConfigId.value) return;
  globalStore.setDefaultPromptConfig(selectedPromptConfigId.value);
}

function bindPromptChat() {
  toggleChatBinding('prompt', selectedPromptConfigId.value);
}

// 无当前角色时绑定无意义（store watch 对 this_chid 为空会静默跳过写卡，造成「绑定无效」），
// 按钮禁用 + toggleCharacterBinding 内再 guard 双保险。
// 依赖 store 的响应式 currentCharacterId 而非模块变量 this_chid：this_chid 非响应式，
// computed 不会在切角色后自动重算（曾有实证：切到角色聊天后按钮仍停留 disabled 态）
const currentCharAvailable = computed(() => globalStore.currentCharacterId != null);

function bindPromptCharacter() {
  toggleCharacterBinding('prompt', selectedPromptConfigId.value);
}

function removePromptConfig() {
  const cfg = selectedPromptConfig.value;
  if (!cfg || cfg.is_default) return;
  if (!confirm(t`Are you sure you want to delete the configuration"${cfg.name}"?" This action cannot be undone.`)) return;
  globalStore.deletePromptConfig(cfg.id);
  if (promptConfigs.value.length > 0) {
    selectedPromptConfigId.value = effectiveConfig.value?.id ?? promptConfigs.value[0].id;
  }
}

function onCreatePromptConfig(payload: { name: string; isDefault: boolean; bindChat: boolean; bindChar: boolean }) {
  const cfg = globalStore.createPromptConfig(payload.name, payload.isDefault);
  selectedPromptConfigId.value = cfg.id;
  if (payload.bindChat) chatStore.settings.prompt_config_id = cfg.id;
  if (payload.bindChar) {
    // 编辑归属走角色卡扩展写入，无当前角色时绑定必失效（与 bindPromptCharacter 同一根因），防御提示
    if (getStCharacter(this_chid)) {
      characterStore.setBinding('prompt', cfg.id);
    } else {
      toastr.warning(t`No character card selected — "Bind character" didn't take effect`);
    }
  }
  showCreatePromptConfig.value = false;
}

const editingModule = computed(() => {
  if (!editingId.value) return null;
  return rules.modules.find(m => m.id === editingId.value) ?? null;
});

const dragIndex = ref<number | null>(null);
const dragOverIndex = ref<number | null>(null);

const addModule = (enrichOnly = false, optionOnly = false) => {
  globalStore.addModule(undefined, enrichOnly, optionOnly);
};

const resetPromptToDefaults = () => {
  if (!confirm(t`Are you sure you want to completely restore all prompt word modules to their default values? \n\nThis will reset the module order, enablement status and content. This action cannot be undone.`))
    return;
  globalStore.resetPromptToDefaults();
  toastr.success(t`Prompt restored to defaults`);
};

function exportPrompts(mode: 'all' | 'option' | 'enrich' = 'all') {
  const pr = globalStore.settings.prompt_rules;
  let modules = pr.modules;
  if (mode === 'option') {
    modules = modules.filter(m => !m.enrich_only);
  } else if (mode === 'enrich') {
    modules = modules.filter(m => !m.option_only);
  }
  // v3：携带配置级字段，使「作为新建配置导入」能得到完整配置；v2 导入方只读 modules，向前兼容
  const json = JSON.stringify(
    {
      version: 3,
      mode,
      exportedAt: isoTimestamp(),
      modules,
      config: {
        option_person: pr.option_person,
        enrich_person: pr.enrich_person,
        enrich_person_style: pr.enrich_person_style,
        option_min_chars: pr.option_min_chars,
        option_max_chars: pr.option_max_chars,
        enrich_min_chars: pr.enrich_min_chars,
        enrich_max_chars: pr.enrich_max_chars,
        context_rounds: pr.context_rounds,
        context_mode: pr.context_mode,
        baibai_enabled: pr.baibai_enabled,
        shujuku_enabled: pr.shujuku_enabled,
      },
    },
    null,
    2,
  );
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const suffix = mode !== 'all' ? `-${mode}` : '';
  a.download = `choice-prompts${suffix}-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

type ImportFileMode = 'all' | 'option' | 'enrich';

const showImportDialog = ref(false);
const importSummary = ref<{
  fileName: string;
  mode: ImportFileMode;
  scoped: PromptModule[];
  totalCount: number;
  /** v3 文件携带的配置级字段（白名单校验后）；v2 文件为空对象，导入新配置时逐字段回退当前值 */
  fileConfig: Record<string, string | number | boolean>;
  overwriteCount: number;
  addCount: number;
  keptCount: number;
} | null>(null);

function importPrompts() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = async e => {
    const file = (e.target as HTMLInputElement).files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data.modules || !Array.isArray(data.modules)) {
        throw new Error('JSON file malformed: missing modules array');
      }
      const importedModules = z.array(PromptModuleSchema).parse(data.modules);
      const ids = importedModules.map(m => m.id);
      if (new Set(ids).size !== ids.length) {
        throw new Error('Duplicate ID in imported module');
      }
      const mode: ImportFileMode = data.mode || 'all';
      if (mode !== 'all' && mode !== 'option' && mode !== 'enrich') {
        throw new Error(`Unknown import mode:${mode}`);
      }
      const existingModules = globalStore.settings.prompt_rules.modules;
      // 按文件模式圈定导入范围：option/enrich 导出文件只覆盖对应类模块，对立类现有模块不动
      const scoped =
        mode === 'all'
          ? importedModules
          : mode === 'option'
            ? importedModules.filter(m => !m.enrich_only)
            : importedModules.filter(m => !m.option_only);
      // 计数为合并模式的预览值：id 命中 → 覆盖，未命中 → 新增，现有中未被导入覆盖的 → 保留
      const existingIds = new Set(existingModules.map(m => m.id));
      const overwriteCount = scoped.filter(m => existingIds.has(m.id)).length;
      // v3 文件携带配置级字段：白名单 + 类型校验逐字段提取，非法/缺失忽略（新建配置时回退当前值）
      const rawConfig = data.config && typeof data.config === 'object' ? (data.config as Record<string, unknown>) : {};
      const s = (v: unknown): string | undefined => (typeof v === 'string' ? v : undefined);
      const n = (v: unknown): number | undefined => (typeof v === 'number' && Number.isFinite(v) ? v : undefined);
      const b = (v: unknown): boolean | undefined => (typeof v === 'boolean' ? v : undefined);
      const fileConfig: Record<string, string | number | boolean> = {};
      const cfgEntries: Array<[string, string | number | boolean | undefined]> = [
        ['option_person', s(rawConfig.option_person)],
        ['enrich_person', s(rawConfig.enrich_person)],
        ['enrich_person_style', s(rawConfig.enrich_person_style)],
        ['option_min_chars', n(rawConfig.option_min_chars)],
        ['option_max_chars', n(rawConfig.option_max_chars)],
        ['enrich_min_chars', n(rawConfig.enrich_min_chars)],
        ['enrich_max_chars', n(rawConfig.enrich_max_chars)],
        ['context_rounds', n(rawConfig.context_rounds)],
        [
          'context_mode',
          rawConfig.context_mode === 'rounds' || rawConfig.context_mode === 'visible_only'
            ? rawConfig.context_mode
            : undefined,
        ],
        ['baibai_enabled', b(rawConfig.baibai_enabled)],
        ['shujuku_enabled', b(rawConfig.shujuku_enabled)],
      ];
      for (const [k, v] of cfgEntries) {
        if (v !== undefined) fileConfig[k] = v;
      }
      importSummary.value = {
        fileName: file.name,
        mode,
        scoped,
        totalCount: scoped.length,
        fileConfig,
        overwriteCount,
        addCount: scoped.length - overwriteCount,
        keptCount: existingModules.length - overwriteCount,
      };
      showImportDialog.value = true;
    } catch (err) {
      toastr.error(t`Import failed:${err instanceof Error ? err.message : 'Invalid JSON file'}`);
    }
  };
  input.click();
}

const onImportConfirm = (payload: { mode: 'merge' | 'replace' | 'new'; newName?: string }) => {
  const summary = importSummary.value;
  if (!summary) return;
  if (payload.mode === 'new') {
    // 兜底重名检测（对话框内已有行内拦截）
    const trimmed = payload.newName?.trim() || t`Imported config`;
    if (promptConfigs.value.some(c => c.name === trimmed)) {
      toastr.warning(t`Configuration name "${trimmed}” already exists`);
      return;
    }
    // 作为新建配置导入：不动当前配置与工作副本；切换 selectedPromptConfigId 由 watch
    // 触发 switchPromptConfig——导入路径未触碰工作副本，旧配置回写无损
    const cfg = globalStore.importPromptModulesAsNewConfig(summary.scoped, {
      name: trimmed,
      config: summary.fileConfig,
    });
    showImportDialog.value = false;
    importSummary.value = null;
    selectedPromptConfigId.value = cfg.id;
    toastr.success(
      t`Imported as new configuration "${cfg.name}": Import ${summary.scoped.length} modules, complete ${summary.keptCount} items`,
    );
    return;
  }
  const { overwritten, added } = globalStore.importPromptModules(summary.scoped, {
    replaceAll: payload.mode === 'replace',
    // 落盘到正在编辑（下拉选中）的配置快照；无配置时为 null，仅写工作副本
    configId: selectedPromptConfigId.value,
  });
  showImportDialog.value = false;
  importSummary.value = null;
  toastr.success(t`Imported: override ${overwritten} modules, new ${added} modules`);
};

const toggleEnabled = (mod: PromptModule) => {
  mod.enabled = !mod.enabled;
};

const copyModule = (id: string) => {
  globalStore.duplicateModule(id);
};

const onDeleteConfirm = () => {
  if (deleteTarget.value) {
    globalStore.removeModule(deleteTarget.value);
    deleteTarget.value = null;
  }
};

const onRestoreConfirm = () => {
  if (restoreTarget.value) {
    globalStore.resetModuleContent(restoreTarget.value);
    restoreTarget.value = null;
  }
};

const toggleEdit = (id: string) => {
  editingId.value = editingId.value === id ? null : id;
};

const startRename = (mod: PromptModule) => {
  renamingId.value = mod.id;
  renameText.value = mod.name;
};

const finishRename = (mod: PromptModule) => {
  const t = renameText.value.trim();
  if (t) mod.name = t;
  renamingId.value = null;
};

const cancelRename = () => {
  renamingId.value = null;
};

const previewContent = (mod: PromptModule): string => {
  if (mod.marker) {
    const m: Record<string, string> = {
      world_info_before: '[World Info Entry - Before Character Definition]',
      world_info_after: '[World Info Entry - After Character Definition]',
      persona_description: '[Persona Description]',
      chat_history: '[Chat history]',
      thinking_prompt: '[Thinking Checklist]',
      assistant_thinking: '[Thinking Chain Start]',
    };
    return m[mod.id] ?? '[dynamic content]';
  }
  const content = mod.content.replace(/\{\{[^}]+\}\}/g, '...').slice(0, 80);
  return content || '(empty)';
};

const onDragStart = (e: DragEvent, idx: number) => {
  dragIndex.value = idx;
  if (e.dataTransfer) {
    e.dataTransfer.effectAllowed = 'move';
    // 拖拽源是 ☰ 把手本身，默认拖影只有一个小图标；用整张卡片做拖影保持视觉反馈
    const card = (e.currentTarget as HTMLElement).closest('.choice-module-card');
    if (card) e.dataTransfer.setDragImage(card, 0, 0);
  }
};

const onDragOver = (_e: DragEvent, idx: number) => {
  if (dragIndex.value === null) return;
  dragOverIndex.value = idx;
};

const onDragLeave = (idx: number) => {
  if (dragOverIndex.value === idx) dragOverIndex.value = null;
};

const onListDragOver = (_e: DragEvent) => {
  // 允许 drop
};

const onListDrop = (_e: DragEvent) => {
  dragIndex.value = null;
  dragOverIndex.value = null;
};

const onDrop = (idx: number) => {
  if (dragIndex.value === null || dragIndex.value === idx) {
    dragIndex.value = null;
    dragOverIndex.value = null;
    return;
  }
  const all = [...allModules.value];
  const [moved] = all.splice(dragIndex.value, 1);
  all.splice(idx, 0, moved);
  globalStore.reorderModules(all.map(m => m.id));
  dragIndex.value = null;
  dragOverIndex.value = null;
};

const onDragEnd = () => {
  dragIndex.value = null;
  dragOverIndex.value = null;
};

function onDocumentClick(e: MouseEvent) {
  const target = e.target as HTMLElement;
  if (!target.closest('.choice-export-wrap')) {
    showExportMenu.value = false;
    showAddMenu.value = false;
  }
}

onMounted(() => {
  document.addEventListener('click', onDocumentClick);
});
onUnmounted(() => {
  document.removeEventListener('click', onDocumentClick);
});
</script>

<style scoped>
.choice-prompt-editor {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
}

.choice-page-toolbar {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
  flex-wrap: wrap;
}

.choice-module-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--choice-space-2);
  flex-wrap: wrap;
}

.choice-module-toolbar-left,
.choice-module-toolbar-right {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-context-rounds {
  display: flex;
  align-items: center;
  gap: var(--choice-space-1);
  font-size: var(--choice-text-sm);
  color: var(--choice-text-secondary);
}

.choice-module-list {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-1);
  min-height: 40px;
}

.choice-module-card {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
  /* 纵向略紧于横向：模块多时列表纵向密度优先（52→约 48px/张） */
  padding: 6px var(--choice-space-2);
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-sm);
  background: var(--choice-bg-card);
  cursor: default;
  transition:
    border-color var(--choice-transition),
    box-shadow var(--choice-transition),
    transform var(--choice-transition);
  user-select: none;
}

.choice-module-card:hover {
  border-color: var(--choice-border-strong);
}

.choice-module-card-marker {
  border-style: dashed;
  background: rgba(128, 128, 128, 0.03);
}

.choice-module-card-dragging {
  opacity: 0.4;
  box-shadow: var(--choice-shadow-lg);
  transform: scale(1.02);
}

.choice-module-card-drag-over {
  border-top: 2px solid var(--choice-primary);
  box-shadow: inset 0 2px 8px var(--choice-primary-glow);
}

.choice-module-drag {
  cursor: grab;
  color: var(--choice-text-muted);
  font-size: var(--choice-text-base);
  padding: 0 2px;
  flex-shrink: 0;
}

.choice-module-drag:active {
  cursor: grabbing;
}

.choice-module-body {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.choice-module-header {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-module-name {
  font-size: var(--choice-text-sm);
  font-weight: 600;
  color: var(--choice-text-secondary);
  cursor: text;
  white-space: nowrap;
}

.choice-module-role {
  font-size: var(--choice-text-xs);
  padding: 2px var(--choice-space-2);
  border-radius: var(--choice-radius-full);
  font-weight: 500;
  text-transform: uppercase;
  flex-shrink: 0;
}

.choice-role-system {
  background: var(--choice-primary-light);
  color: var(--choice-color-info);
}

.choice-role-user {
  background: rgba(100, 180, 100, 0.2);
  color: var(--choice-color-success);
}

.choice-role-assistant {
  background: rgba(180, 140, 80, 0.2);
  color: var(--choice-color-warning);
}

.choice-module-lock {
  font-size: var(--choice-text-xs);
  flex-shrink: 0;
}

.choice-module-preview {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.choice-module-actions {
  display: flex;
  align-items: center;
  gap: 2px;
  flex-shrink: 0;
}

.choice-module-btn {
  width: 24px;
  height: 24px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--choice-text-sm);
}

/* 小号重命名输入框：仅覆盖宽度，底色/边框/聚焦态由 global.css 的 .choice-input 提供 */
.choice-rename-input {
  width: 120px;
}

.choice-module-edit {
  margin-top: var(--choice-space-1);
  padding: var(--choice-space-2);
  border: 1px solid var(--choice-border-strong);
  border-radius: var(--choice-radius-sm);
  background: var(--choice-bg-card);
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
}

.choice-module-edit-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: var(--choice-text-sm);
  color: var(--choice-text-secondary);
}

.choice-beginner-section {
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-sm);
  overflow: hidden;
}

.choice-beginner-body {
  padding: var(--choice-space-2) var(--choice-space-3);
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
  border-top: 1px solid var(--choice-border);
}

.choice-field-module {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
  background: var(--choice-bg-card);
  padding: 1px var(--choice-space-2);
  border-radius: var(--choice-radius-full);
}

.choice-restore-btn {
  font-size: var(--choice-text-xs);
  padding: 2px var(--choice-space-2);
  margin-left: auto;
}

.choice-enrich-badge-sm {
  font-size: var(--choice-text-xs);
  padding: 1px var(--choice-space-2);
  border-radius: var(--choice-radius-full);
  background: var(--choice-primary-light);
  color: var(--choice-primary);
  font-weight: 500;
  flex-shrink: 0;
}

.choice-option-badge-sm {
  font-size: var(--choice-text-xs);
  padding: 1px var(--choice-space-2);
  border-radius: var(--choice-radius-full);
  background: var(--choice-color-warning-bg);
  color: var(--choice-color-warning);
  font-weight: 500;
  flex-shrink: 0;
}

.choice-mode-switch {
  display: flex;
  gap: 0;
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-sm);
  overflow: hidden;
}

.choice-mode-btn {
  padding: var(--choice-space-1) var(--choice-space-3);
  font-size: var(--choice-text-sm);
  color: var(--choice-text-muted);
  background: transparent;
  border: none;
  cursor: pointer;
  transition:
    background var(--choice-transition),
    color var(--choice-transition);
}

.choice-mode-btn:not(:last-child) {
  border-right: 1px solid var(--choice-border);
}

.choice-mode-btn:hover {
  background: var(--choice-bg-hover);
  color: var(--choice-text-secondary);
}

.choice-mode-btn--active {
  background: var(--choice-primary);
  color: var(--choice-text-on-primary);
}

.choice-mode-btn--active:hover {
  background: var(--choice-primary-hover);
  color: var(--choice-text-on-primary);
}

.choice-export-wrap {
  position: relative;
  display: inline-flex;
  align-items: center;
}

.choice-export-btn {
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-1);
}

/* 箭头是按钮内部装饰而非独立按键，随菜单开合旋转 */
.choice-export-caret {
  font-size: var(--choice-text-xs);
  transition: transform var(--choice-transition);
}

.choice-export-caret--open {
  transform: rotate(180deg);
}

.choice-export-dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: var(--choice-z-dropdown);
  min-width: 140px;
  margin-top: 2px;
  background: var(--choice-bg-panel);
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-sm);
  box-shadow: var(--choice-shadow-md);
  overflow: hidden;
}

.choice-export-dropdown button {
  display: block;
  width: 100%;
  padding: var(--choice-space-2) var(--choice-space-3);
  font-size: var(--choice-text-sm);
  color: var(--choice-text);
  background: transparent;
  border: none;
  text-align: left;
  cursor: pointer;
  transition: background var(--choice-transition);
}

.choice-export-dropdown button:hover {
  background: var(--choice-bg-hover);
}
</style>
