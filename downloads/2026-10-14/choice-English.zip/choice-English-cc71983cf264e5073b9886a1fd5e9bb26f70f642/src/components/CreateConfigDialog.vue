<template>
  <Teleport to="body">
    <div v-if="open" class="choice-ccdlg-overlay" @click.self="emit('close')">
      <div class="choice-ccdlg-dialog">
        <div class="choice-ccdlg-header">
          <span class="choice-ccdlg-title">
            <i class="fa-solid fa-plus"></i>
            {{ t`New Config` }}
          </span>
          <button class="choice-ccdlg-close" :title="t`Cancel`" @click="emit('close')">&times;</button>
        </div>

        <div class="choice-ccdlg-body">
          <div class="choice-ccdlg-field">
            <label class="choice-ccdlg-label">{{ t`Config name` }}</label>
            <input v-model="name" class="text_pole" :placeholder="t`Enter config name`" @keyup.enter="onCreate" />
            <p v-if="isDup" class="choice-ccdlg-warning">{{ t`A config with this name already exists. Please choose another.` }}</p>
          </div>

          <div class="choice-ccdlg-checks">
            <label class="choice-check">
              <input v-model="isDefault" type="checkbox" />
              {{ t`Set as Default` }}
            </label>
            <label class="choice-check">
              <input v-model="bindChat" type="checkbox" />
              {{ t`Bind to Chat` }}
            </label>
            <label class="choice-check" :title="!hasChar ? t`Select a character card in SillyTavern first` : ''">
              <input v-model="bindChar" type="checkbox" :disabled="!hasChar" />
              {{ t`Bind to Character` }}
            </label>
          </div>
        </div>

        <div class="choice-ccdlg-footer">
          <button class="menu_button" @click="emit('close')">{{ t`Cancel` }}</button>
          <button class="menu_button" :disabled="!name.trim() || isDup" @click="onCreate">{{ t`Create` }}</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useGlobalSettingsStore } from '@/store/global-settings';

const props = defineProps<{ open: boolean; existingNames?: string[] }>();

const emit = defineEmits<{
  close: [];
  create: [payload: { name: string; isDefault: boolean; bindChat: boolean; bindChar: boolean }];
}>();

const name = ref('');
const isDefault = ref(false);
const bindChat = ref(false);
const bindChar = ref(false);

// 无当前角色时「绑定角色」不可勾选：绑定走角色卡 extensions 写入，this_chid 为空时
// store watch 会静默跳过写卡（绑定无效的根因），禁用勾选把该路径堵死在入口。
// 用 store 的响应式 currentCharacterId（this_chid 非响应式，computed 不会自动重算）
const hasChar = computed(() => useGlobalSettingsStore().currentCharacterId != null);

// 与现有配置重名（trim 后精确比较）时禁止创建，行内提示
const isDup = computed(() => {
  const trimmed = name.value.trim();
  return trimmed.length > 0 && (props.existingNames ?? []).some(n => n.trim() === trimmed);
});

const onCreate = () => {
  const trimmed = name.value.trim();
  if (!trimmed || isDup.value) return;
  emit('create', {
    name: trimmed,
    isDefault: isDefault.value,
    bindChat: bindChat.value,
    bindChar: bindChar.value,
  });
  name.value = '';
  isDefault.value = false;
  bindChat.value = false;
  bindChar.value = false;
};
</script>

<style scoped>
.choice-ccdlg-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  /* 同 dvh 回退：手机上 100vh 按布局视口取值，大于可视高度 */
  height: 100vh;
  height: 100dvh;
  z-index: var(--choice-z-dialog);
  background: var(--choice-overlay);
  display: flex;
  align-items: center;
  justify-content: center;
}

.choice-ccdlg-dialog {
  width: 380px;
  max-width: 92vw;
  background: var(--choice-bg-panel);
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-lg);
  box-shadow:
    inset 0 1px 0 var(--choice-frost-line),
    var(--choice-shadow-lg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.choice-ccdlg-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--choice-space-3) var(--choice-space-4);
  background: linear-gradient(180deg, rgba(var(--choice-primary-rgb), 0.08), transparent);
  border-bottom: 1px solid var(--choice-border);
}

.choice-ccdlg-title {
  font-size: var(--choice-text-base);
  font-weight: bold;
  color: var(--choice-text);
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-ccdlg-close {
  background: none;
  border: none;
  color: var(--choice-text-muted);
  font-size: var(--choice-text-xl);
  cursor: pointer;
  line-height: 1;
  padding: 0 var(--choice-space-1);
  border-radius: 50%;
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition:
    background var(--choice-transition),
    color var(--choice-transition);
}

.choice-ccdlg-close:hover {
  background: var(--choice-bg-hover);
  color: var(--choice-text);
}

.choice-ccdlg-body {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-4);
  padding: var(--choice-space-4);
}

.choice-ccdlg-field {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-1);
}

.choice-ccdlg-label {
  font-size: var(--choice-text-sm);
  color: var(--choice-text-secondary);
  font-weight: bold;
}

.choice-ccdlg-warning {
  font-size: var(--choice-text-xs);
  color: var(--choice-color-error);
}

.choice-ccdlg-checks {
  display: flex;
  gap: var(--choice-space-4);
  flex-wrap: wrap;
}

.choice-check {
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-1);
  font-size: var(--choice-text-sm);
  color: var(--choice-text-secondary);
  cursor: pointer;
}

.choice-ccdlg-footer {
  display: flex;
  justify-content: flex-end;
  gap: var(--choice-space-2);
  border-top: 1px solid var(--choice-border);
  padding: var(--choice-space-3) var(--choice-space-4);
}
</style>
