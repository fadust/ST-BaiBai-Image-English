<template>
  <div class="choice-api-editor">
    <ChoiceSectionCard title="Try again" icon="fa-solid fa-rotate">
      <div class="choice-retry-fields">
        <label class="choice-field">
          <span>{{ t`Retry Count` }}</span>
          <input
            v-model.number="globalStore.settings.retry_count"
            type="number"
            class="choice-input"
            min="0"
            max="10"
            placeholder="0"
            @change="globalStore.settings.retry_count = clampNum($event, 0, 10, 0)"
          />
        </label>
        <label class="choice-field">
          <span>{{ t`Retry interval (seconds)` }}</span>
          <input
            v-model.number="globalStore.settings.retry_interval"
            type="number"
            class="choice-input"
            min="0"
            max="60"
            placeholder="1"
            @change="globalStore.settings.retry_interval = clampNum($event, 0, 60, 1)"
          />
        </label>
      </div>
      <span class="choice-field-hint">{{
        t`Retries: 0 = no retry; network errors and 5xx retry automatically, waiting the "retry interval" between attempts (0 = retry immediately)`
      }}</span>

      <label class="choice-check">
        <input v-model="globalStore.settings.api_tool_choice_none" type="checkbox" />
        {{ t`Attach tool_choice: "none" to requests` }}
      </label>
      <span class="choice-field-hint">{{
        t`Bypasses rewriting of generation requests by anti-truncation preset scripts (e.g. Aether); the field is never forwarded to the upstream API — normally leave this on`
      }}</span>
    </ChoiceSectionCard>

    <ChoiceSectionCard title="Channels and models" icon="fa-solid fa-plug" default-open>
      <div class="choice-api-select-row">
        <label class="choice-field" style="flex: 1; min-width: 0">
          <span>{{ t`Generation API` }}</span>
          <select
            :value="selectedApiId"
            class="choice-select"
            @change="selectApi(($event.target as HTMLSelectElement).value)"
          >
            <option v-for="api in globalStore.settings.apis" :key="api.id" :value="api.id">
              {{ api.name || t`<Unnamed>` }}
            </option>
          </select>
        </label>
        <button
          class="menu_button"
          style="flex-shrink: 0; margin-top: auto"
          :title="t`New API Config`"
          @click="createApi"
        >
          <i class="fa-solid fa-plus"></i> {{ t`New` }}
        </button>
        <button
          class="menu_button"
          style="flex-shrink: 0; margin-top: auto; color: var(--choice-color-error)"
          :disabled="!selectedApiId"
          :title="t`Delete Current API`"
          @click="removeApi"
        >
          <i class="fa-solid fa-trash-can"></i> {{ t`Delete` }}
        </button>
      </div>

      <div class="choice-api-form" data-tour="api-form">
        <div class="choice-api-form-body">
          <div class="choice-api-name-row">
            <input v-model="draftForm.name" class="choice-input" :placeholder="t`Config name`" />
          </div>
          <div class="choice-api-url-row" data-tour="api-url">
            <input v-model="draftForm.apiurl" class="choice-input" :placeholder="t`API URL`" />
          </div>
          <div class="choice-api-key-row">
            <input v-model="draftForm.key" class="choice-input" type="password" :placeholder="t`API Key`" />
          </div>
          <div class="choice-model-row">
            <input
              v-model="draftForm.model"
              class="choice-input"
              :placeholder="t`Model`"
              @focus="modelDropdownOpen = true"
              @blur="onModelBlur"
            />
            <button
              class="menu_button choice-fetch-btn"
              :disabled="fetching"
              :title="t`Fetch available models from API`"
              @click="fetchModels"
            >
              <i v-if="fetching" class="fa-solid fa-spinner fa-spin"></i>
              <i v-else class="fa-solid fa-cloud-arrow-down"></i>
              {{ fetching ? '' : t`Fetch` }}
            </button>
          </div>
          <div v-if="modelDropdownOpen && modelList.length > 0" class="choice-model-list">
            <div
              v-for="model in modelList"
              :key="model"
              class="choice-model-item"
              :class="{ 'choice-model-item--active': draftForm.model === model }"
              @click="
                draftForm.model = model;
                modelDropdownOpen = false;
              "
            >
              {{ model }}
            </div>
          </div>
          <div class="choice-api-row">
            <label class="choice-field">
              <span>{{ t`Temperature` }}</span>
              <input
                v-model.number="draftForm.temperature"
                type="number"
                class="choice-input"
                min="0"
                max="2"
                step="0.1"
                @change="draftForm.temperature = clampNum($event, 0, 2, 1)"
              />
            </label>
            <label class="choice-field">
              <span>{{ t`Max Tokens` }}</span>
              <input
                v-model.number="draftForm.max_tokens"
                type="number"
                class="choice-input"
                min="1"
                @change="draftForm.max_tokens = clampNum($event, 1, 1000000, 4096)"
              />
            </label>
            <label class="choice-field">
              <span>{{ t`Timeout (s)` }}</span>
              <input
                v-model.number="draftForm.timeout"
                type="number"
                class="choice-input"
                min="0"
                placeholder="0"
                @change="draftForm.timeout = clampNum($event, 0, 7200, 180)"
              />
            </label>
          </div>
          <div class="choice-api-preset-row">
            <label class="choice-field" style="flex: 1; min-width: 0">
              <span>{{ t`Provider` }}</span>
              <select v-model="selectedPresetId" class="choice-select" @change="onSelectPreset">
                <option value="">{{ t`Custom (manual entry)` }}</option>
                <option v-for="preset in API_PRESETS" :key="preset.id" :value="preset.id">{{ preset.name }}</option>
              </select>
            </label>
          </div>
          <span v-if="selectedPreset" class="choice-field-hint">{{ selectedPreset.keyHint }}</span>
          <div class="choice-api-bottom-row">
            <div class="choice-api-checks">
              <label class="choice-check">
                <input v-model="draftForm.stream" type="checkbox" />
                {{ t`Stream` }}
              </label>
            </div>
            <input
              v-model="draftForm.exclude_params"
              class="choice-input"
              :placeholder="t`Exclude Params`"
              style="flex: 1; min-width: 0"
            />
          </div>
        </div>
      </div>

      <div class="choice-api-bottom-actions">
        <button class="menu_button" data-tour="api-save" @click="save">{{ t`Save` }}</button>
        <button class="menu_button" @click="reset">{{ t`Cancel` }}</button>
      </div>
    </ChoiceSectionCard>
  </div>
</template>

<script setup lang="ts">
import toastr from 'toastr';
import ChoiceSectionCard from '@/components/shared/ChoiceSectionCard.vue';
import { uuidv4 } from '@sillytavern/scripts/utils';
import { useGlobalSettingsStore } from '@/store/global-settings';
import type { SecondaryApi } from '@/type/settings';
import { normalizeApiUrl } from '@/core/api-client';
import { API_PRESETS, presetForApiUrl } from '@/core/api-presets';

const globalStore = useGlobalSettingsStore();

const EMPTY_API = (): SecondaryApi => ({
  id: uuidv4(),
  name: '',
  apiurl: '',
  key: '',
  model: '',
  temperature: 1,
  max_tokens: 4096,
  timeout: 180,
  stream: false,
  exclude_params: '',
});

const initForm = (): SecondaryApi => {
  const api = globalStore.settings.apis.find(a => a.id === selectedApiId.value);
  return api ? klona(api) : EMPTY_API();
};

const selectedApiId = ref<string>(globalStore.settings.active_api_id);
const draftForm = ref<SecondaryApi>(initForm());

const modelList = ref<string[]>([]);
const fetching = ref(false);
const modelDropdownOpen = ref(false);

// 服务商预设：仅表单级 UI 状态，不持久化（保存只存 apiurl，刷新后按地址经 presetForApiUrl 反显）
const selectedPresetId = ref<string>(presetForApiUrl(draftForm.value.apiurl)?.id ?? '');
const selectedPreset = computed(() => API_PRESETS.find(p => p.id === selectedPresetId.value) ?? null);

const syncPresetFromUrl = () => {
  selectedPresetId.value = presetForApiUrl(draftForm.value.apiurl)?.id ?? '';
};

const onSelectPreset = () => {
  const preset = selectedPreset.value;
  if (!preset) return; // 自定义：不预填地址
  const next = { ...draftForm.value, apiurl: preset.baseUrl };
  // 原模型名若不在该服务商示例中则清空，让用户从示例 placeholder 重选
  if (!preset.modelExamples.includes(next.model)) next.model = '';
  draftForm.value = next;
};

const onModelBlur = () => {
  setTimeout(() => {
    modelDropdownOpen.value = false;
  }, 150);
};

const selectApi = (id: string) => {
  selectedApiId.value = id;
  // 下拉「生成 API」即渠道选择器：选中立即生效，否则 active_api_id 只会被「新建保存」改写，
  // 导致生成永远使用最近创建的 API。store 深度 watch 会自动持久化该字段。
  globalStore.settings.active_api_id = id;
  const api = globalStore.settings.apis.find(a => a.id === id);
  draftForm.value = api ? klona(api) : EMPTY_API();
  syncPresetFromUrl();
  modelDropdownOpen.value = false;
};

const createApi = () => {
  selectedApiId.value = '';
  modelList.value = [];
  modelDropdownOpen.value = false;
  syncPresetFromUrl();
};

const fetchModels = async () => {
  const helper = window.TavernHelper;
  if (!helper) {
    toastr.warning(t`JS-Slash-Runner not found. Cannot fetch model list.`);
    return;
  }
  if (!draftForm.value.apiurl) {
    toastr.warning(t`Please fill in the API URL first`);
    return;
  }
  fetching.value = true;
  try {
    const models = await helper.getModelList({
      apiurl: normalizeApiUrl(draftForm.value.apiurl),
      key: draftForm.value.key || undefined,
    });
    modelList.value = models;
    if (models.length === 0) {
      toastr.info(t`Model list is empty`);
    } else {
      toastr.success(t`Pull to ${models.length} models`);
    }
  } catch (error) {
    toastr.error(t`Failed to pull model list:${error instanceof Error ? error.message : String(error)}`);
  } finally {
    fetching.value = false;
  }
};

const removeApi = () => {
  const id = selectedApiId.value;
  const newApis = globalStore.settings.apis.filter(a => a.id !== id);
  globalStore.settings.apis = newApis;
  if (globalStore.settings.active_api_id === id) {
    globalStore.settings.active_api_id = newApis[0]?.id ?? '';
  }
  const nextId = newApis[0]?.id ?? '';
  selectedApiId.value = nextId;
  const api = newApis.find(a => a.id === nextId);
  draftForm.value = api ? klona(api) : EMPTY_API();
  syncPresetFromUrl();
  modelList.value = [];
  modelDropdownOpen.value = false;
  toastr.success(t`Deleted`);
};

// 数字输入失焦钳制：v-model.number 对清空/负值不设防——retry_count 负数会让 api-client
// 的尝试循环一次都不执行（throw undefined）；temperature 越界直接 400
const clampNum = (e: Event, min: number, max: number, fallback: number): number => {
  const n = Number((e.target as HTMLInputElement).value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};

const save = () => {
  const normalized = { ...draftForm.value, apiurl: normalizeApiUrl(draftForm.value.apiurl) };
  // 空 apiurl 会静默落到酒馆主 OpenAI 配置（主 key 被副功能消耗）、空 model 发出无模型请求
  if (!normalized.apiurl.trim() || !normalized.model.trim()) {
    toastr.warning(t`Fill in the API address and model name first`);
    return;
  }
  const dupName = normalized.name.trim();
  if (dupName) {
    const duplicate = globalStore.settings.apis.find(a => a.id !== selectedApiId.value && a.name.trim() === dupName);
    if (duplicate) {
      toastr.warning(t`API name "${dupName}” already exists`);
      return;
    }
  }
  const original = globalStore.settings.apis.find(a => a.id === selectedApiId.value);
  if (original) {
    Object.assign(original, normalized);
    globalStore.settings.apis = [...globalStore.settings.apis];
    draftForm.value = klona(original);
  } else {
    const newApi = { ...normalized, id: uuidv4() };
    globalStore.settings.apis = [...globalStore.settings.apis, newApi];
    globalStore.settings.active_api_id = newApi.id;
    selectedApiId.value = newApi.id;
    draftForm.value = klona(newApi);
  }
  toastr.success(t`Saved`);
};

const reset = () => {
  selectedApiId.value = globalStore.settings.active_api_id;
  draftForm.value = initForm();
  syncPresetFromUrl();
  modelList.value = [];
  modelDropdownOpen.value = false;
};
</script>

<style scoped>
.choice-api-editor {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-4);
}

.choice-api-select-row {
  display: flex;
  align-items: flex-end;
  gap: var(--choice-space-2);
}

/* 两个数字输入横排，窄容器自动折行堆叠——不依赖 CSS container query */
.choice-retry-fields {
  display: flex;
  flex-wrap: wrap;
  gap: var(--choice-space-2);
}

.choice-retry-fields .choice-field {
  flex: 1 1 120px;
  min-width: 0;
}

/* 渠道与模型卡片内的表单：卡片已提供边框/背景，内层不再重复描边（避免卡中卡） */
.choice-api-form {
  display: flex;
  flex-direction: column;
}

.choice-api-form-body {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
  padding: var(--choice-space-2);
}

.choice-api-name-row {
  display: flex;
}

.choice-api-name-row .choice-input,
.choice-api-url-row .choice-input,
.choice-api-key-row .choice-input,
.choice-model-row .choice-input {
  /* 占满行宽：底色/边框/聚焦态由 global.css 的 .choice-input 提供。
     url 行此前漏加 flex:1，导致 API 地址输入栏明显比其他栏短（用户反馈） */
  flex: 1;
}

.choice-api-url-row {
  display: flex;
}

.choice-api-key-row {
  display: flex;
}

.choice-model-row {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-fetch-btn {
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-1);
  flex-shrink: 0;
}

.choice-model-list {
  max-height: 160px;
  overflow-y: auto;
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-sm);
  background: var(--choice-bg-card);
}

.choice-model-item {
  padding: var(--choice-space-1) var(--choice-space-2);
  font-size: var(--choice-text-xs);
  color: var(--choice-text);
  cursor: pointer;
  border-bottom: 1px solid var(--choice-border);
}

.choice-model-item:last-child {
  border-bottom: none;
}

.choice-model-item:hover {
  background: var(--choice-bg-hover);
}

.choice-model-item--active {
  color: var(--choice-accent);
  font-weight: bold;
}

.choice-api-row {
  display: flex;
  gap: var(--choice-space-2);
  flex-wrap: nowrap;
}

.choice-api-row .choice-field {
  flex: 1;
  min-width: 0;
}

.choice-api-preset-row {
  display: flex;
  align-items: flex-end;
  gap: var(--choice-space-2);
}

.choice-api-preset-row .choice-field {
  flex: 1;
  min-width: 0;
}

.choice-api-bottom-row {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-api-checks {
  display: flex;
  gap: var(--choice-space-3);
  flex-shrink: 0;
}

.choice-check {
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-1);
  font-size: var(--choice-text-xs);
  color: var(--choice-text-secondary);
}

.choice-api-bottom-actions {
  display: flex;
  gap: var(--choice-space-2);
  padding-top: var(--choice-space-2);
  border-top: 1px solid var(--choice-border);
  margin-top: 4px;
}
</style>
