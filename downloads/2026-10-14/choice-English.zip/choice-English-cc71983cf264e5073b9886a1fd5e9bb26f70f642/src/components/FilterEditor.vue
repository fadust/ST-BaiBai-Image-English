<template>
  <div class="choice-filter-editor">
    <div class="choice-section">
      <h4 class="choice-section-title"><i class="fa-solid fa-filter"></i>{{ t`Filter settings` }}</h4>
      <!-- 状态栏 -->
      <div class="choice-config-status">
        <span class="choice-config-status-label">{{ t`Active` }}:</span>
        <span class="choice-bound-badge">
          <i class="fa-solid fa-globe"></i> {{ t`Global` }} {{ globalActiveCount }}
        </span>
        <span v-if="gs.currentPresetName" class="choice-bound-badge">
          <i class="fa-solid fa-sliders"></i> {{ gs.currentPresetName }} {{ presetActiveCount }}
        </span>
        <span v-else class="choice-bound-badge choice-bound-fallback">
          <i class="fa-solid fa-sliders"></i> {{ t`Preset (none)` }}
        </span>
        <span v-if="currentCharName !== t`Not selected`" class="choice-bound-badge choice-bound-char">
          <i class="fa-solid fa-address-card"></i> {{ currentCharName }} {{ charActiveCount }}
        </span>
        <span v-else class="choice-bound-badge choice-bound-fallback">
          <i class="fa-solid fa-address-card"></i> {{ t`Character (not selected)` }}
        </span>
      </div>

      <!-- 酒馆正则总开关：聊天记录是否先走酒馆原生正则（全局/预设/角色卡三区），
         再走本页过滤规则。关 = 只用本页规则，避免预设正则清空旧层 user 输入
         导致 assistant 配对断裂、相邻合并。 -->
      <div class="choice-stregex-head" data-tour="filter-stregex-toggle">
        <span class="choice-inline-label"><i class="fa-solid fa-scroll"></i> {{ t`Apply SillyTavern regex` }}</span>
        <span class="choice-stregex-desc">{{
          t`On: chat history first passes SillyTavern global/preset/character regex, then this page's rules. Off: skip SillyTavern regex, use only this page's rules`
        }}</span>
        <ChoiceSwitch
          v-model="gs.settings.filter_settings.st_regex_enabled"
          class="choice-stregex-switch"
          :title="gs.settings.filter_settings.st_regex_enabled ? t`SillyTavern regex enabled` : t`SillyTavern regex is off; only this page's rules apply`"
        />
      </div>
    </div>

    <div class="choice-section">
      <!-- 标签提取快速区（新手入口）：不理解分区/分组/正则也能用，填标签名即可。
         规则存进固定 id 的专用全局分组（见 global-settings ensureExtractGroup），
         生成时恒定先于下方手动分组的 tag/regex 规则执行（先裁剪后过滤），互不干扰。
         预览行实时演示"填的名字 → 匹配的标签对"，消除"单框到底填什么"的疑惑 -->
      <div class="choice-extract-quick" data-tour="filter-extract-quick">
        <div class="choice-extract-quick-head">
          <span class="choice-inline-label"><i class="fa-solid fa-bolt"></i> {{ t`Tag Extraction` }}</span>
          <span class="choice-extract-quick-desc">{{
            t`Recommended for beginners: keep only the content between the specified tag pair in AI output and discard the rest; user input is kept as-is`
          }}</span>
          <!-- 提取总开关：关 = 规则保留但全部停用（不受下方任何分组开关影响） -->
          <ChoiceSwitch
            v-model="gs.extractGroupEnabled"
            class="choice-extract-quick-switch"
            :title="gs.extractGroupEnabled ? t`Tag extraction enabled` : t`Tag extraction disabled (rules kept)`"
          />
        </div>
        <div class="choice-extract-quick-row">
          <input
            v-model="extractInput"
            class="choice-input choice-extract-input"
            :placeholder="t`Only fill in the tag name, such as: text`"
            @keydown.enter="addExtract"
          />
          <button class="choice-btn-sm choice-btn-new" @click="addExtract">
            <i class="fa-solid fa-plus"></i> {{ t`Extract this tag` }}
          </button>
        </div>
        <!-- 实时预览：填"正文"就展示 <正文>…</正文>，所见即所提取 -->
        <div class="choice-extract-preview">
          <span v-if="extractPreviewName">
            {{ t`Only reserved for AI output ${extractPreviewName} The content between (including the tag itself) is discarded; the user input is retained as is:` }}
            <code class="choice-extract-preview-tag"
              >&lt;{{ extractPreviewName }}&gt;…&lt;/{{ extractPreviewName }}&gt;</code
            >
          </span>
          <span v-else>{{ t`Example: If the plot of Kali is included in &lt;Text&gt;…&lt;/Text&gt; 里，这里就填「正文」` }}</span>
        </div>
        <div
          v-if="gs.extractTagNames.length > 0"
          class="choice-extract-chips"
          :class="{ 'choice-extract-chips--off': !gs.extractGroupEnabled }"
        >
          <span v-for="name in gs.extractTagNames" :key="name" class="choice-extract-chip">
            <span class="choice-extract-chip-tag">&lt;{{ name }}&gt;</span>
            <i class="fa-solid fa-xmark" :title="t`Remove this extract tag`" @click="gs.removeExtractRule(name)"></i>
          </span>
        </div>
      </div>
    </div>

    <div class="choice-section" data-tour="filter-global-head">
      <div class="choice-filter-card-head">
        <h4 class="choice-section-title"><i class="fa-solid fa-globe"></i>{{ t`Global Regex` }}</h4>
        <button class="choice-btn-sm choice-btn-new" @click="gs.addFilterGroup('global')">
          <i class="fa-solid fa-plus"></i> {{ t`Add Group` }}
        </button>
      </div>
      <div ref="globalListEl" class="choice-filter-group-list" data-area="global">
        <FilterGroupPanel
          v-for="group in globalGroupsSorted"
          :key="group.id"
          :group-id="group.id"
          :data-group-id="group.id"
          :dimmed="false"
          :show-bindings="false"
          :binding-label="''"
          :binding-icon="''"
          :duplicate-indices="getDuplicateIndices(group.id)"
          @add-from-library="openLibrary(group.id)"
          @delete="onDeleteGroup(group.id)"
          @unbind="() => {}"
        />
        <div v-if="globalGroups.length === 0" class="choice-empty-hint">
          <span>{{ t`No global groups. Click 'New Group' to create one.` }}</span>
        </div>
      </div>
    </div>

    <div class="choice-section">
      <div class="choice-filter-card-head">
        <h4 class="choice-section-title"><i class="fa-solid fa-sliders"></i>{{ t`Preset Regex` }}</h4>
        <button class="choice-btn-sm choice-btn-new" @click="gs.addFilterGroup('preset')">
          <i class="fa-solid fa-plus"></i> {{ t`Add Group` }}
        </button>
      </div>
      <div ref="presetListEl" class="choice-filter-group-list" data-area="preset">
        <FilterGroupPanel
          v-for="group in presetGroupsSorted"
          :key="group.id"
          :group-id="group.id"
          :data-group-id="group.id"
          :dimmed="!isPresetActive(group)"
          :show-bindings="true"
          :binding-label="group.preset_name ?? ''"
          :binding-icon="'fa-solid fa-sliders'"
          :duplicate-indices="getDuplicateIndices(group.id)"
          @add-from-library="openLibrary(group.id)"
          @delete="onDeleteGroup(group.id)"
          @unbind="unbindPreset(group)"
          @bind-to-current="bindPresetToCurrent(group)"
        />
        <div v-if="presetGroups.length === 0" class="choice-empty-hint">
          <span>{{ t`No preset groups. Click 'New Group' to create one.` }}</span>
        </div>
      </div>
    </div>

    <div class="choice-section">
      <div class="choice-filter-card-head">
        <h4 class="choice-section-title"><i class="fa-solid fa-address-card"></i>{{ t`Character Regex` }}</h4>
        <button class="choice-btn-sm choice-btn-new" @click="addCharGroup">
          <i class="fa-solid fa-plus"></i> {{ t`Add Group` }}
        </button>
      </div>
      <div ref="charListEl" class="choice-filter-group-list" data-area="character">
        <FilterGroupPanel
          v-for="group in charGroupsSorted"
          :key="group.id"
          :group-id="group.id"
          :data-group-id="group.id"
          :dimmed="!isCharActive(group)"
          :show-bindings="true"
          :binding-label="getCharName(group.character_id)"
          :binding-icon="'fa-solid fa-address-card'"
          :duplicate-indices="getDuplicateIndices(group.id)"
          @add-from-library="openLibrary(group.id)"
          @delete="onDeleteGroup(group.id)"
          @unbind="unbindCharacter(group)"
        />
        <div v-if="charGroups.length === 0" class="choice-empty-hint">
          <span>{{ t`No character groups. Click 'New Group' to create one.` }}</span>
        </div>
      </div>
    </div>

    <button
      class="choice-entrypool-btn"
      data-tour="filter-library"
      :title="t`Open regex library manager`"
      @click="showLibrary = true"
    >
      <i class="fa-solid fa-code"></i>
      {{ t`Regex Library` }} ({{ gs.settings.filter_settings.regex_library.length }})
    </button>

    <RegexLibraryDialog
      :open="showLibrary"
      :selectable="libraryTargetId !== null"
      :already-referenced-ids="libraryTargetId ? getReferencedIds(libraryTargetId) : new Set()"
      @close="onLibraryClose"
      @confirm="onLibraryConfirm"
    />

    <ConfirmDialog
      :open="deleteTarget !== null"
      :title="t`Delete Group`"
      :message="t`Delete this group and all its rules? This cannot be undone.`"
      :confirm-text="t`Delete`"
      :cancel-text="t`Cancel`"
      @confirm="onDeleteConfirm"
      @cancel="deleteTarget = null"
    />

    <ConfirmDialog
      :open="showCharWarning"
      :title="t`Notice`"
      :message="t`Select a character card in SillyTavern first`"
      :confirm-text="t`Confirm`"
      :cancel-text="''"
      @confirm="showCharWarning = false"
    />
  </div>
</template>

<script setup lang="ts">
import { useGlobalSettingsStore } from '@/store/global-settings';
import { onboardingPendingAction } from '@/core/onboarding';
import RegexLibraryDialog from '@/components/RegexLibraryDialog.vue';
import ConfirmDialog from '@/components/ConfirmDialog.vue';
import FilterGroupPanel from '@/components/FilterGroupPanel.vue';
import ChoiceSwitch from '@/components/shared/ChoiceSwitch.vue';
import { this_chid } from '@/core/st-world-info';
import { getStCharacter } from '@/core/st-character';
import { DRAG_HANDLE_GROUP_SELECTOR, draggableFilterOptions } from '@/util/sortable';
import type { FilterGroup } from '@/type/settings';
import Sortable from 'sortablejs';

const gs = useGlobalSettingsStore();
const filterGroups = computed(() => gs.settings.filter_settings.groups);

// 快速区输入框：回车/点按钮都走 gs.addExtractRule（内部负责去尖括号、去重、重建分组）
const extractInput = ref('');
const addExtract = () => {
  gs.addExtractRule(extractInput.value);
  extractInput.value = '';
};
// 预览用标签名：与 store 的清洗规则一致（剥掉用户顺手带的尖括号/闭合斜杠），
// 保证"预览显示的标签对"就是实际会匹配的
const extractPreviewName = computed(() =>
  extractInput.value
    .trim()
    .replace(/^<\/?\s*/, '')
    .replace(/\s*>$/, '')
    .trim(),
);

const globalGroups = computed(() =>
  // 提取专用分组不渲染进全局正则区：提取（保留标签内）与过滤（删除）语义不同，混排
  // 会被当成又一条过滤规则；快速区是提取规则的唯一管理入口（启停/增删都在那里）
  filterGroups.value.filter(g => g.preset_name === null && g.character_id === null && g.id !== gs.extractGroupId),
);
// 显示序必须与 store 序严格一致：Sortable 的 onEnd 按 DOM 位置回写 store，computed 里
// 任何重排（enabled 置顶/按名排序）都会把拖拽写入的顺序在下一帧渲染中回滚——此前
// preset/char 区拖拽完全无效、global 区有禁用分组时错位即此因。启停/当前态用样式区分
const globalGroupsSorted = computed(() => globalGroups.value);
const presetGroups = computed(() => filterGroups.value.filter(g => g.preset_name !== null));
const charGroups = computed(() => filterGroups.value.filter(g => g.character_id !== null));

const globalActiveCount = computed(() => globalGroups.value.filter(g => g.enabled).length);
const presetActiveCount = computed(
  () => presetGroups.value.filter(g => g.preset_name === gs.currentPresetName && g.enabled).length,
);
const charActiveCount = computed(
  () => charGroups.value.filter(g => g.character_id === gs.currentCharacterId && g.enabled).length,
);

const presetGroupsSorted = computed(() => presetGroups.value);

const charGroupsSorted = computed(() => charGroups.value);

const isPresetActive = (group: FilterGroup) => group.preset_name === gs.currentPresetName;
const isCharActive = (group: FilterGroup) => group.character_id === gs.currentCharacterId;

const currentCharName = computed(() => {
  const ch = getStCharacter(this_chid);
  return ch?.name || t`Not selected`;
});

const getCharName = (chid: string | number | null) => {
  if (chid === null) return '';
  return getStCharacter(chid)?.name || `#${chid}`;
};

const unbindPreset = (group: FilterGroup) => {
  group.preset_name = null;
};

const bindPresetToCurrent = (group: FilterGroup) => {
  group.preset_name = gs.currentPresetName;
};

const unbindCharacter = (group: FilterGroup) => {
  group.character_id = null;
};

const showLibrary = ref(false);
const libraryTargetId = ref<string | null>(null);
const deleteTarget = ref<string | null>(null);
const showCharWarning = ref(false);

// 新手引导弹窗状态信号：close-all 归零 / filter-library 打开。filter-reference 步
// 进入时自动关掉正则库——引用流程的锚点（分组按钮）在正则库弹窗之下，弹窗开着时
// 聚光灯只能照到弹窗面板而非按钮
watch(onboardingPendingAction, a => {
  if (a === 'filter-library' || a === 'close-all') {
    showLibrary.value = a === 'filter-library';
    onboardingPendingAction.value = null;
  }
});

const openLibrary = (groupId: string) => {
  libraryTargetId.value = groupId;
  showLibrary.value = true;
};

const onLibraryClose = () => {
  showLibrary.value = false;
  libraryTargetId.value = null;
};

const getReferencedIds = (groupId: string): Set<string> => {
  const group = gs.settings.filter_settings.groups.find(g => g.id === groupId);
  if (!group) return new Set();
  const ids = new Set<string>();
  for (const e of group.entries) {
    if (e.library_entry_id) ids.add(e.library_entry_id);
  }
  return ids;
};

const onLibraryConfirm = (ids: string[]) => {
  const targetId = libraryTargetId.value;
  if (!targetId) {
    libraryTargetId.value = null;
    return;
  }
  const existingIds = getReferencedIds(targetId);
  const newIds = new Set(ids);
  const group = gs.settings.filter_settings.groups.find(g => g.id === targetId);
  if (!group) {
    libraryTargetId.value = null;
    return;
  }
  for (const id of ids) {
    if (!existingIds.has(id)) {
      gs.addFilterGroupEntry(targetId, { library_entry_id: id, inline_rule: null });
    }
  }
  for (const id of existingIds) {
    if (!newIds.has(id)) {
      const idx = group.entries.findIndex(e => e.library_entry_id === id);
      if (idx !== -1) gs.removeFilterGroupEntry(targetId, idx);
    }
  }
  libraryTargetId.value = null;
};

const onDeleteGroup = (id: string) => {
  deleteTarget.value = id;
};

const onDeleteConfirm = () => {
  if (deleteTarget.value) {
    gs.removeFilterGroup(deleteTarget.value);
    deleteTarget.value = null;
  }
};

const addCharGroup = () => {
  if (currentCharName.value === (t`Not selected` as string)) {
    showCharWarning.value = true;
    return;
  }
  gs.addFilterGroup('character');
};

const getActiveGroups = computed(() => {
  const preset = gs.currentPresetName;
  const chid = gs.currentCharacterId;
  return gs.settings.filter_settings.groups.filter(g => {
    if (!g.enabled) return false;
    if (g.preset_name !== null && g.preset_name !== preset) return false;
    if (g.character_id !== null && g.character_id !== chid) return false;
    return true;
  });
});

const activeDuplicateKeys = computed(() => {
  const entryKeys = new Map<string, { groupId: string; entryIdx: number }[]>();
  const groups = getActiveGroups.value;
  for (const group of groups) {
    for (let i = 0; i < group.entries.length; i++) {
      const entry = group.entries[i];
      let key: string | null = null;
      if (entry.library_entry_id) {
        key = `lib:${entry.library_entry_id}`;
      } else if (entry.inline_rule) {
        // 三区只有 tag/regex 两种过滤语义（提取只在页顶快速区）；extract 走不进任何分支即不标红
        if (entry.inline_rule.type === 'tag') {
          if (entry.inline_rule.start || entry.inline_rule.end) {
            key = `inline:tag:${entry.inline_rule.start}|||${entry.inline_rule.end}`;
          }
        } else if (entry.inline_rule.type === 'regex' && entry.inline_rule.pattern) {
          key = `inline:regex:${entry.inline_rule.pattern}`;
        }
      }
      if (key) {
        if (!entryKeys.has(key)) entryKeys.set(key, []);
        entryKeys.get(key)!.push({ groupId: group.id, entryIdx: i });
      }
    }
  }
  const duplicates = new Set<string>();
  for (const [, items] of entryKeys) {
    if (items.length > 1) {
      for (const item of items) {
        duplicates.add(`${item.groupId}:${item.entryIdx}`);
      }
    }
  }
  return duplicates;
});

const getDuplicateIndices = (groupId: string): Set<number> => {
  const indices = new Set<number>();
  for (const key of activeDuplicateKeys.value) {
    if (key.startsWith(`${groupId}:`)) {
      indices.add(parseInt(key.split(':')[1], 10));
    }
  }
  return indices;
};

const globalListEl = ref<HTMLElement | null>(null);
const presetListEl = ref<HTMLElement | null>(null);
const charListEl = ref<HTMLElement | null>(null);
const sortables: Sortable[] = [];

function createSortable(el: HTMLElement) {
  return Sortable.create(el, {
    ...draggableFilterOptions,
    animation: 150,
    group: 'filter-groups',
    handle: DRAG_HANDLE_GROUP_SELECTOR,
    onMove: evt => {
      const toArea = (evt.to as HTMLElement).dataset.area;
      // 未绑定角色卡时禁止拖入 character 区；其余路径显式 return true（SortableJS 约定非 false 即放行）
      if (toArea === 'character' && gs.currentCharacterId == null) {
        return false;
      }
      return true;
    },
    onEnd: evt => {
      if (evt.oldIndex === undefined || evt.newIndex === undefined) return;
      const toArea = (evt.to as HTMLElement).dataset.area;
      const groupId = evt.item.dataset.groupId;
      if (!groupId) return;
      const group = gs.settings.filter_settings.groups.find(g => g.id === groupId);
      if (!group) return;
      // 跨区先改归属：改后 moved 才脱离原区成员集、进入目标区成员集
      if (toArea === 'global') {
        group.preset_name = null;
        group.character_id = null;
      } else if (toArea === 'preset') {
        group.preset_name = gs.currentPresetName;
        group.character_id = null;
      } else if (toArea === 'character') {
        group.preset_name = null;
        group.character_id = gs.currentCharacterId ?? null;
      }
      const groups = gs.settings.filter_settings.groups;
      const fromIdx = groups.findIndex(g => g.id === groupId);
      if (fromIdx === -1) return;
      const [moved] = groups.splice(fromIdx, 1);
      // 插入点按「目标区在 store 中的成员序（moved 已移出）」计算：evt.newIndex 是拖拽后
      // moved 在目标 DOM 列表的位置，插到同位成员之前即与 DOM 一致。此前实现取「区谓词
      // 命中的第一个成员」下标再 ±1：向下拖多格只会落到原位下一格、向上拖非顶部位置直接跳顶部
      const areaMembers = groups.filter(g => {
        if (toArea === 'global') return g.preset_name === null && g.character_id === null && g.id !== gs.extractGroupId;
        if (toArea === 'preset') return g.preset_name !== null;
        return g.character_id !== null;
      });
      const anchor = areaMembers[evt.newIndex];
      if (!anchor) {
        // 拖到区末尾（或目标区仅剩 moved 自己）：跟在该区最后一个成员之后；区为空则尾插
        const last = areaMembers[areaMembers.length - 1];
        if (!last) {
          groups.push(moved);
          return;
        }
        groups.splice(groups.findIndex(g => g.id === last.id) + 1, 0, moved);
        return;
      }
      groups.splice(
        groups.findIndex(g => g.id === anchor.id),
        0,
        moved,
      );
    },
  });
}

onMounted(() => {
  if (globalListEl.value) sortables.push(createSortable(globalListEl.value));
  if (presetListEl.value) sortables.push(createSortable(presetListEl.value));
  if (charListEl.value) sortables.push(createSortable(charListEl.value));
});

onUnmounted(() => {
  for (const s of sortables) s.destroy();
});
</script>

<style scoped>
.choice-filter-editor {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-4);
}

/* 正则区卡片标题行：标题左、右侧动作（新增分组等）靠右 */
.choice-filter-card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: var(--choice-space-2);
  margin-bottom: var(--choice-space-2);
}

/* 状态栏窄屏换行：徽章 flex-shrink:0 + 4 枚横排在窄面板必溢出，允许折行兜底 */
.choice-config-status {
  flex-wrap: wrap;
}

.choice-filter-group-list {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
}

/* 标签提取快速区：中性虚线卡片，传达"这是更简单的另一条路"——
   不用主色浅底（primary-light 会抢三个正则区的视觉焦点，新手辅助不该盖过主入口） */
.choice-extract-quick {
  border: 1px dashed var(--choice-border-strong);
  border-radius: var(--choice-radius-sm);
  padding: var(--choice-space-2) var(--choice-space-3);
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
  background: var(--choice-bg-card);
}

.choice-extract-quick-head {
  display: flex;
  align-items: baseline;
  gap: var(--choice-space-2);
  flex-wrap: wrap;
}

/* 酒馆正则总开关行：与标签提取快速区同源 baseline 布局 */
.choice-stregex-head {
  display: flex;
  align-items: baseline;
  gap: var(--choice-space-2);
  flex-wrap: wrap;
}

/* 总开关对齐标题行：baseline 布局下开关需要自身居中修正 */
.choice-extract-quick-switch {
  align-self: center;
  margin-left: auto;
}

.choice-stregex-switch {
  align-self: center;
  margin-left: auto;
}

.choice-stregex-desc {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
}

/* 总开关关闭：chips 灰显但仍可见（规则保留，只是不参与生成） */
.choice-extract-chips--off {
  opacity: 0.45;
}

.choice-extract-quick-desc {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
}

.choice-extract-quick-row {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
}

/* 实时预览行：输入标签名后立即演示实际会保留的标签对，讲清"单框填什么" */
.choice-extract-preview {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
  line-height: 1.5;
}

.choice-extract-preview-tag {
  font-family: var(--choice-font-mono);
  color: var(--choice-primary-hover, var(--choice-primary));
  background: var(--choice-bg-element);
  border-radius: var(--choice-radius-sm);
  padding: 0 var(--choice-space-1);
}

.choice-extract-input {
  flex: 1;
  min-width: 0;
}

.choice-extract-chips {
  display: flex;
  flex-wrap: wrap;
  gap: var(--choice-space-1);
}

.choice-extract-chip {
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-1);
  padding: 2px var(--choice-space-2);
  border-radius: var(--choice-radius-full);
  background: var(--choice-bg-element);
  border: 1px solid var(--choice-border-strong);
  font-size: var(--choice-text-xs);
}

.choice-extract-chip-tag {
  font-family: var(--choice-font-mono);
}

.choice-extract-chip i {
  cursor: pointer;
  color: var(--choice-text-muted);
  transition: color var(--choice-transition);
}

.choice-extract-chip i:hover {
  color: var(--choice-color-error);
}
</style>
