<template>
  <Teleport to="body">
    <div v-if="open" class="choice-epool-overlay" @click.self="emit('close')">
      <div class="choice-epool-dialog">
        <div class="choice-epool-header">
          <span class="choice-epool-title">
            <i class="fa-solid fa-database"></i>
            {{ t`Entry Library` }}
            <span class="choice-epool-count">({{ masterPool.length }})</span>
          </span>
          <div class="choice-epool-header-actions" data-tour="entrypool-toolbar">
            <button
              class="choice-icon-btn"
              :title="allGroupsExpanded ? t`Collapse All` : t`Expand All`"
              @click="toggleExpandAllGroups"
            >
              <i :class="allGroupsExpanded ? 'fa-solid fa-compress' : 'fa-solid fa-expand'"></i>
            </button>
            <button class="choice-icon-btn" :title="t`New Group`" @click="createGroup">
              <i class="fa-solid fa-folder-plus"></i>
            </button>
            <button class="choice-icon-btn" :title="t`Import File`" @click="showImportSource = true">
              <i class="fa-solid fa-file-import"></i>
            </button>
            <button class="choice-icon-btn" :title="exportBtnTitle" @click="onExportPool">
              <i class="fa-solid fa-file-export"></i>
            </button>
            <button ref="guideBtn" class="choice-icon-btn" :title="t`Page Guide`" @click="showGuide = !showGuide">
              <i class="fa-solid fa-circle-question"></i>
            </button>
            <button class="choice-epool-close" :title="t`Close`" @click="emit('close')">&times;</button>
          </div>
        </div>

        <div class="choice-epool-body choice-scrollbar">
          <div v-if="groupedEntries.length > 0" ref="groupList" class="choice-epool-list">
            <div
              v-for="group in groupedEntries"
              :key="group.key"
              class="choice-epool-group"
              :data-group-key="group.key"
            >
              <div class="choice-epool-group-head" @click="toggleGroup(group.key)">
                <DragHandle :title="t`Drag to reorder`" @click.stop />
                <label class="choice-check" @click.stop>
                  <input type="checkbox" :checked="isGroupAllSelected(group)" @change="toggleSelectGroup(group)" />
                </label>
                <i class="fa-solid" :class="expandedGroups.has(group.key) ? 'fa-chevron-down' : 'fa-chevron-right'"></i>
                <span v-if="groupRenameId !== group.key" class="choice-epool-group-name">{{
                  group.key || t`Ungrouped`
                }}</span>
                <input
                  v-else
                  ref="groupRenameInput"
                  v-model="groupRenameText"
                  class="text_pole"
                  style="width: 120px; font-size: var(--choice-text-xs)"
                  @keydown.enter="finishGroupRename(group.key)"
                  @keydown.escape="cancelGroupRename"
                  @click.stop
                />
                <span class="choice-epool-group-count">({{ group.entries.length }})</span>
                <button
                  class="choice-icon-btn"
                  :title="groupRenameId === group.key ? t`Save` : t`Rename`"
                  @click.stop="groupRenameId === group.key ? finishGroupRename(group.key) : startGroupRename(group.key)"
                >
                  <i :class="groupRenameId === group.key ? 'fa-solid fa-check' : 'fa-solid fa-pen-to-square'"></i>
                </button>
                <button
                  v-if="groupRenameId === group.key"
                  class="choice-icon-btn"
                  :title="t`Cancel`"
                  @click.stop="cancelGroupRename"
                >
                  <i class="fa-solid fa-xmark"></i>
                </button>
                <button class="choice-icon-btn" :title="t`Add Entry`" @click.stop="addEntryToGroup(group.key)">
                  <i class="fa-solid fa-plus"></i>
                </button>
                <button class="choice-icon-btn" :title="t`Copy All`" @click.stop="copyGroup(group)">
                  <i class="fa-solid fa-copy"></i>
                </button>
                <button
                  class="choice-icon-btn choice-delete-btn"
                  :title="t`Delete Group`"
                  @click.stop="deleteTarget = { type: 'group', key: group.key, count: group.entries.length }"
                >
                  <i class="fa-solid fa-trash-can"></i>
                </button>
              </div>
              <div
                :class="['choice-epool-group-body', { 'is-collapsed': !expandedGroups.has(group.key) }]"
                :data-group-key="group.key"
              >
                <div v-if="group.entries.length === 0" class="choice-empty-hint">
                  <span>{{ t`No entries. Click + to add.` }}</span>
                </div>
                <div
                  v-for="entry in group.entries"
                  :key="entry.id"
                  class="choice-epool-entry"
                  :data-entry-id="entry.id"
                >
                  <div class="choice-epool-entry-head">
                    <DragHandle :title="t`Drag to reorder or move between groups`" />
                    <label class="choice-check" @click.stop>
                      <input type="checkbox" :checked="selected.has(entry.id)" @change="toggleSelectEntry(entry.id)" />
                    </label>
                    <i
                      class="fa-solid"
                      :class="expanded.has(entry.id) ? 'fa-chevron-down' : 'fa-chevron-right'"
                      @click="toggleEntry(entry.id)"
                    ></i>
                    <span class="choice-epool-entry-summary" @click="toggleEntry(entry.id)">{{
                      entrySummary(entry)
                    }}</span>
                    <span v-if="entry.pinned" class="choice-pin-badge">📌</span>
                    <select
                      :value="entry.category"
                      class="text_pole choice-cat-select"
                      :title="t`Move to Group`"
                      @change="onEntryCategoryChange(entry, ($event.target as HTMLSelectElement).value)"
                      @click.stop
                    >
                      <option value="">{{ t`Ungrouped` }}</option>
                      <option v-for="cat in categoryNames" :key="cat" :value="cat">{{ cat }}</option>
                    </select>
                    <button
                      class="choice-icon-btn choice-delete-btn"
                      :title="t`Delete`"
                      @click.stop="deleteTarget = { type: 'entry', id: entry.id, summary: entrySummary(entry) }"
                    >
                      <i class="fa-solid fa-trash-can"></i>
                    </button>
                  </div>
                  <div v-if="expanded.has(entry.id)" class="choice-epool-entry-body">
                    <input v-model="entry.type" class="text_pole" :placeholder="t`Entry type (short tag)`" />
                    <textarea
                      v-model="entry.content"
                      class="text_pole"
                      :placeholder="t`AI Generate Prompt`"
                      rows="2"
                    ></textarea>
                    <input v-model="entry.rule" class="text_pole" :placeholder="t`Rule (applicable timing / writing constraint, optional)`" />
                    <div class="choice-epool-entry-fields">
                      <label class="choice-check">
                        <input v-model="entry.pinned" type="checkbox" />
                        {{ t`Pinned` }}
                      </label>
                      <input
                        v-model.number="entry.weight"
                        class="text_pole choice-small-input"
                        type="number"
                        min="0"
                        :title="t`Weight (weighted random)`"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div v-else class="choice-empty-hint">
            <i class="fa-solid fa-database"></i>
            <span>{{ t`Entry pool is empty. Click + to add` }}</span>
          </div>
        </div>

        <ImportPoolDialog
          :open="showImportPool"
          :data="importFileData"
          :initial-mode="'replace'"
          @close="showImportPool = false"
          @confirm="onImportPoolConfirm"
        />

        <!-- 导入源对话框：粘贴/选文件 → 「解析并合并导入」直接落库（一步到位）；
             「替换整个条目库」走预览确认（危险操作）。失败红字显示在对话框内 -->
        <ImportSourceDialog
          :open="showImportSource"
          :title="t`Import Entry Pool`"
          :error="importSourceError"
          :show-replace="true"
          @close="showImportSource = false"
          @merge="onImportMerge"
          @replace="onImportReplace"
        />

        <ConfirmDialog
          :open="deleteTarget !== null"
          :title="deleteDialogTitle"
          :message="deleteDialogMessage"
          :confirm-text="t`Delete`"
          :cancel-text="t`Cancel`"
          @confirm="onDeleteConfirm"
          @cancel="deleteTarget = null"
        />

        <GuidePopover
          :visible="showGuide"
          :anchor-el="guideBtn"
          :hint="DIALOG_HINTS.entryPool"
          @close="showGuide = false"
        />
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import toastr from 'toastr';
import { uuidv4 } from '@sillytavern/scripts/utils';
import ImportPoolDialog from '@/components/ImportPoolDialog.vue';
import ConfirmDialog from '@/components/ConfirmDialog.vue';
import GuidePopover from '@/components/GuidePopover.vue';
import { DIALOG_HINTS } from '@/core/guide-content';
import DragHandle from '@/components/shared/DragHandle.vue';
import { useGlobalSettingsStore } from '@/store/global-settings';
import { PoolConfig, type PoolEntry } from '@/type/settings';
import { DRAG_HANDLE_SELECTOR, draggableFilterOptions } from '@/util/sortable';
import { isoTimestamp } from '@/util/time';
import ImportSourceDialog from '@/components/shared/ImportSourceDialog.vue';
import Sortable from 'sortablejs';
import { focusPoolEntryId } from '@/core/floating-state';

const props = defineProps<{ open: boolean }>();
const emit = defineEmits<{ close: [] }>();

const globalStore = useGlobalSettingsStore();
const masterPool = computed(() => globalStore.settings.master_pool);
const configs = computed(() => globalStore.settings.configs);

const expanded = ref<Set<string>>(new Set());
const expandedGroups = ref<Set<string>>(new Set());
const allGroupsExpanded = ref(false);
const groupRenameId = ref<string | null>(null);
const groupRenameText = ref('');
const showImportPool = ref(false);
const importFileData = ref<any>(null);
const showGuide = ref(false);
const guideBtn = ref<HTMLElement | null>(null);

const deleteTarget = ref<
  { type: 'entry'; id: string; summary: string } | { type: 'group'; key: string; count: number } | null
>(null);
const selected = ref<Set<string>>(new Set());
const pendingGroups = computed({
  get: () => new Set(globalStore.settings.empty_groups),
  set: val => {
    globalStore.settings.empty_groups = [...val];
  },
});

const addPendingGroup = (key: string) => {
  if (!globalStore.settings.empty_groups.includes(key)) {
    globalStore.settings.empty_groups = [...globalStore.settings.empty_groups, key];
  }
};
const removePendingGroup = (key: string) => {
  globalStore.settings.empty_groups = globalStore.settings.empty_groups.filter(k => k !== key);
};
const hasPendingGroup = (key: string): boolean => {
  return globalStore.settings.empty_groups.includes(key);
};

watch(
  () => props.open,
  val => {
    if (!val) {
      deleteTarget.value = null;
      selected.value = new Set();
      groupRenameId.value = null;
    }
  },
);

// ── 统计页「定位条目」：滚动到目标条目并短暂高亮 ──
// 定义与 watch 放在 groupedEntries 之后（scrollToFocusedEntry 引用 groupedEntries，
// 避免 temporal dead zone）。watch 用 immediate 以覆盖「从其他 tab 跳转过来」场景：
// PoolEditor 的 immediate watch 在 setup 期间同步设 showEntryPool=true，EntryPoolDialog
// 挂载时 props.open 已是 true、focusPoolEntryId 已非 null——非 immediate 的 watch
// 不会因「值未变化」而触发，导致定位不执行。immediate + nextTick 保证挂载即定位。
let focusTimer: number | null = null;

const categoryNames = computed(() => {
  const names = new Set<string>();
  for (const e of masterPool.value) {
    if (e.category.trim()) names.add(e.category.trim());
  }
  for (const name of pendingGroups.value) {
    names.add(name);
  }
  return [...names].sort();
});

type EntryGroup = { key: string; entries: PoolEntry[] };

const groupedEntries = computed<EntryGroup[]>(() => {
  const map = new Map<string, PoolEntry[]>();
  for (const entry of masterPool.value) {
    const key = entry.category.trim() || '';
    let group = map.get(key);
    if (!group) {
      group = [];
      map.set(key, group);
    }
    group.push(entry);
  }
  for (const name of pendingGroups.value) {
    if (!map.has(name)) {
      map.set(name, []);
    }
  }
  const groups: EntryGroup[] = [];
  for (const [key, entries] of map) {
    groups.push({ key, entries });
  }
  // 显示顺序与 group_order 对齐（拖拽排序的读取端，此前只写不读——拖完任何重算即回弹，
  // 且二次拖动用 DOM 索引 splice 字母序数组会把 group_order 写错）：group_order 命中的
  // 分组按其顺序在前，未收录的分组（新建/导入/重命名遗留）按字母序补后，「未分组」恒最后。
  // 与统计侧 entryGroups 的排序语义同源，防同一份 group_order 两套口径。
  const used = new Set<string>();
  const ordered: EntryGroup[] = [];
  for (const key of globalStore.settings.group_order) {
    // 未分组恒最后、由下方统一追加：历史 group_order 可能含 ''（旧版拖拽把未分组键一并写入），
    // 在此收录会让「未分组」出现两次、v-for :key 撞车
    if (key === '') continue;
    // 历史坏数据可能把同一分组写进 order 两次（旧拖拽 bug 的产物），跳过重复防 v-for :key 撞车
    if (used.has(key)) continue;
    const g = groups.find(x => x.key === key);
    if (g) {
      ordered.push(g);
      used.add(g.key);
    }
  }
  const rest = groups.filter(g => !used.has(g.key) && g.key !== '').sort((a, b) => a.key.localeCompare(b.key));
  const ungrouped = groups.find(g => g.key === '');
  return [...ordered, ...rest, ...(ungrouped ? [ungrouped] : [])];
});

// ── 统计页「定位条目」实现（须在 groupedEntries 之后定义，避免 TDZ） ──
const scrollToFocusedEntry = () => {
  const id = focusPoolEntryId.value;
  if (!id) return;
  // 先确保目标条目所在分组展开——折叠组 max-height:4px + overflow:hidden，
  // DOM 虽在但视觉不可见、getBoundingClientRect 异常，须先移除 is-collapsed
  const group = groupedEntries.value.find(g => g.entries.some(e => e.id === id));
  if (group) {
    expanded.value.add(id);
    expandedGroups.value.add(group.key);
  }
  nextTick(() => {
    const el = document.querySelector<HTMLElement>(`.choice-epool-entry[data-entry-id="${CSS.escape(id)}"]`);
    const body = document.querySelector<HTMLElement>('.choice-epool-body');
    if (!el || !body) {
      // 目标条目已从 master_pool 删除或 DOM 未就绪：置回信号避免残留
      focusPoolEntryId.value = null;
      return;
    }
    // 禁用原生 scrollIntoView——它会连滚所有可滚祖先（含竖向），移动端会把弹窗
    // 背后的酒馆页面一起拖走。参照 FloatingSettings 的 strip 滚动算法手算 scrollTop
    const elRect = el.getBoundingClientRect();
    const bodyRect = body.getBoundingClientRect();
    const target = body.scrollTop + (elRect.top - bodyRect.top) - (body.clientHeight - elRect.height) / 2;
    body.scrollTop = Math.max(0, target);
    el.classList.add('choice-epool-entry--focus');
    if (focusTimer !== null) window.clearTimeout(focusTimer);
    focusTimer = window.setTimeout(() => {
      el.classList.remove('choice-epool-entry--focus');
      focusTimer = null;
    }, 1800);
    // 消费完成，置回信号
    focusPoolEntryId.value = null;
  });
};

// immediate 覆盖「从 stats tab 跳转」场景：EntryPoolDialog 挂载时 open 和
// focusPoolEntryId 均已是目标值（非变化），非 immediate 不会触发。
watch(
  [() => props.open, focusPoolEntryId],
  ([open, id]) => {
    if (open && id) scrollToFocusedEntry();
  },
  { immediate: true },
);

// 清理高亮定时器——PoolEditor 在非 pool tab 时会 unmount（v-if），连带卸载本组件
onUnmounted(() => {
  if (focusTimer !== null) {
    window.clearTimeout(focusTimer);
    focusTimer = null;
  }
});

const entrySummary = (entry: PoolEntry): string => {
  const type = entry.type.trim();
  if (!type && !entry.content.trim()) return t`<Empty Entry>`;
  if (!entry.content.trim()) return type.slice(0, 50);
  return type.replace(/"/g, '') + ' | ' + entry.content.replace(/"/g, '').slice(0, 40);
};

const toggleEntry = (id: string) => {
  deleteTarget.value = null;
  if (expanded.value.has(id)) expanded.value.delete(id);
  else expanded.value.add(id);
};

const toggleGroup = (key: string) => {
  deleteTarget.value = null;
  if (expandedGroups.value.has(key)) expandedGroups.value.delete(key);
  else expandedGroups.value.add(key);
};

const onEntryCategoryChange = (entry: PoolEntry, newCat: string) => {
  const oldCat = entry.category.trim() || '';
  entry.category = newCat;
  if (oldCat && oldCat !== newCat) {
    if (hasPendingGroup(newCat)) removePendingGroup(newCat);
    const fromEntries = masterPool.value.filter(e => (e.category.trim() || '') === oldCat);
    if (fromEntries.length === 0) addPendingGroup(oldCat);
  }
};

const toggleExpandAllGroups = () => {
  deleteTarget.value = null;
  if (allGroupsExpanded.value) {
    expandedGroups.value = new Set();
    allGroupsExpanded.value = false;
  } else {
    const allKeys = new Set(groupedEntries.value.map(g => g.key));
    for (const name of pendingGroups.value) allKeys.add(name);
    expandedGroups.value = allKeys;
    allGroupsExpanded.value = true;
  }
};

const copyGroup = (group: EntryGroup) => {
  deleteTarget.value = null;
  const texts = group.entries
    .map(e => (e.content.trim() ? `${e.type}: ${e.content}` : e.type))
    .filter(t => t.trim())
    .join('\n');
  if (!texts) {
    toastr.warning(t`Nothing to copy`);
    return;
  }
  navigator.clipboard
    .writeText(texts)
    .then(() => {
      toastr.success(t`Copied ${group.entries.length} strip to clipboard`);
    })
    .catch(() => {
      const ta = document.createElement('textarea');
      ta.value = texts;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        toastr.success(t`Copied ${group.entries.length} strip to clipboard`);
      } catch {
        toastr.error(t`Copy failed`);
      }
      document.body.removeChild(ta);
    });
};

const toggleSelectEntry = (id: string) => {
  deleteTarget.value = null;
  if (selected.value.has(id)) selected.value.delete(id);
  else selected.value.add(id);
};

const isGroupAllSelected = (group: EntryGroup) =>
  group.entries.length > 0 && group.entries.every(e => selected.value.has(e.id));

const toggleSelectGroup = (group: EntryGroup) => {
  deleteTarget.value = null;
  if (isGroupAllSelected(group)) {
    for (const e of group.entries) selected.value.delete(e.id);
  } else {
    for (const e of group.entries) selected.value.add(e.id);
  }
};

const createGroup = () => {
  deleteTarget.value = null;
  const name = prompt(t`Enter group name`);
  if (!name || !name.trim()) return;
  const trimmed = name.trim();
  if (categoryNames.value.includes(trimmed)) {
    toastr.warning(t`Group "${trimmed}” already exists`);
    return;
  }
  addPendingGroup(trimmed);
  expandedGroups.value.add(trimmed);
  allGroupsExpanded.value = false;
};

const startGroupRename = (groupKey: string) => {
  groupRenameId.value = groupKey;
  groupRenameText.value = groupKey;
};

const finishGroupRename = (oldKey: string) => {
  const newName = groupRenameText.value.trim();
  if (!newName || newName === oldKey) {
    groupRenameId.value = null;
    return;
  }
  if (newName !== oldKey && categoryNames.value.includes(newName) && newName !== groupRenameId.value) {
    toastr.warning(t`Group "${newName}” already exists`);
    groupRenameId.value = null;
    return;
  }
  for (const entry of masterPool.value) {
    if ((entry.category.trim() || '') === oldKey) {
      entry.category = newName;
    }
  }
  const orderIdx = globalStore.settings.group_order.indexOf(oldKey);
  if (orderIdx !== -1) globalStore.settings.group_order[orderIdx] = newName;
  if (hasPendingGroup(oldKey)) {
    removePendingGroup(oldKey);
    addPendingGroup(newName);
  }
  groupRenameId.value = null;
};

const cancelGroupRename = () => {
  groupRenameId.value = null;
};

const addEntryToGroup = (groupKey: string) => {
  deleteTarget.value = null;
  const entry: PoolEntry = {
    id: uuidv4(),
    type: '',
    content: '',
    rule: '',
    pinned: false,
    weight: 1,
    category: groupKey,
  };
  masterPool.value.push(entry);
  expanded.value.add(entry.id);
  expandedGroups.value.add(groupKey);
  if (hasPendingGroup(groupKey)) {
    removePendingGroup(groupKey);
  }
};

const removeEntry = (id: string) => {
  const idx = masterPool.value.findIndex(e => e.id === id);
  const cat = idx !== -1 ? masterPool.value[idx].category.trim() || '' : '';
  if (idx !== -1) masterPool.value.splice(idx, 1);
  expanded.value.delete(id);
  deleteTarget.value = null;
  for (const cfg of configs.value) {
    const eidx = cfg.entries.findIndex(e => e.entry_id === id);
    if (eidx !== -1) cfg.entries.splice(eidx, 1);
  }
  // 删空且非挂起的分组从 group_order 清除：残留键会成为导出文件/统计侧的幽灵分组
  // （移动走最后一条走 addPendingGroup 保组，此处删空不保——与既有行为一致）
  if (cat !== '' && !hasPendingGroup(cat) && !masterPool.value.some(e => (e.category.trim() || '') === cat)) {
    const oi = globalStore.settings.group_order.indexOf(cat);
    if (oi !== -1) globalStore.settings.group_order.splice(oi, 1);
  }
};

const removeGroup = (group: EntryGroup) => {
  const ids = new Set(group.entries.map(e => e.id));
  for (let i = masterPool.value.length - 1; i >= 0; i--) {
    if (ids.has(masterPool.value[i].id)) {
      masterPool.value.splice(i, 1);
    }
  }
  for (const id of ids) {
    expanded.value.delete(id);
  }
  expandedGroups.value.delete(group.key);
  removePendingGroup(group.key);
  deleteTarget.value = null;
  // 同步清理持久化排序键：残留会成为导出文件/统计侧的幽灵分组（分组数虚高、重命名静默无效）
  const orderIdx = globalStore.settings.group_order.indexOf(group.key);
  if (orderIdx !== -1) globalStore.settings.group_order.splice(orderIdx, 1);
  for (const cfg of configs.value) {
    for (let i = cfg.entries.length - 1; i >= 0; i--) {
      if (ids.has(cfg.entries[i].entry_id)) {
        cfg.entries.splice(i, 1);
      }
    }
  }
};

// 部分导出：勾选模式下仅导出勾选的条目与其所属分组；无勾选则全量导出。
// partial 时 configs 置空并带标记——配置按 entry_id 引用条目，部分条目无法还原完整配置，
// 导入端据此禁用"替换"选项，防止替换导入清空现有配置
const onExportPool = () => {
  const partial = selected.value.size > 0;
  const pool = partial ? masterPool.value.filter(e => selected.value.has(e.id)) : masterPool.value;
  // 空库导出防护：空文件导回去再导入会把库清空却提示"成功"（死亡循环），直接阻止
  if (pool.length === 0) {
    toastr.warning(t`Entry pool is empty, nothing to export`);
    return;
  }
  const groupOrder = partial
    ? globalStore.settings.group_order.filter(g => pool.some(e => (e.category || '') === g))
    : globalStore.settings.group_order;
  const json = JSON.stringify(
    {
      version: 1,
      type: 'choice-pool-export',
      exportedAt: isoTimestamp(),
      partial,
      data: {
        master_pool: pool,
        configs: partial ? [] : globalStore.settings.configs,
        group_order: groupOrder,
      },
    },
    null,
    2,
  );
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `choice-pool-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  toastr.success(partial ? t`Exported selected ${pool.length} entries` : t`Exported all ${pool.length} entries`);
};

// 头部"导出文件"按钮 title 随勾选数动态提示部分导出
const exportBtnTitle = computed(() =>
  selected.value.size > 0 ? t`Export files (export only selected ${selected.value.size} Article)` : t`Export File`,
);

// 导入选文件走 pickJsonFile（showOpenFilePicker 优先 + 挂载式 input 回退，
// 见 util/file-picker.ts 顶注——分离/隐藏 input 在真机会被静默拦截）
// 导入入口改为 ImportSourceDialog：
// 「解析并合并导入」直接落库（粘贴后一步到位，条目立刻出现在库里）；
// 「替换整个条目库」走预览确认（危险操作）。
// 解析失败红字显示在对话框内，粘贴内容不丢失
const showImportSource = ref(false);
const importSourceError = ref('');

// 公共解析：去 BOM/首尾杂质 + type 校验，失败时写红字并返回 null
const parseImportText = (text: string): any | null => {
  let data: any;
  try {
    const clean = text.replace(/^\uFEFF/, '').trim();
    data = JSON.parse(clean);
  } catch (err: any) {
    importSourceError.value = t`JSON parsing failed:${err?.message ?? err}. Please make sure you paste the complete contents of the exported file (from { to })`;
    return null;
  }
  if (data?.type !== 'choice-pool-export') {
    importSourceError.value = t`Incorrect file format: type=${data?.type ?? 'None'}, requires choice-pool-export (item library exported file). Files exported from the regular library cannot be imported into the entry library`;
    return null;
  }
  return data;
};

/** 导入条目清洗：外部文件可能手工编辑/截断——缺 id 会毁掉模板 :key 与配置引用、
 *  字段类型漂移会进 store 持久化并在下次加载被 zod 拒收。逐字段归一；正文与类型
 *  双空的条目作废（无内容条目无意义），id 缺失/非字符串补 uuid。 */
const sanitizeImportedEntry = (raw: unknown): PoolEntry | null => {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const content = typeof r.content === 'string' ? r.content : '';
  const type = typeof r.type === 'string' ? r.type.trim() : '';
  if (!content.trim() && !type) return null;
  return {
    id: typeof r.id === 'string' && r.id ? r.id : uuidv4(),
    type,
    content,
    rule: typeof r.rule === 'string' ? r.rule : '',
    pinned: !!r.pinned,
    weight: Number.isFinite(r.weight) ? Math.max(0, Number(r.weight)) : 1,
    category: typeof r.category === 'string' ? r.category : '',
  };
};

/** 导入数据整体清洗：条目逐张清洗、配置走 PoolConfig zod 校验（带 defaults，旧版本
 *  导出缺新字段时自动补齐）、group_order 只收字符串。返回清洗后的可导入数据，
 *  条目全无效时返回 null（调用方提示取消）。 */
const sanitizeImportData = (raw: any): { master_pool: PoolEntry[]; configs: any[]; group_order: string[] } | null => {
  const masterPool = Array.isArray(raw?.master_pool) ? raw.master_pool : [];
  const pool: PoolEntry[] = masterPool
    .map(sanitizeImportedEntry)
    .filter((e: PoolEntry | null): e is PoolEntry => e !== null);
  if (!pool.length) return null;
  const configs = Array.isArray(raw?.configs)
    ? raw.configs
        .map((c: unknown) => (c && typeof c === 'object' ? PoolConfig.safeParse(c) : null))
        .filter((p: any): p is { success: true; data: any } => !!p?.success)
        .map((p: any) => p.data)
    : [];
  // group_order 只收「清洗后条目里真实存在的具名分组」：文件里的残留键（条目被清洗掉/
  // 导出源就有的幽灵分组）会经导出/统计侧再次扩散；「未分组」（''）不是用户分组，恒不收
  const cats = new Set(pool.map(e => e.category.trim() || ''));
  const group_order = (Array.isArray(raw?.group_order) ? (raw.group_order as unknown[]) : []).filter(
    (g): g is string => typeof g === 'string' && g !== '' && cats.has(g),
  );
  return { master_pool: pool, configs, group_order };
};

// 合并导入：直接落库，条目立刻出现（按 id 去重，重复文件不会产生重复条目）
const onImportMerge = ({ text }: { text: string; fileName: string }) => {
  importSourceError.value = '';
  const data = parseImportText(text);
  if (!data) return;
  const clean = sanitizeImportData(data.data);
  // 空条目文件防护：空库时期导出的文件导入后"成功"却什么都没有（死亡循环），直接阻止
  if (!clean) {
    importSourceError.value = t`No recognizable valid entries in this file (master_pool empty or entries missing content/type); cannot import`;
    return;
  }
  const { master_pool, configs, group_order } = clean;
  const existingIds = new Set(globalStore.settings.master_pool.map(e => e.id));
  const newEntries = master_pool.filter(e => !existingIds.has(e.id));
  if (newEntries.length) globalStore.settings.master_pool.push(...newEntries);
  if (configs.length) {
    for (const cfg of configs) {
      if (!globalStore.settings.configs.some(c => c.name === cfg.name)) {
        globalStore.settings.configs.push(cfg);
      }
    }
  }
  if (group_order.length) {
    for (const g of group_order) {
      if (!globalStore.settings.group_order.includes(g)) {
        globalStore.settings.group_order.push(g);
      }
    }
  }
  showImportSource.value = false;
  // 跳过提示先算再插值：插值里嵌反引号模板会让运行时 i18n 键与对账提取口径错位
  const skippedNote =
    master_pool.length - newEntries.length > 0 ? t`（${master_pool.length - newEntries.length} The item already exists, skip)` : '';
  toastr.success(
    newEntries.length
      ? t`Imported ${newEntries.length} entries${skippedNote}`
      : t`All ${master_pool.length} All items already exist and have not been imported repeatedly.`,
  );
};

// 替换导入：走预览确认弹窗（ImportPoolDialog），由用户最终确认
const onImportReplace = ({ text, fileName }: { text: string; fileName: string }) => {
  importSourceError.value = '';
  const data = parseImportText(text);
  if (!data) return;
  const clean = sanitizeImportData(data.data);
  if (!clean) {
    importSourceError.value = t`No recognizable valid entries in this file (master_pool empty or entries missing content/type); cannot import`;
    return;
  }
  // 预览与最终确认共用清洗后的数据：预览看到的就是将要落库的
  importFileData.value = { ...data.data, ...clean, partial: !!data.partial, fileName, exportedAt: data.exportedAt };
  showImportSource.value = false;
  showImportPool.value = true;
};

const onImportPoolConfirm = (mode: 'merge' | 'replace') => {
  if (!importFileData.value) return;
  const { master_pool, configs, group_order } = importFileData.value;
  // 空条目文件防护：空库时期导出的文件、或内容为空的文件，导入只会把库清空/保持为空，
  // 却提示"成功"——这正是"导入成功但条目库还是空的"体验事故的来源。直接取消导入
  if (!master_pool?.length) {
    toastr.warning(t`This file contains no entries, import cancelled. Check you picked the right export file`);
    return;
  }
  // 防御：部分导出没有完整 configs，替换会清空现有配置——UI 已禁用，此处兜底按合并处理
  if (mode === 'replace' && importFileData.value.partial) {
    mode = 'merge';
  }
  if (mode === 'replace') {
    globalStore.settings.master_pool = master_pool ?? [];
    globalStore.settings.configs = configs ?? [];
    globalStore.settings.group_order = group_order ?? [];
  } else {
    // 合并按 id 去重：同一份文件合并两次不再产生重复条目（与正则库合并行为对齐）
    const existingIds = new Set(globalStore.settings.master_pool.map(e => e.id));
    const newEntries = (master_pool ?? []).filter((e: PoolEntry) => !existingIds.has(e.id));
    if (newEntries.length) globalStore.settings.master_pool.push(...newEntries);
    if (configs?.length) {
      for (const cfg of configs) {
        if (!globalStore.settings.configs.some(c => c.name === cfg.name)) {
          globalStore.settings.configs.push(cfg);
        }
      }
    }
    if (group_order?.length) {
      for (const g of group_order) {
        if (!globalStore.settings.group_order.includes(g)) {
          globalStore.settings.group_order.push(g);
        }
      }
    }
  }
  showImportPool.value = false;
  importFileData.value = null;
  toastr.success(mode === 'replace' ? t`Entry pool replaced` : t`Entry pool merged`);
};

const deleteDialogTitle = computed(() => {
  if (!deleteTarget.value) return '';
  switch (deleteTarget.value.type) {
    case 'entry':
      return t`Delete Entries`;
    case 'group':
      return t`Delete Group`;
  }
});

const deleteDialogMessage = computed(() => {
  if (!deleteTarget.value) return '';
  switch (deleteTarget.value.type) {
    case 'entry':
      return t`Are you sure you want to delete the entry"${deleteTarget.value.summary}"?" This action cannot be undone.`;
    case 'group': {
      // 分组名先算再插值：插值里嵌 t`` 会让运行时 i18n 键与对账提取口径错位
      const groupName = deleteTarget.value.key || t`Ungrouped`;
      return t`Are you sure you want to delete the group"${groupName}” and all ${deleteTarget.value.count} Articles? This action cannot be undone.`;
    }
  }
});

const onDeleteConfirm = () => {
  if (!deleteTarget.value) return;
  switch (deleteTarget.value.type) {
    case 'entry': {
      removeEntry(deleteTarget.value.id);
      break;
    }
    case 'group': {
      const target = deleteTarget.value;
      if (!target || target.type !== 'group') break;
      const group = groupedEntries.value.find(g => g.key === target.key);
      if (group) removeGroup(group);
      break;
    }
  }
};

const groupList = ref<HTMLElement | null>(null);
let groupSortable: Sortable | null = null;
const entrySortables = new Map<string, Sortable>();

const initGroupSortable = () => {
  if (!groupList.value) return;
  if (groupSortable) groupSortable.destroy();
  groupSortable = Sortable.create(groupList.value, {
    ...draggableFilterOptions,
    draggable: '.choice-epool-group',
    handle: DRAG_HANDLE_SELECTOR,
    animation: 150,
    onEnd: evt => {
      if (evt.oldIndex === undefined || evt.newIndex === undefined) return;
      const keys = groupedEntries.value.map(g => g.key);
      const [moved] = keys.splice(evt.oldIndex, 1);
      keys.splice(evt.newIndex, 0, moved);
      // group_order 只存具名分组：「未分组」（''）不是用户分组、显示端恒最后，写进去
      // 会成为导出文件与统计侧的幽灵分组键
      globalStore.settings.group_order = keys.filter(k => k !== '');
    },
  });
};

const initEntrySortables = () => {
  for (const [, s] of entrySortables) s.destroy();
  entrySortables.clear();
  const bodies = document.querySelectorAll('.choice-epool-group-body');
  bodies.forEach(body => {
    const groupKey = (body as HTMLElement).dataset.groupKey || '';
    const s = Sortable.create(body as HTMLElement, {
      ...draggableFilterOptions,
      group: 'entries',
      draggable: '.choice-epool-entry',
      handle: DRAG_HANDLE_SELECTOR,
      animation: 150,
      onEnd: evt => {
        const entryId = evt.item.dataset.entryId;
        if (!entryId) return;
        const fromKey = evt.from.dataset.groupKey || '';
        const toKey = (evt.to as HTMLElement).dataset.groupKey || '';
        if (toKey) expandedGroups.value.add(toKey);
        const entry = masterPool.value.find(e => e.id === entryId);
        if (!entry) return;
        if (fromKey !== toKey) {
          entry.category = toKey;
          if (hasPendingGroup(toKey)) removePendingGroup(toKey);
          const fromEntries = masterPool.value.filter(e => (e.category.trim() || '') === fromKey);
          if (fromEntries.length === 0) {
            addPendingGroup(fromKey);
          }
        }
        const oldIdx = masterPool.value.indexOf(entry);
        if (oldIdx !== -1) masterPool.value.splice(oldIdx, 1);
        const toEntries = masterPool.value.filter(e => (e.category.trim() || '') === toKey);
        if (evt.newIndex !== undefined && evt.newIndex < toEntries.length) {
          const ref = toEntries[evt.newIndex];
          const refIdx = masterPool.value.indexOf(ref);
          masterPool.value.splice(refIdx, 0, entry);
        } else {
          masterPool.value.push(entry);
        }
        if (!masterPool.value.includes(entry)) {
          console.warn('[Choice] The entry is lost after dragging it, re-add it', entryId);
          masterPool.value.push(entry);
        }
      },
    });
    entrySortables.set(groupKey, s);
  });
};

onMounted(() => {
  watch(
    [groupList, () => groupedEntries.value.length],
    () => {
      nextTick(() => {
        initGroupSortable();
        initEntrySortables();
      });
    },
    { immediate: true },
  );
});

onUnmounted(() => {
  if (groupSortable) groupSortable.destroy();
  for (const s of entrySortables.values()) s.destroy();
});
</script>

<style scoped>
.choice-epool-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  /* dvh = 动态视口（扣掉手机地址栏/工具栏后的可视高度）。手机上 100vh 按布局视口算，
     常大于可视高度，弹窗底部会被顶到屏幕外（"条目多时超出屏幕"的真因）。
     老内核不认识 dvh 时本行非法被忽略，自动回落上一行的 vh，两行必须成对 */
  height: 100vh;
  height: 100dvh;
  z-index: var(--choice-z-dialog);
  background: var(--choice-overlay);
  display: flex;
  justify-content: center;
  overflow-y: auto;
  /* 触屏上拖到边缘禁止滚动链传导，避免把背后的酒馆页面一起拖走 */
  overscroll-behavior: contain;
}

.choice-epool-dialog {
  width: 600px;
  max-width: 92vw;
  /* 同 dvh 回退：手机上按可视高度封顶，弹窗不再被系统栏顶出屏幕 */
  max-height: 85vh;
  max-height: 85dvh;
  margin: auto;
  background: var(--choice-bg-panel);
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-lg);
  box-shadow:
    inset 0 1px 0 var(--choice-frost-line),
    var(--choice-shadow-lg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.choice-epool-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  /* 纵向 8px 与正则库头部严格同高（两库并排对比时头部高度一致） */
  padding: var(--choice-space-2) var(--choice-space-3);
  background: linear-gradient(180deg, rgba(var(--choice-primary-rgb), 0.08), transparent);
  border-bottom: 1px solid var(--choice-border);
}

.choice-epool-title {
  font-size: var(--choice-text-base);
  font-weight: bold;
  color: var(--choice-text);
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-epool-count {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
  font-weight: normal;
}

.choice-epool-header-actions {
  display: inline-flex;
  gap: var(--choice-space-1);
  align-items: center;
}

/* 头部按钮尺寸显式约定 28px（与正则库头部一致）。此前 global 40px 触控规则
   与各组件 scoped 尺寸互相打架，两库头部一宽一窄观感割裂；头部工具条统一 28 */
.choice-epool-header .choice-icon-btn {
  width: 28px;
  height: 28px;
}

.choice-epool-close {
  background: none;
  border: none;
  color: var(--choice-text-muted);
  font-size: var(--choice-text-xl);
  cursor: pointer;
  line-height: 1;
  padding: 0 var(--choice-space-1);
  border-radius: 50%;
  width: 28px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition:
    background var(--choice-transition),
    color var(--choice-transition);
}

.choice-epool-close:hover {
  background: var(--choice-bg-hover);
  color: var(--choice-text);
}

/* 窄屏（手机）下弹窗近全屏：与 shared/ChoiceDialog 的窄屏规则一致，
   条目多时一屏能看到更多行（max-width 不同步放宽会被基础 92vw 钳住） */
@media (max-width: 480px) {
  .choice-epool-dialog {
    width: 96vw;
    max-width: 96vw;
    /* 同 dvh 回退 */
    max-height: 92vh;
    max-height: 92dvh;
  }
}

.choice-epool-body {
  overflow-y: auto;
  /* 触屏上内容拖到滚动边缘时禁止滚动链传导，避免把背后的酒馆页面一起拖走 */
  overscroll-behavior: contain;
  padding: var(--choice-space-2);
  flex: 1;
}

.choice-epool-list {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
}

/* 分组 */
.choice-epool-group {
  display: flex;
  flex-direction: column;
}

.choice-epool-group-head {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
  padding: var(--choice-space-1) var(--choice-space-2);
  cursor: pointer;
  border-radius: var(--choice-radius-sm);
  background: var(--choice-bg-card);
  box-shadow: inset 0 1px 0 var(--choice-frost-line);
  border: 1px solid var(--choice-border);
  font-size: var(--choice-text-sm);
  color: var(--choice-text);
}

/* 手机窄屏（<480px 触屏）：紧凑单行——按钮/把手 24px、间距收 4px、缩进收窄；
   计数恢复显示（此前为塞进单行隐藏过，用户要求可见），用 flex-shrink:0 + nowrap
   防挤压，分组名 flex:1 + 省略号兜底。特异性高于全局触屏 40px 规则 */
@media (pointer: coarse) and (max-width: 480px) {
  .choice-epool-group-head {
    gap: var(--choice-space-1);
  }

  .choice-epool-group-head .choice-icon-btn {
    width: 24px;
    height: 24px;
  }

  .choice-epool-group-head .choice-drag-handle {
    width: 24px;
  }

  .choice-epool-group-body {
    padding-left: var(--choice-space-2);
  }

  .choice-epool-entry-head {
    gap: var(--choice-space-1);
    padding: var(--choice-space-1);
  }

  .choice-epool-entry-head .choice-drag-handle {
    width: 24px;
  }

  .choice-epool-entry-body {
    gap: var(--choice-space-1);
  }

  .choice-epool-entry-body .choice-icon-btn {
    width: 24px;
    height: 24px;
  }

  .choice-cat-select {
    max-width: 64px;
  }
}

.choice-epool-group-head:hover {
  background: var(--choice-bg-hover);
}

.choice-epool-group-name {
  font-weight: bold;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.choice-epool-group-count {
  font-size: var(--choice-text-xs);
  color: var(--choice-text-muted);
  cursor: pointer;
  /* 防挤压消失：分组名 flex:1 收缩时，无 shrink:0 的计数会被挤到 0 宽不可见 */
  flex-shrink: 0;
  white-space: nowrap;
}

.choice-epool-group-body {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-1);
  padding: var(--choice-space-1) 0 var(--choice-space-1) var(--choice-space-4);
  /* max-height 只为折叠动画存在（2000→4px 过渡），必须有限值；上限给到 20000px
     ≈ 数百行，实际不会触达。子行必须 flex-shrink:0：flex 列容器在限高下会把行
     按比例压扁成细条（flex 默认 shrink），条目多时全部叠在一起不可读——
     WorldInfoEditor 的排除列表注释记录过同一坑。行高恒定后，超出部分由外层
     .choice-epool-body 滚动呈现，而非压进行内 */
  max-height: 20000px;
  overflow: hidden;
  transition:
    max-height var(--choice-transition-slow),
    opacity var(--choice-transition-slow),
    padding var(--choice-transition-slow);
  opacity: 1;
}

.choice-epool-group-body > * {
  flex-shrink: 0;
}

.choice-epool-group-body.is-collapsed {
  max-height: 4px;
  padding: 0;
  opacity: 0;
}

/* 条目 */
.choice-epool-entry {
  display: flex;
  flex-direction: column;
  border: 1px solid var(--choice-border);
  border-radius: var(--choice-radius-sm);
  background: var(--choice-bg-card);
  box-shadow: inset 0 1px 0 var(--choice-frost-line);
  overflow: hidden;
}

/* 统计页定位高亮：边框 + 外发光，~1.8s 后移除（JS 定时器去 class） */
.choice-epool-entry--focus {
  border-color: var(--choice-color-info);
  box-shadow:
    0 0 0 2px var(--choice-color-info-bg),
    inset 0 1px 0 var(--choice-frost-line);
  transition:
    border-color var(--choice-transition),
    box-shadow var(--choice-transition);
}

.choice-epool-entry-head {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
  padding: var(--choice-space-1) var(--choice-space-2);
  min-height: 0;
  flex-wrap: wrap;
}

.choice-epool-entry-head:hover {
  background: var(--choice-bg-hover);
}

.choice-epool-entry-summary {
  flex: 1;
  font-size: var(--choice-text-sm);
  color: var(--choice-text-secondary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  cursor: pointer;
}

.choice-pin-badge {
  font-size: var(--choice-text-xs);
  flex-shrink: 0;
}

.choice-cat-select {
  font-size: var(--choice-text-xs);
  padding: 1px var(--choice-space-1);
  width: auto;
  min-width: 0;
  max-width: 90px;
  flex-shrink: 1;
  background: var(--choice-bg-element);
  border: 1px solid var(--choice-border-strong);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
  color: var(--choice-text);
}

.choice-cat-select:focus {
  border-color: var(--choice-border-active);
  outline: none;
}

.choice-epool-entry-body {
  display: flex;
  flex-direction: column;
  gap: var(--choice-space-2);
  padding: 0 var(--choice-space-2) var(--choice-space-2);
  border-top: 1px solid var(--choice-border);
  padding-top: var(--choice-space-2);
}

.choice-epool-entry-fields {
  display: flex;
  align-items: center;
  gap: var(--choice-space-2);
  flex-wrap: nowrap;
}

.choice-small-input {
  width: 56px;
  background: var(--choice-bg-element);
  border: 1px solid var(--choice-border-strong);
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
  color: var(--choice-text);
}

.choice-small-input:focus {
  border-color: var(--choice-border-active);
  outline: none;
}

.choice-icon-btn {
  background: transparent;
  color: var(--choice-text-muted);
  border: none;
  cursor: pointer;
  font-size: var(--choice-text-sm);
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  border-radius: var(--choice-radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  transition:
    background var(--choice-transition),
    color var(--choice-transition);
}

.choice-icon-btn:hover:not(:disabled) {
  background: var(--choice-bg-hover);
  color: var(--choice-text);
}

.choice-delete-btn {
  color: var(--choice-color-error);
}

.choice-delete-btn:hover:not(:disabled) {
  color: var(--choice-color-error);
}

.choice-check {
  display: inline-flex;
  align-items: center;
  gap: var(--choice-space-1);
  font-size: var(--choice-text-xs);
  color: var(--choice-text-secondary);
  white-space: nowrap;
}

.choice-empty-hint {
  color: var(--choice-text-muted);
  font-size: var(--choice-text-sm);
  padding: var(--choice-space-5) 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--choice-space-2);
}

.choice-empty-hint i {
  font-size: var(--choice-text-xl);
}
</style>
