<template>
  <Teleport to="body">
    <!-- 按压/拖动期的全屏命中屏蔽层：气泡用 transform 跟手，Vue 异步刷新使位移滞后
         pointermove 一帧，Chromium 的 hover 重算用更新前的几何，间隙帧命中会穿透到
         下层的酒馆元素——主界面 .menu_button 的 :hover 白底带过渡，表现为"拖动/点击
         悬浮球时酒馆按键闪白"。屏蔽层接住间隙帧命中，酒馆元素拿不到 :hover。
         VueUse 把 pointermove/pointerup 挂在 window 捕获阶段不受影响；屏蔽层在
         pointerdown 之后才挂载，本次手势的 down/up 都落在气泡上，点击判定无干扰。
         右键不置 isPressed，长按菜单的 contextmenu 路径不受影响。面板打开时
         FloatingSettings 的 overlay 本身就是全屏屏蔽层，无需在此叠加处理 -->
    <div v-if="isPressed || isDragging" class="choice-drag-shield" aria-hidden="true"></div>
    <div
      ref="bubbleEl"
      class="choice-floating-bubble"
      :class="{
        'choice-floating-bubble--dragging': isDragging,
        'choice-floating-bubble--generating': bubbleState === 'generating',
        'choice-floating-bubble--idle': bubbleState === 'idle' && !isDragging,
        'choice-floating-bubble--disabled': bubbleState === 'disabled',
        'choice-floating-bubble--snapped-left': isSnappedLeft && !isDragging,
        'choice-floating-bubble--snapped-right': isSnappedRight && !isDragging,
        // 方向档不受 isDragging 门控（拖拽中贴边让位要取消，但按住探出仍需知道方向），
        // 专供按压探出组合使用，见样式 choice-floating-bubble--pressed 段
        'choice-floating-bubble--snap-left-dir': isSnappedLeft,
        'choice-floating-bubble--snap-right-dir': isSnappedRight,
        'choice-floating-bubble--pressed': isPressed,
        'choice-floating-bubble--above-overlay': isSettingsOpen,
        'choice-floating-bubble--compact': bubbleCompact,
      }"
      :style="{
        '--choice-x': x + 'px',
        '--choice-y': y + 'px',
        width: BUBBLE_SIZE + 'px',
        height: BUBBLE_SIZE + 'px',
        '--choice-bubble-icon-size': BUBBLE_SIZE / 3 + 'px',
        transition:
          isDragging || isResizing
            ? 'none'
            : isPressed
              ? 'transform 0.12s ease-out'
              : 'transform 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }"
      :title="bubbleTitle"
    >
      <div class="choice-bubble-inner-ring"></div>
      <i
        :class="
          isGenerating ? 'fa-solid fa-spinner fa-spin choice-bubble-icon' : 'fa-solid fa-chess choice-bubble-icon'
        "
      ></i>
    </div>
    <FloatingContextMenu v-if="isBubbleContextMenuOpen" />
    <FloatingOptions v-if="isBubbleOptionsOpen" />
  </Teleport>
</template>

<script setup lang="ts">
import { generatorState, resolveCustomApi } from '@/core/generator';
import { useGlobalSettingsStore } from '@/store/global-settings';
import { usePoolSelectorStore } from '@/store/pool-selector';
import {
  toggleSettings,
  closeSettings,
  isSettingsOpen,
  isBubbleContextMenuOpen,
  isBubbleOptionsOpen,
  closeBubbleOptions,
  bubbleX,
  bubbleY,
  bubbleSize,
  isMobileBubble,
  snapBubblePosition,
  getSnapOffset,
} from '@/core/floating-state';
import FloatingContextMenu from '@/components/FloatingContextMenu.vue';
import FloatingOptions from '@/components/FloatingOptions.vue';

// 气泡直径与移动端判定来自 floating-state 单一来源（详见该模块注释），本组件不再
// 各自维护 MQL——避免与上下文菜单等处各自硬编码 60 而在移动端漂移
const BUBBLE_SIZE = bubbleSize;
const isMobilePointer = isMobileBubble;
// 贴边隐藏量 = 直径的 1/3（露 2/3）：按比例而非固定 px——桌面 60px 藏 20px 是
// 长期验证的观感基准；早先手机沿用固定露出 40px，48px 球只藏 8px 几乎全露
// （真机反馈"露出来太多"）。取 1/3 直径后两档观感一致
const SNAP_OFFSET = computed(() => getSnapOffset(BUBBLE_SIZE.value));
// 点击/长按共用的指针净位移阈值：松手时位移小于它视为点击，大于它视为拖拽意图（取消长按）
const TAP_SLOP = 8;
const STORAGE_KEY_X = 'choice_floating_bubble_x';
const STORAGE_KEY_Y = 'choice_floating_bubble_y';
// 按住气泡期间挂在 body 行内样式上的禁选：盖住长按选中"附近文本"的路径。
// 不能用 body class 实现（原 choice-suppress-select 类）：theme.css 的限域选择器用
// [class*='choice-'] 匹配任意祖先，body 一旦挂 choice- 类，body 自己就成了"choice
// 容器"，[data-choice-theme] [class*='choice-'] .menu_button 等整组规则会泄漏到
// 全页所有酒馆元素（实测：按压期间整个主界面的 .menu_button 被染成面板元素色，
// 即"拖动/点击悬浮球时主界面按键变色"的主根因）。行内样式 + important 与原规则
// 等效，且不产生可被属性选择器误配的痕迹；必须与清理成对出现
// （onEnd/pointercancel/onUnmounted 三处兜底）——漏清理会导致全站文本无法选中，
// 属于不可见的高危回归
const SUPPRESS_SELECT_PROPS = ['user-select', '-webkit-user-select'] as const;
const applySuppressSelect = () => {
  for (const prop of SUPPRESS_SELECT_PROPS) document.body.style.setProperty(prop, 'none', 'important');
};
const clearSuppressSelect = () => {
  for (const prop of SUPPRESS_SELECT_PROPS) document.body.style.removeProperty(prop);
};

const isGenerating = computed(() => generatorState.loading);

// 紧凑小点样式（ui.bubble_style='compact'）：直径由 floating-state.bubbleSize 统一
// 处理，这里只挂视觉类（内环保留度/呼吸节奏走本组件样式表）
const bubbleCompact = computed(() => useGlobalSettingsStore().settings.ui.bubble_style === 'compact');

const posX = useStorage(STORAGE_KEY_X, window.innerWidth - BUBBLE_SIZE.value - 16);
const posY = useStorage(STORAGE_KEY_Y, window.innerHeight - BUBBLE_SIZE.value - 80);

const isSnappedLeft = ref(false);
const isSnappedRight = ref(false);

const isDisabled = computed(() => {
  const gs = useGlobalSettingsStore();
  const api = resolveCustomApi(gs.settings.active_api_id, gs.settings.apis);
  const pool = usePoolSelectorStore().effectivePool;
  return !api || pool.length === 0;
});

// disabled 态此前只是变暗，没有任何文字解释"为什么点它没用"。title 把具体缺什么
// 说清楚（未配 API / 池空 / 都缺），并随 bubble_click_action 提示单击将打开什么
// （选项弹窗 / 设置面板），避免文案与实际点击行为错位
const bubbleTitle = computed(() => {
  const gs = useGlobalSettingsStore();
  const noApi = !resolveCustomApi(gs.settings.active_api_id, gs.settings.apis);
  const noPool = usePoolSelectorStore().effectivePool.length === 0;
  const opensSettings = gs.settings.ui.bubble_click_action === 'settings';
  const actionHint = opensSettings ? t`Click to open settings` : t`Click to view options`;
  if (noApi && noPool) return t`API is not configured and the entry pool is empty -${actionHint}`;
  if (noApi) return t`Not configured API——${actionHint}`;
  if (noPool) return t`The entry pool is empty——${actionHint}`;
  return actionHint;
});

const bubbleState = computed(() => {
  if (isDisabled.value) return 'disabled';
  if (isGenerating.value) return 'generating';
  if (isDragging.value) return 'dragging';
  return 'idle';
});

const bubbleEl = ref<HTMLElement | null>(null);

// 按压态只做整体 scale 反馈。禁止给容器加任何会改变 getBoundingClientRect 的位移效果
// （比如曾经的"贴边弹出 translateX(20px)"）：useDraggable 的拖拽锚点取自 pointerdown 时
// 的视觉矩形（VueUse 13.9.0 实现为 e.clientX - targetRect.left，getBoundingClientRect
// 含 CSS transform），容器一带位移锚点就偏离逻辑坐标——点击时 1px 指针抖动会让
// position 突跳 ~20px，松手被误判成拖拽，即"贴边球点一下弹一下、面板打不开"的根因。
// 位移类视觉提示只能放在子元素上（子元素 transform 不影响容器矩形），见样式里
// snapped:hover 的图标 nudge。按压缩放本身安全：锚点在 VueUse 的 capture 阶段采集，
// 早于 pressed 类生效；且 scale 不改 translate，残余偏差 ≤2.4px 不可见。
const isPressed = ref(false);

const handleClick = () => {
  isBubbleContextMenuOpen.value = false;
  bubbleX.value = posX.value;
  bubbleY.value = posY.value;
  // 单击行为由 ui.bubble_click_action 决定：
  // - 'settings'：恢复"点击打开/关闭设置"的旧语义（弹窗不参与，保持关闭）；
  // - 'options'：设置面板开着时点气泡关闭设置（气泡在遮罩之上可命中，第二次点击
  //   需能收回），否则切换选项弹窗开/关
  const gs = useGlobalSettingsStore();
  if (gs.settings.ui.bubble_click_action === 'settings') {
    toggleSettings();
    return;
  }
  if (isSettingsOpen.value) {
    closeSettings();
  } else {
    isBubbleOptionsOpen.value = !isBubbleOptionsOpen.value;
  }
};

const { x, y, isDragging } = useDraggable(bubbleEl, {
  initialValue: { x: posX.value, y: posY.value },
  // 按压期间指针净位移超过 TAP_SLOP 即转入拖拽意图：取消长按计时、撤掉按压缩放，
  // 让球以完整尺寸跟手。onMove 由 VueUse 接在 window 上，不怕指针滑出气泡范围
  onMove: (_pos, e) => {
    if (Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y) > TAP_SLOP) {
      clearLongPressTimer();
      isPressed.value = false;
    }
  },
  onEnd: (finalPos, e) => {
    // window 级 pointerup 必达，在这里兜底清长按计时器：元素级监听可能因指针滑出
    // 气泡收不到 up，漏清会形成"幽灵长按"——面板刚被点开，500ms 后菜单又自己弹出
    clearLongPressTimer();
    isPressed.value = false;
    clearSuppressSelect();

    const snapped = snapBubblePosition(finalPos.x, finalPos.y, BUBBLE_SIZE.value, {
      width: window.innerWidth,
      height: window.innerHeight,
    });
    posX.value = snapped.x;
    posY.value = snapped.y;
    x.value = snapped.x;
    y.value = snapped.y;
    isSnappedLeft.value = snapped.snappedLeft;
    isSnappedRight.value = snapped.snappedRight;
    bubbleX.value = snapped.x;
    bubbleY.value = snapped.y;

    // 点击判定用指针净位移而非元素位置差：元素位置被视觉位移污染（见 isPressed 注释），
    // 指针位移才是"点击意图"的正确度量。8px 容忍触摸抖动，与长按取消共用同一阈值
    const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
    if (moved < TAP_SLOP && !longPressTriggered) {
      handleClick();
    }
    longPressTriggered = false;
  },
});

let longPressTimer: ReturnType<typeof setTimeout> | null = null;
let longPressTriggered = false;
let pointerDownPos = { x: 0, y: 0 };

const clearLongPressTimer = () => {
  if (longPressTimer !== null) {
    clearTimeout(longPressTimer);
    longPressTimer = null;
  }
};

const onPointerDown = (e: PointerEvent) => {
  // 右键交给 contextmenu 处理，与 useDraggable 默认 buttons:[0] 对齐
  if (e.button !== 0) return;
  longPressTriggered = false;
  pointerDownPos = { x: e.clientX, y: e.clientY };
  isPressed.value = true;
  // 手机端长按会触发原生文本选择：安卓 Chromium 对 user-select:none 的元素长按，
  // 仍可能选中附近的聊天文本；iOS 则弹出系统 callout。preventDefault 抑制兼容鼠标
  // 事件与长按选择手势——useDraggable 用 pointer 事件且监听器照常触发（不阻断传播），
  // 拖拽不受影响；气泡无 focus/输入依赖，取消默认行为安全
  if (e.pointerType !== 'mouse') {
    e.preventDefault();
  }
  // 按住期间（直到松手/取消）在 body 级兜底禁选：盖住长按选中"附近文本"的路径。
  // 必须与清理成对出现（onEnd/pointercancel/onUnmounted 三处兜底）——漏移除会导致
  // 全站文本无法选中，属于不可见的高危回归
  applySuppressSelect();
  // 长按菜单仅触屏/笔生效：鼠标按住半秒是常见误操作（原本会吞掉点击），鼠标改用右键
  if (e.pointerType !== 'mouse') {
    longPressTimer = setTimeout(() => {
      longPressTriggered = true;
      isPressed.value = false;
      bubbleX.value = posX.value;
      bubbleY.value = posY.value;
      // 快捷菜单与选项 popover 互斥：长按打开菜单时收起已弹出的选项
      closeBubbleOptions();
      isBubbleContextMenuOpen.value = true;
    }, 500);
  }
};

// touch-action:none 已阻断滚动接管，pointercancel 罕见；VueUse 只监听 pointerup，
// cancel 不会走 onEnd，这里兜底清理按压态与计时器
const onPointerCancel = () => {
  clearLongPressTimer();
  isPressed.value = false;
  clearSuppressSelect();
};

// 鼠标右键呼出应用菜单（触屏长按的等价物）。FloatingContextMenu 的 document 级
// pointerdown 关闭逻辑忽略气泡来源的点击，不会被同一次右键的 pointerdown 立即关掉
const onContextMenu = (e: MouseEvent) => {
  e.preventDefault();
  bubbleX.value = posX.value;
  bubbleY.value = posY.value;
  // 快捷菜单与选项 popover 互斥：右键打开菜单时收起已弹出的选项
  closeBubbleOptions();
  isBubbleContextMenuOpen.value = true;
};

// 初始位置判断：如果存储的 x 靠左或靠右，初始化吸附状态
watch(
  posX,
  val => {
    const centerX = val + BUBBLE_SIZE.value / 2;
    isSnappedLeft.value = centerX < window.innerWidth / 2 && (val === -SNAP_OFFSET.value || val <= 0);
    isSnappedRight.value =
      centerX >= window.innerWidth / 2 &&
      (val === window.innerWidth - BUBBLE_SIZE.value + SNAP_OFFSET.value ||
        val >= window.innerWidth - BUBBLE_SIZE.value);
    bubbleX.value = val;
    bubbleY.value = posY.value;
  },
  { immediate: true },
);

const isResizing = ref(false);
let resizeTimer: ReturnType<typeof setTimeout> | null = null;
const handleResize = () => {
  isResizing.value = true;
  let clampedX: number;
  if (isSnappedLeft.value) {
    clampedX = -SNAP_OFFSET.value;
  } else if (isSnappedRight.value) {
    clampedX = window.innerWidth - BUBBLE_SIZE.value + SNAP_OFFSET.value;
  } else {
    clampedX = Math.max(0, Math.min(posX.value, window.innerWidth - BUBBLE_SIZE.value));
  }
  const clampedY = Math.max(0, Math.min(posY.value, window.innerHeight - BUBBLE_SIZE.value));
  posX.value = clampedX;
  posY.value = clampedY;
  x.value = clampedX;
  y.value = clampedY;
  bubbleX.value = clampedX;
  bubbleY.value = clampedY;

  if (resizeTimer !== null) clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    resizeTimer = null;
    isResizing.value = false;
  }, 200);
};

// 尺寸档切换（旋屏跨过 480px、外接/断开鼠标）不会触发 window resize，
// 但 clamp 边界变了：必须立即按新直径重夹位置，否则桌面存档位置在切到手机档时
// 可能超出 innerWidth - 48 的边界悬在屏外
watch(isMobilePointer, handleResize);

onMounted(() => {
  bubbleEl.value?.addEventListener('pointerdown', onPointerDown);
  bubbleEl.value?.addEventListener('pointercancel', onPointerCancel);
  bubbleEl.value?.addEventListener('contextmenu', onContextMenu);
  window.addEventListener('resize', handleResize);
  // 初始化钳制：位置存档（localStorage）可能是在更宽的窗口/别的设备下写入的，
  // 首次挂载若超出当前视口，球会整个悬在屏外（真机反馈"有时打开浏览器看不见
  // 悬浮球"）。resize 事件只在窗口变化时触发，覆盖不了"存档越界 + 视口未变"
  // 的加载场景，必须挂载时主动钳一次（幂等：贴边态按当前直径重吸附，界内则原样）
  handleResize();
});
onUnmounted(() => {
  bubbleEl.value?.removeEventListener('pointerdown', onPointerDown);
  bubbleEl.value?.removeEventListener('pointercancel', onPointerCancel);
  bubbleEl.value?.removeEventListener('contextmenu', onContextMenu);
  window.removeEventListener('resize', handleResize);
  if (resizeTimer !== null) clearTimeout(resizeTimer);
  clearLongPressTimer();
  // 组件卸载兜底：按住状态下组件被卸载时，禁选样式残留会让全站无法选字
  clearSuppressSelect();
});
</script>

<style scoped>
.choice-floating-bubble {
  position: fixed;
  left: 0;
  top: 0;
  z-index: var(--choice-z-floating);
  /* 尺寸不在此写死：直径是 JS 侧 clamp/吸附计算的一部分（BUBBLE_SIZE computed），
     由 :style 单一来源驱动，双处常量必然漂移 */
  border-radius: var(--choice-radius-full);
  background: var(--choice-bg-panel);
  border: 1px solid var(--choice-border);
  color: var(--choice-primary);
  display: flex;
  align-items: center;
  justify-content: center;
  /* 图标随直径等比（1/3 直径），且保留字体档缩放联动（原为固定 --choice-text-xl，
     48px 手机球上 20px 图标偏挤） */
  font-size: calc(var(--choice-bubble-icon-size, 20px) * var(--choice-font-scale, 1));
  cursor: pointer;
  box-shadow: var(--choice-shadow-glow);
  touch-action: none;
  /* -webkit- 前缀版缺一不可：老 WebView 内核只认前缀写法；touch-callout 抑制
     iOS Safari 长按弹出的系统级菜单/放大镜（user-select 管不到它） */
  -webkit-user-select: none;
  user-select: none;
  -webkit-touch-callout: none;
  transform: translate3d(var(--choice-x), var(--choice-y), 0);
  overflow: hidden;
}

.choice-floating-bubble--idle {
  opacity: 0.75;
  animation: choice-bubble-breathe 8s ease-in-out infinite;
}

.choice-floating-bubble--generating {
  animation: choice-bubble-pulse 3s ease-in-out infinite;
}

/* 禁用态只靠整体变暗+去色传达（右上角 ⚠ 角标已移除：overflow:hidden 剪裁下
   悬挂式被剪成豁口、收入界内又喧宾夺主，两版真机都不接受）；禁用原因仍可在
   悬浮面板/设置里看到，气泡本身保持干净 */
.choice-floating-bubble--disabled {
  opacity: 0.5;
  filter: grayscale(30%);
}

/* 紧凑小点（ui.bubble_style='compact'）：小直径下内环装饰与呼吸动画都收淡，
   观感更接近干净的小圆点，手机端更不占视觉注意力（直径由 floating-state 管） */
.choice-floating-bubble--compact .choice-bubble-inner-ring {
  opacity: 0.12;
}

.choice-floating-bubble--compact.choice-floating-bubble--idle {
  animation-duration: 12s;
}

/* 命中屏蔽层：与气泡同 z-index，DOM 顺序在气泡之前（同层后者在上），
   故气泡可命中可见，屏蔽层只兜住气泡之外的整屏命中。完全透明，纯 hit-test 用 */
.choice-drag-shield {
  position: fixed;
  inset: 0;
  z-index: var(--choice-z-floating);
  background: transparent;
}

.choice-floating-bubble--dragging {
  will-change: transform;
  cursor: grabbing;
}

/* 面板打开时把气泡提到遮罩(9000,含其子级对话框)之上：否则第二次点击气泡关闭面板时，
   点击被全屏遮罩吞掉，气泡永远收不到 click */
.choice-floating-bubble--above-overlay {
  z-index: calc(var(--choice-z-floating) + 1);
}

/* —— 悬停类反馈仅对真正支持 hover 的指针（鼠标）启用 ——
   触屏浏览器的 :hover 在点按后会粘滞（没有 pointerleave 时机）：松手、甚至设置
   面板关闭后，探出/放大态仍卡住不回弹（真机反馈"点击后棋子固定在内侧光环之外，
   有时不会回去"——"有时候"取决于浏览器是否保留该次点按的 hover 态）。
   触屏只保留贴边让位基础态；老内核不认此媒体条件时整块被忽略，仅失去悬停增强 */
@media (hover: hover) and (pointer: fine) {
  .choice-floating-bubble:hover {
    opacity: 1;
    box-shadow: 0 0 28px rgba(var(--choice-primary-rgb), 0.45);
  }

  /* 贴边态悬停禁止容器位移弹出（peek）：容器 transform 会改变 getBoundingClientRect，
     污染 useDraggable 拖拽锚点、把点击抖动放大成瞬移（根因见 script 内 isPressed 注释）。
     悬停提示改为图标向屏幕内侧多探出几 px——子元素 transform 不影响容器矩形。
     让位量随图标尺寸等比（0.7 倍），48px 手机球不再沿用桌面的固定 14px */
  .choice-floating-bubble--snapped-left:hover .choice-bubble-icon {
    transform: translateX(calc(var(--choice-bubble-icon-size, 20px) * 0.7));
  }

  .choice-floating-bubble--snapped-right:hover .choice-bubble-icon {
    transform: translateX(calc(var(--choice-bubble-icon-size, 20px) * -0.7));
  }

  /* 悬停放大排除按压态：否则此规则(0,4,0)特异性压过 pressed(0,1,0)，
     鼠标按下时收缩反馈永远不生效（按住时球必然处于 hover 中） */
  .choice-floating-bubble:not(.choice-floating-bubble--snapped-left):not(.choice-floating-bubble--snapped-right):not(
      .choice-floating-bubble--pressed
    ):hover {
    transform: translate3d(var(--choice-x), var(--choice-y), 0) scale(1.08);
  }
}

/* 按压态：整体轻微收缩作反馈，不加任何位移（根因见 script 内 isPressed 注释）。
   松手后由内联 transition 的回弹缓动放回，与拖拽吸附共用同一份缓动 */
.choice-floating-bubble--pressed {
  transform: translate3d(var(--choice-x), var(--choice-y), 0) scale(0.94);
}

/* 触屏的悬停等价物是"按住"：按住贴边球时图标探出、松手回弹——与 PC 端 hover
   的动效节奏一致（探出量同为 0.7 倍图标尺寸）。方向用不受 isDragging 门控的
   -snap-*-dir 类：useDraggable 在 pointerdown 即置 isDragging，贴边让位类
   （snapped-*，绑了 !isDragging）按住期间整体消失，combo 若依赖它们永远不命中。
   松手随 --pressed 的清理路径（onEnd/pointercancel/onUnmounted）必然回落，
   拖拽中指针越过 TAP_SLOP 也会撤掉按压态→探出随之取消，不干扰拖拽跟手 */
.choice-floating-bubble--pressed.choice-floating-bubble--snap-left-dir .choice-bubble-icon {
  transform: translateX(calc(var(--choice-bubble-icon-size, 20px) * 0.7));
}

.choice-floating-bubble--pressed.choice-floating-bubble--snap-right-dir .choice-bubble-icon {
  transform: translateX(calc(var(--choice-bubble-icon-size, 20px) * -0.7));
}

.choice-bubble-inner-ring {
  position: absolute;
  inset: 3px;
  border-radius: 50%;
  background: conic-gradient(from 0deg, var(--choice-primary), transparent 60%, var(--choice-primary));
  opacity: 0.3;
  pointer-events: none;
  /* 镂空成环：实心圆锥渐变的所有角度在圆心交汇，会出现一个彩色聚点——平时被
     居中图标盖住，贴边态图标向内侧让位后恰好露出来（真机反馈"贴边后中间有个点"）。
     radial mask 只留外圈，扫光变成贴边旋转的弧环；-webkit- 前缀版老内核也要认，
     两个都不认时整条被忽略，回落为原实心圆盘（仅观感回退，无功能影响） */
  -webkit-mask: radial-gradient(farthest-side, #0000 calc(100% - 4px), #000 calc(100% - 3px));
  mask: radial-gradient(farthest-side, #0000 calc(100% - 4px), #000 calc(100% - 3px));
}

.choice-floating-bubble--idle .choice-bubble-inner-ring {
  animation: choice-bubble-ring-spin 20s linear infinite;
}

.choice-floating-bubble--generating .choice-bubble-inner-ring {
  animation: choice-bubble-ring-spin 1.5s linear infinite;
  opacity: 0.5;
}

.choice-floating-bubble--disabled .choice-bubble-inner-ring {
  animation: none;
  opacity: 0.15;
}

.choice-bubble-icon {
  position: relative;
  z-index: 1;
  transition: transform 0.3s ease;
}

/* 贴边态图标向屏幕内侧让位：让位量随图标尺寸等比（0.5 倍图标高），固定 10px
   在 48px 手机球上占比过大，图标看起来快贴出球缘（真机反馈） */
.choice-floating-bubble--snapped-left .choice-bubble-icon {
  transform: translateX(calc(var(--choice-bubble-icon-size, 20px) * 0.5));
}

.choice-floating-bubble--snapped-right .choice-bubble-icon {
  transform: translateX(calc(var(--choice-bubble-icon-size, 20px) * -0.5));
}
</style>
