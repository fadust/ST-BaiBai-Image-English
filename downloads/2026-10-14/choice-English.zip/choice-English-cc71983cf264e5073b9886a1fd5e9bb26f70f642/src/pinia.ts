export const pinia = createPinia();
